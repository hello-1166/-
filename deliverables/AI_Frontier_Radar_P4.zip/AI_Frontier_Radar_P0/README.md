# AI Frontier Radar — P4 本地视频自动流程

从已确认策划导入视频脚本JSON，放入真实素材或使用原文资料卡，Windows助手自动配音，服务自动编排字幕并生成竖屏MP4、封面、字幕和来源清单。沿用现有Plus写稿，不接写稿API或本地大模型，不自动发布。

**升级使用 `scripts/upgrade_p4.ps1`，见[完整Windows操作指南](docs/P4_GUIDE.md)。** 升级后从原工程运行 `start_p0.ps1`；另开窗口运行 `video_worker.ps1`。现有新闻、选题、分类和策划保留。

视频制作台：http://localhost:8000/videos · 内容策划台：http://localhost:8000/plans

Windows语音取决于本机中文声音包。云端Docker完整构建因磁盘不足未通过，需本机完成首次构建与健康检查；真实本地编码与浏览器流程已经验证。

---

# AI Frontier Radar — P3.1 创作者规则推荐

优先具体任务与变化线索；摘要不足先补材料，区分研究、培训与行业场景。显示推荐依据、未推荐原因和差异化建议角度，并限制同方向占满推荐。

**已有 P3 使用 `scripts/upgrade_p3_1.ps1`，见[升级与使用指南](docs/P3_1_GUIDE.md)。** 保留新闻、选题、人工分类和内容策划，沿用现有 Plus，无模型 API 请求。数据库仍为 5。

---

# AI Frontier Radar — P3 内容策划台

从已选题创建单条视频或周报策划，填写主题、受众、核实记录和分镜，保存口播/图文草稿并导出带来源的创作材料包。沿用现有 Plus，不自动调用模型或发布内容。

**已有 P2.1 请使用 `scripts/upgrade_p3.ps1`，见[Windows 升级与使用指南](docs/P3_GUIDE.md)。** 新包解压到独立目录，升级后从原项目目录运行 `scripts/start_p0.ps1`。保留 `.env`、新闻、分类、已选题和 n8n 数据。

策划台：http://localhost:8000/plans · 选题：http://localhost:8000/topics · 新闻：http://localhost:8000/radar

下面保留历史版本文档，当前升级流程以 P3 指南为准。

---

# AI Frontier Radar — P2.1 分类选题工作台

新增六类资讯、内容栏目、开放情况、证据类型、制作进度；支持组合筛选、人工覆盖与带标签导出。判断不足留待确认，默认不调用模型，继续使用现有Plus手动审稿。

**已有P2请使用scripts/upgrade_p2_1.ps1，具体见[升级与使用指南](docs/P2_1_GUIDE.md)。** 原目录启动，现有新闻和选题保留，n8n无需重新导入。

选题：http://localhost:8000/topics ；新闻：http://localhost:8000/radar 。本次变更不生成稿件或自动发布。

下面保留P2历史文档，当前升级流程以P2.1指南为准。

---

# AI Frontier Radar V1.0 — P2 自动初筛与选题工作台

P1 已在用户 Windows 验证采集和 n8n 定时运行。本版增加自动规则初筛、疑似事件合并、人工选题/忽略、Markdown导出与可选的手动模型分析。

**从 P1 升级请使用 scripts/upgrade_p2.ps1，不要使用旧 P1 升级脚本。**

完整使用与安全升级步骤见 [P2_GUIDE](docs/P2_GUIDE.md)。选题入口：http://localhost:8000/topics 。

默认规则筛选不需要密钥、不调用模型。模型分析需要本机明确启用并手动点击；真实服务商调用尚待用户凭据联调。模型和规则均不代表独立事实核查。

完整口播/图文生成与内容发布不在本增量范围。本版先交付可人工检查的选题材料。

以下为保留的 P1 使用背景，升级流程以 P2_GUIDE 为准。

---

# AI Frontier Radar V1.0 — P1 新闻收件箱

本地半自动的 AI 前沿情报系统，面向后续小红书与抖音内容准备。P0 已在 Windows 本机完成核心启动与 n8n 持久化验证；本版完成 P1 的公开 RSS/Atom 采集、链接去重、本地收件箱及可选飞书同步。

## 已有 P0：先升级，保留原目录

将 P1 ZIP 解压到一个**新的临时目录**。在新解压目录（包含 `scripts`）打开 PowerShell：

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\upgrade_p1.ps1 -ExistingProjectPath "D:\Projects\AI_Frontier_Radar_P0"
```

将示例路径替换为你正在使用的 P0 工程目录。升级脚本校验源文件和已知 P0 文件，备份旧代码，保留 `.env`、`data/`、`logs/` 及未管理的用户文件。若遇到未知本地修改会在写入前停止，供人工检查。此前把 Dockerfile 改成已验证的 Docker 官方 AWS Python 镜像，属于兼容的修改。

升级后，回到**原 P0 目录**运行：

```powershell
.\scripts\start_p0.ps1
```

沿用原工程目录名，n8n Compose 项目与持久化卷不会因升级被改名。启动时 SQLite 会从 schema 1 升至 schema 2，原始数据库先备份到 `data/backups/`。旧代码在 `backups/p1-code-*/`。

不要直接将新 ZIP 覆盖整个旧目录，也不要执行 `docker compose down -v`。

## 首次安装

启动 Docker Desktop，确认使用 Linux containers / WSL 2。在工程目录运行：

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\start_p0.ps1
```

没有飞书或模型凭据也能启动。脚本检查引擎、拉取 n8n、构建 API、等待健康并运行冒烟检查。首次较慢可加 `-WaitTimeout 600`。

## 使用入口

- **新闻收件箱：<http://localhost:8000/radar>**
- n8n：<http://localhost:5678>
- API 文档：<http://localhost:8000/docs>

先打开新闻收件箱，点击“采集一次”。每次回看最近 7 天，每源最多处理 100 条；来源未提供发布时间时明确显示未知，历史记录不会自动删除。标题与摘要保留来源原文，摘要截断至最多 1200 字符，模型翻译和内容改写属于后续阶段。

同一规范化链接只保留一条新闻，不同来源仍记录在出处中。只去掉明确的跟踪参数，保留有业务含义的 URL 参数；这不是同一事件的语义聚类。所有收录内容均为“未核查”。

## 来源和计划

已配置并实查的公开 RSS：OpenAI News、Google DeepMind、Hugging Face、arXiv cs.AI / cs.LG、Google AI Blog、Google Research Blog。综合 Hacker News 默认停用。

来源配置在 `config/source_registry.yaml`；超时、回看天数、条目上限在 `config/ingestion.yaml`。HTTP 304 保留现有数据，429 按 Retry-After 设置冷却，单源失败不会丢掉其他来源的成功结果。错误与运行历史保存在本地，并在页面显示。

启用 n8n 定时采集：导入 `workflows/01_news_ingestion.json`，先手动执行检查结果。工作流默认未激活，定时节点为每 15 分钟。验收后在 n8n 中启用/发布工作流才会自动采集；这里启用的是采集任务。节点不包含社交平台发布，也没有模型凭据或远端消息通知。

`config/settings.yaml` 中的日报、紧急提醒等是早期规划，P1 尚不执行。采集间隔以 n8n 定时节点为准，不能只修改规划 YAML 就认为定时任务已改变。

## 飞书与模型

飞书为可选的 News Inbox 工作台。按 `docs/P1_FEISHU_SETUP.md` 准备表字段，在本机 `.env` 填写应用信息并重新创建 API 容器。然后在收件箱点击“同步下一批 25 条”。同步先核对字段类型、按 Radar ID 查询，既有记录不会被修改；本地丢失创建响应时，下次会先查重。

P1 是本地到飞书的单向新增/关联；人工在飞书修改的审核状态暂不回写本地。本地仍标记内容未独立核查。源链接与来源名称随记录同步，未知发布时间留空。飞书真实权限与写入需要在你本机配置后联调，模拟测试不能代替真实联调。

多模型配置仍支持 OpenAI、Anthropic、Gemini、DeepSeek、Qwen。P1 不调用模型、不产生模型调用费用，也不自动生成或发布内容。

## 测试与排障

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -e ".[dev]" -c requirements-dev.lock
pytest
```

PowerShell 不存在时，脚本测试会明确 skip；完整脚本验证需要 PowerShell。普通单元测试不访问外部 RSS 或飞书。Python 运行与开发依赖均有含平台标记的锁文件。

Dockerfile 使用 Docker 官方 AWS 公共仓库的 Python 镜像作为默认基础镜像，避免已遇到的 Docker Hub 鉴权地址超时；可通过本机 `.env` 的 `PYTHON_BASE_IMAGE` 改用其他已核实的官方来源。不会关闭 TLS 校验。`docs/N8N_TROUBLESHOOTING.md` 保留 P0 网络问题的说明。

Linux bind mount 权限可通过 `.env` 的 `RADAR_UID` / `RADAR_GID` 指定；普通 Docker 对应宿主机用户，rootless Docker 可能需要容器 0:0。Windows Desktop 保留默认即可。

日常启动：`docker compose up -d --no-build --wait --wait-timeout 180`；停止：`docker compose stop`。`docker compose config --quiet` 用于校验，不要分享包含展开密钥的完整配置输出。

## 当前边界与交付记录

- `docs/P1_IMPLEMENTATION_BRIEF.md`：范围与架构。
- `docs/P1_FEISHU_SETUP.md`：字段、权限与同步步骤。
- `docs/P1_ACCEPTANCE.md`：实际验证及未验证事项。
- `docs/P0_EXECUTION_REPORT.md`：此前 P0 云端执行历史，不能当作 P1 当前结论。

内部时间使用 UTC，界面显示 Asia/Shanghai。密钥只放本机 `.env`；运行数据库、日志、备份和 `.env` 不进入工程包。P1 没有自动评分、事实核查、图文/视频生产或平台发布；这些阶段继续保留人工审核。
