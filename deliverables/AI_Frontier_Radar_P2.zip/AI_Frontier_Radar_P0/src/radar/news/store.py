from __future__ import annotations

import json
import sqlite3
from contextlib import closing, contextmanager
from datetime import UTC, datetime

from radar.core.database import database_path


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


@contextmanager
def database():
    with closing(sqlite3.connect(database_path(), timeout=10)) as connection:
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        with connection:
            yield connection


def feed_state(source_id: str) -> dict:
    with database() as c:
        row = c.execute("SELECT * FROM feed_state WHERE source_id=?", (source_id,)).fetchone()
    return dict(row) if row else {}


def save_feed_state(source_id: str, values: dict) -> None:
    previous = feed_state(source_id)
    previous.update(values)
    fields = [
        "etag",
        "last_modified",
        "next_allowed_at",
        "last_checked_at",
        "last_status",
        "last_error",
    ]
    with database() as c:
        c.execute(
            "INSERT INTO feed_state (source_id," + ",".join(fields) + ") VALUES (?,?,?,?,?,?,?) "
            "ON CONFLICT(source_id) DO UPDATE SET " + ",".join(f"{f}=excluded.{f}" for f in fields),
            [source_id] + [previous.get(f) for f in fields],
        )


def save_items(items: list[dict], collected_at: str) -> tuple[int, int]:
    inserted = 0
    fields = [
        "id",
        "canonical_url",
        "title",
        "original_url",
        "source_id",
        "source_name",
        "language",
        "category",
        "summary",
        "published_at",
        "published_at_raw",
    ]
    with database() as c:
        for item in items:
            cursor = c.execute(
                "INSERT INTO news_items (" + ",".join(fields) + ",first_collected_at,last_seen_at) "
                "VALUES (" + ",".join("?" for _ in range(len(fields) + 2)) + ") "
                "ON CONFLICT(canonical_url) DO UPDATE SET last_seen_at=excluded.last_seen_at "
                "RETURNING id,first_collected_at",
                [item.get(f) for f in fields] + [collected_at, collected_at],
            )
            row = cursor.fetchone()
            # An item and its first origin are committed together; later origins are duplicates.
            first_origin = c.execute(
                "SELECT 1 FROM news_origins WHERE news_id=? LIMIT 1", (row["id"],)
            ).fetchone()
            if first_origin is None:
                inserted += 1
            c.execute(
                "INSERT INTO news_origins "
                "(news_id,source_id,source_name,entry_id,original_url,first_seen_at,last_seen_at) "
                "VALUES (?,?,?,?,?,?,?) ON CONFLICT(news_id,source_id) DO UPDATE SET "
                "last_seen_at=excluded.last_seen_at",
                (
                    row["id"],
                    item["source_id"],
                    item["source_name"],
                    item["entry_id"],
                    item["original_url"],
                    collected_at,
                    collected_at,
                ),
            )
    return inserted, len(items) - inserted


def begin_run(run_id: str, started_at: str) -> None:
    with database() as c:
        c.execute(
            "INSERT INTO ingestion_runs(id,started_at,status) VALUES (?,?,?)",
            (run_id, started_at, "running"),
        )


def finish_run(result: dict) -> None:
    with database() as c:
        c.execute(
            "UPDATE ingestion_runs SET finished_at=?,status=?,details_json=?,seen=?,inserted=?,"
            "duplicates=?,skipped=?,errors=? WHERE id=?",
            (
                result["finished_at"],
                result["status"],
                json.dumps(result["sources"]),
                result["seen"],
                result["inserted"],
                result["duplicates"],
                result["skipped"],
                result["errors"],
                result["id"],
            ),
        )


def runs(limit: int = 20) -> list[dict]:
    with database() as c:
        rows = c.execute(
            "SELECT * FROM ingestion_runs ORDER BY started_at DESC LIMIT ?", (limit,)
        ).fetchall()
    result = []
    for row in rows:
        value = dict(row)
        value["sources"] = json.loads(value.pop("details_json"))
        result.append(value)
    return result


def news(limit: int, offset: int, source_id: str | None, query: str, sync: str | None) -> dict:
    conditions, params = [], []
    if source_id:
        conditions.append(
            "EXISTS (SELECT 1 FROM news_origins o WHERE o.news_id=n.id AND o.source_id=?)"
        )
        params.append(source_id)
    if query:
        conditions.append("(n.title LIKE ? ESCAPE '\\' OR n.summary LIKE ? ESCAPE '\\')")
        escaped = query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        params.extend(["%" + escaped + "%"] * 2)
    if sync == "pending":
        conditions.append("n.feishu_record_id IS NULL")
    elif sync == "synced":
        conditions.append("n.feishu_record_id IS NOT NULL")
    where = " WHERE " + " AND ".join(conditions) if conditions else ""
    with database() as c:
        total = c.execute("SELECT count(*) FROM news_items n" + where, params).fetchone()[0]
        rows = c.execute(
            "SELECT n.* FROM news_items n"
            + where
            + " ORDER BY COALESCE(n.published_at,n.first_collected_at) DESC,n.id "
            "LIMIT ? OFFSET ?",
            params + [limit, offset],
        ).fetchall()
        items = []
        for row in rows:
            item = dict(row)
            item["published_at_unknown"] = item["published_at"] is None
            item["origins"] = [
                dict(origin)
                for origin in c.execute(
                    "SELECT source_id,source_name,original_url FROM news_origins WHERE news_id=?",
                    (row["id"],),
                ).fetchall()
            ]
            items.append(item)
    return {"total": total, "items": items, "limit": limit, "offset": offset}


def stats() -> dict:
    with database() as c:
        row = c.execute(
            "SELECT count(*) AS total, "
            "COALESCE(sum(feishu_record_id IS NOT NULL),0) AS synced, "
            "COALESCE(sum(published_at IS NULL),0) AS unknown_dates FROM news_items"
        ).fetchone()
    result = dict(row)
    result["pending_sync"] = result["total"] - result["synced"]
    return result


def pending_sync(limit: int) -> list[dict]:
    with database() as c:
        return [
            dict(row)
            for row in c.execute(
                "SELECT * FROM news_items WHERE feishu_record_id IS NULL "
                "ORDER BY first_collected_at DESC,id LIMIT ?",
                (limit,),
            ).fetchall()
        ]


def record_sync(news_id: str, record_id: str | None, error: str | None) -> None:
    with database() as c:
        c.execute(
            "UPDATE news_items SET feishu_record_id=COALESCE(?,feishu_record_id),"
            "feishu_synced_at=CASE WHEN ? IS NOT NULL THEN ? ELSE feishu_synced_at END,"
            "feishu_sync_error=? WHERE id=?",
            (record_id, record_id, utc_now(), error, news_id),
        )


def state_value(key: str) -> str | None:
    with database() as c:
        row = c.execute("SELECT state_value FROM system_state WHERE state_key=?", (key,)).fetchone()
    return row[0] if row else None


def set_state(key: str, value: str) -> None:
    with database() as c:
        c.execute(
            "INSERT INTO system_state(state_key,state_value) VALUES (?,?) "
            "ON CONFLICT(state_key) DO UPDATE SET state_value=excluded.state_value,"
            "updated_at=CURRENT_TIMESTAMP",
            (key, value),
        )
