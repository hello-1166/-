from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from threading import Lock
from uuid import NAMESPACE_URL, uuid5

from radar.news.store import database, set_state, state_value, utc_now
from radar.selection.config import settings
from radar.selection.ranking import likely_same_event, rank

SCREEN_LOCK = Lock()


def screen(now: datetime | None = None) -> dict:
    if not SCREEN_LOCK.acquire(blocking=False):
        return {"status": "busy"}
    try:
        now = now or datetime.now(UTC)
        cfg = settings()
        cutoff = now - timedelta(days=cfg.lookback_days)
        with database() as c:
            rows = [
                dict(row)
                for row in c.execute(
                    "SELECT * FROM news_items WHERE COALESCE(published_at,first_collected_at)>=? "
                    "ORDER BY COALESCE(published_at,first_collected_at) DESC,id LIMIT ?",
                    (cutoff.isoformat(), cfg.max_items),
                )
            ]
            # Keep existing memberships and human decisions stable on reruns.
            memberships = dict(c.execute("SELECT news_id,topic_id FROM editorial_members"))
            anchors = [
                dict(r)
                for r in c.execute(
                    "SELECT id,title,published_at FROM editorial_topics "
                    "WHERE published_at>=? ORDER BY "
                    "created_at,id",
                    (cutoff.isoformat(),),
                )
            ]
            for item in rows:
                if item["id"] in memberships:
                    continue
                match = next(
                    (
                        a
                        for a in anchors
                        if item["published_at"]
                        and a.get("published_at")
                        and abs(
                            (
                                datetime.fromisoformat(a["published_at"])
                                - datetime.fromisoformat(item["published_at"])
                            ).total_seconds()
                        )
                        <= 172800
                        and likely_same_event(a["title"], item["title"], cfg.cluster_similarity)
                    ),
                    None,
                )
                tid = (
                    match["id"] if match else str(uuid5(NAMESPACE_URL, "radar-topic:" + item["id"]))
                )
                if not match:
                    c.execute(
                        "INSERT INTO editorial_topics(id,anchor_news_id,title,"
                        "published_at,expires_at,score,"
                        "analysis_json,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
                        (
                            tid,
                            item["id"],
                            item["title"],
                            item["published_at"],
                            now.isoformat(),
                            0,
                            "{}",
                            now.isoformat(),
                            now.isoformat(),
                        ),
                    )
                    anchors.append(
                        {"id": tid, "title": item["title"], "published_at": item["published_at"]}
                    )
                c.execute(
                    "INSERT INTO editorial_members(news_id,topic_id) VALUES (?,?)",
                    (item["id"], tid),
                )
                memberships[item["id"]] = tid
            c.execute("UPDATE editorial_topics SET recommended=0,active=0")
            eligible = []
            for tid in sorted({memberships[item["id"]] for item in rows}):
                # Use the original anchor as headline; grouping does not amplify score or freshness.
                anchor = c.execute(
                    "SELECT n.* FROM editorial_topics t JOIN news_items n ON n.id=t.anchor_news_id "
                    "WHERE t.id=?",
                    (tid,),
                ).fetchone()
                value = rank(dict(anchor), now)
                try:
                    published = datetime.fromisoformat(anchor["published_at"] or "")
                    expires = published + timedelta(days=cfg.lookback_days)
                except ValueError:
                    expires = now - timedelta(seconds=1)
                value["audience"] = cfg.audience
                c.execute(
                    "UPDATE editorial_topics SET score=?,analysis_json=?,published_at=?,"
                    "expires_at=?,active=1,updated_at=? WHERE id=?",
                    (
                        value["score"],
                        json.dumps(value, ensure_ascii=False),
                        anchor["published_at"],
                        expires.isoformat(),
                        now.isoformat(),
                        tid,
                    ),
                )
                if (
                    value["timely"]
                    and expires >= now
                    and value["score"] >= cfg.recommendation_threshold
                ):
                    eligible.append((value["score"], tid))
            # Ignored/selected topics must not consume the pending recommendation slots.
            pending = {
                r[0] for r in c.execute("SELECT id FROM editorial_topics WHERE decision='pending'")
            }
            picks = [tid for _, tid in sorted(eligible, reverse=True) if tid in pending][
                : cfg.recommendation_limit
            ]
            c.executemany(
                "UPDATE editorial_topics SET recommended=1 WHERE id=?", [(t,) for t in picks]
            )
        result = {
            "status": "completed",
            "considered": len(rows),
            "topics": len({memberships[item["id"]] for item in rows}),
            "recommended": len(picks),
            "finished_at": utc_now(),
            "bounded": len(rows) == cfg.max_items,
        }
        set_state("editorial_last_screen", json.dumps(result))
        return result
    finally:
        SCREEN_LOCK.release()


def last_screen() -> dict | None:
    value = state_value("editorial_last_screen")
    return json.loads(value) if value else None
