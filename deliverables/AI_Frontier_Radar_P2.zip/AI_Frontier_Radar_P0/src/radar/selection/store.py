from __future__ import annotations

import json
from datetime import datetime
from zoneinfo import ZoneInfo

from radar.news.store import database, utc_now


def decode(row) -> dict:
    item = dict(row)
    for key in ("analysis", "model"):
        raw = item.pop(key + "_json", None)
        item[key] = json.loads(raw) if raw else None
    return item


def topic(topic_id: str) -> dict | None:
    with database() as c:
        row = c.execute("SELECT * FROM editorial_topics WHERE id=?", (topic_id,)).fetchone()
        if not row:
            return None
        item = decode(row)
        item["articles"] = [
            dict(r)
            for r in c.execute(
                "SELECT n.id,n.title,n.original_url,n.source_name,n.published_at,n.summary "
                "FROM editorial_members m JOIN news_items n ON n.id=m.news_id "
                "WHERE m.topic_id=? ORDER BY n.first_collected_at,n.id",
                (topic_id,),
            )
        ]
    return item


def listing(limit: int, offset: int, status: str | None, query: str, now: str) -> dict:
    where = " WHERE 1=1" if status in {"selected", "ignored"} else " WHERE t.active=1"
    args = []
    if status == "recommended":
        where += " AND t.recommended=1 AND t.decision='pending' AND t.expires_at>=?"
        args.append(now)
    elif status:
        where += " AND t.decision=?"
        args.append(status)
    if query:
        where += " AND t.title LIKE ? ESCAPE '\\'"
        args.append("%" + query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
    with database() as c:
        total = c.execute("SELECT count(*) FROM editorial_topics t" + where, args).fetchone()[0]
        rows = c.execute(
            "SELECT id FROM editorial_topics t"
            + where
            + " ORDER BY t.score DESC,t.published_at DESC,t.id LIMIT ? OFFSET ?",
            args + [limit, offset],
        ).fetchall()
    return {
        "total": total,
        "items": [topic(row[0]) for row in rows],
        "limit": limit,
        "offset": offset,
    }


def decide(topic_id: str, decision: str) -> dict | None:
    with database() as c:
        c.execute(
            "UPDATE editorial_topics SET decision=?,updated_at=? WHERE id=?",
            (decision, utc_now(), topic_id),
        )
    return topic(topic_id)


def usage() -> dict:
    day = datetime.now(ZoneInfo("Asia/Shanghai")).date().isoformat()
    with database() as c:
        row = c.execute(
            "SELECT count(*) AS requests,COALESCE(sum(input_tokens),0) AS input_tokens,"
            "COALESCE(sum(output_tokens),0) AS output_tokens FROM "
            "editorial_model_calls WHERE day=?",
            (day,),
        ).fetchone()
        history = [
            dict(r)
            for r in c.execute(
                "SELECT id,provider,model_id,status,error_code,started_at,"
                "input_tokens,output_tokens "
                "FROM editorial_model_calls ORDER BY started_at DESC LIMIT 10"
            )
        ]
    return {"day": day, **dict(row), "recent": history}
