SCHEMA_VERSION = "2"
STATEMENTS = [
    """CREATE TABLE IF NOT EXISTS news_items (
        id TEXT PRIMARY KEY, canonical_url TEXT NOT NULL UNIQUE,
        title TEXT NOT NULL, original_url TEXT NOT NULL,
        source_id TEXT NOT NULL, source_name TEXT NOT NULL,
        language TEXT NOT NULL, category TEXT NOT NULL, summary TEXT NOT NULL,
        published_at TEXT, published_at_raw TEXT NOT NULL,
        first_collected_at TEXT NOT NULL, last_seen_at TEXT NOT NULL,
        review_status TEXT NOT NULL DEFAULT 'pending_review',
        feishu_record_id TEXT, feishu_synced_at TEXT, feishu_sync_error TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS news_origins (
        news_id TEXT NOT NULL REFERENCES news_items(id),
        source_id TEXT NOT NULL, source_name TEXT NOT NULL, entry_id TEXT NOT NULL,
        original_url TEXT NOT NULL, first_seen_at TEXT NOT NULL, last_seen_at TEXT NOT NULL,
        PRIMARY KEY (news_id, source_id)
    )""",
    """CREATE TABLE IF NOT EXISTS feed_state (
        source_id TEXT PRIMARY KEY, etag TEXT, last_modified TEXT, next_allowed_at TEXT,
        last_checked_at TEXT, last_status TEXT, last_error TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS ingestion_runs (
        id TEXT PRIMARY KEY, started_at TEXT NOT NULL, finished_at TEXT,
        status TEXT NOT NULL, details_json TEXT NOT NULL DEFAULT '[]',
        seen INTEGER NOT NULL DEFAULT 0, inserted INTEGER NOT NULL DEFAULT 0,
        duplicates INTEGER NOT NULL DEFAULT 0, skipped INTEGER NOT NULL DEFAULT 0,
        errors INTEGER NOT NULL DEFAULT 0
    )""",
    "CREATE INDEX IF NOT EXISTS news_collected_idx ON news_items(first_collected_at DESC)",
]

STATEMENTS += [
    """CREATE TABLE IF NOT EXISTS editorial_topics (
        id TEXT PRIMARY KEY, anchor_news_id TEXT NOT NULL REFERENCES news_items(id),
        title TEXT NOT NULL, published_at TEXT,
        expires_at TEXT NOT NULL, score INTEGER NOT NULL,
        recommended INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1, decision TEXT NOT NULL DEFAULT 'pending',
        analysis_json TEXT NOT NULL, model_json TEXT,
        created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS editorial_members (
        news_id TEXT PRIMARY KEY REFERENCES news_items(id),
        topic_id TEXT NOT NULL REFERENCES editorial_topics(id)
    )""",
    """CREATE TABLE IF NOT EXISTS editorial_model_calls (
        id TEXT PRIMARY KEY, topic_id TEXT NOT NULL, fingerprint TEXT NOT NULL,
        day TEXT NOT NULL, provider TEXT NOT NULL, model_id TEXT NOT NULL,
        started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL,
        error_code TEXT, input_tokens INTEGER, output_tokens INTEGER
    )""",
    "CREATE INDEX IF NOT EXISTS editorial_member_topic ON editorial_members(topic_id)",
    "CREATE INDEX IF NOT EXISTS editorial_call_day ON editorial_model_calls(day)",
]
SCHEMA_VERSION = "3"
