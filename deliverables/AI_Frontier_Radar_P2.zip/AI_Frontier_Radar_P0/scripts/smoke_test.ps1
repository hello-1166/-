param(
    [string]$ApiBaseUrl = "http://localhost:8000",
    [string]$N8nBaseUrl = "http://localhost:5678"
)
$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot

Push-Location $ProjectRoot
try {
    Write-Host "Checking Docker Compose configuration..."
    docker compose config --quiet
    if ($LASTEXITCODE -ne 0) { throw "Docker Compose configuration failed." }

    Write-Host "Checking running services..."
    $services = @(docker compose ps --status running --services)
    if ($LASTEXITCODE -ne 0) { throw "Docker Compose status failed." }
    foreach ($service in @("api", "n8n")) {
        if ($services -notcontains $service) { throw "Service is not running: $service" }
    }

    $health = Invoke-RestMethod "$ApiBaseUrl/health" -TimeoutSec 10
    if ($health.status -ne "healthy" -or $health.service -ne "radar-api") {
        throw "API health check failed."
    }
    $ready = Invoke-RestMethod "$ApiBaseUrl/ready" -TimeoutSec 10
    if ($ready.status -ne "ready" -or $ready.database -ne "ready") {
        throw "API readiness check failed."
    }
    foreach ($path in @(
        "/api/v1/system/config-status",
        "/api/v1/llm/providers",
        "/api/v1/integrations/feishu/status",
        "/docs",
        "/radar",
        "/api/v1/news/stats",
        "/topics",
        "/api/v1/selection/status"
    )) {
        Invoke-WebRequest "$ApiBaseUrl$path" -UseBasicParsing -TimeoutSec 10 | Out-Null
    }
    Invoke-WebRequest "$N8nBaseUrl/healthz" -UseBasicParsing -TimeoutSec 10 | Out-Null
    Invoke-WebRequest "$N8nBaseUrl/" -UseBasicParsing -TimeoutSec 10 | Out-Null
    Write-Host "Checking n8n to API connectivity..."
    docker compose exec -T n8n node -e "fetch('http://api:8000/ready').then(async r=>{const b=await r.json();process.exit(r.ok&&b.status==='ready'&&b.database==='ready'?0:1)}).catch(()=>process.exit(1))"
    if ($LASTEXITCODE -ne 0) { throw "n8n cannot reach the API readiness endpoint." }
    Write-Host "Radar smoke tests passed."
} finally {
    Pop-Location
}
