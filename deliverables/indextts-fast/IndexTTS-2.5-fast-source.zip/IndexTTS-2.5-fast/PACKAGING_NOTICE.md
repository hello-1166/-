# IndexTTS-2.5 minimal source transport package

Upstream: https://github.com/index-tts/index-tts
Pinned source commit: d9e41aac89fd00b3d71497fddb287b7f24613712

All retained upstream files are byte-for-byte unchanged and verified against their upstream Git blob hashes. The original LICENSE and copyright notices are retained. Use remains governed by the upstream bilibili Model Use License Agreement.

Packaging changes: omitted Git metadata/CI, documentation, tests, promotional images/videos, and the bundled facodec JDC bst.t7 file. The packaged inference source has no direct reference to that bundled path; its F0 downloader code is unchanged. This is an inference source transport package, not a full development checkout and not a model-weight distribution. Required model weights and examples are downloaded separately by the upstream utilities.

Any modifications made to the original model in this Derivative Work are not endorsed, warranted, or guaranteed by the original right-holder of the original model, and the original right-holder disclaims all liability related to this Derivative Work.

Checks: upstream file hashes, Python syntax, required WebUI/config/build files, and ZIP integrity. No Windows GPU execution test has been performed here.
