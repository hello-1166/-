import json

import httpx
import pytest
from fastapi.testclient import TestClient
from test_p1_ingestion import rss, source

from radar.core.database import initialize_database
from radar.main import app
from radar.news import ingestion, store
from radar.news.config import IngestionSettings, Source, sources
from radar.news.parser import parse_feed
from radar.news.webpages import article, collect_html


def html_source():
    return source().model_copy(
        update={"collection_method": "html", "article_path_prefix": "/news/"}
    )


def test_registry_is_broad_and_source_methods_valid():
    rows = sources()
    active = [s for s in rows if s.enabled]
    assert len(active) >= 20
    assert {"media", "research", "official_company", "developer_ecosystem", "creator"} <= {
        s.category for s in active
    }
    assert any(s.language == "zh" for s in active)
    assert any(s.collection_method == "html" for s in active)
    assert any(not s.enabled and s.verification_note for s in rows)


def test_initial_backfill_then_delayed_news_and_selection_independent(monkeypatch):
    initialize_database()
    monkeypatch.setattr(ingestion, "sources", lambda: [source()])
    with httpx.Client(
        transport=httpx.MockTransport(lambda r: httpx.Response(200, content=rss(days=30)))
    ) as c:
        first = ingestion.run_ingestion(client=c)
        assert first["inserted"] == 0 and first["skipped"] == 1
        again = ingestion.run_ingestion(client=c)
        assert again["inserted"] == 0
    # A newly appearing, delayed publication is retained, without a score threshold.
    with httpx.Client(
        transport=httpx.MockTransport(
            lambda r: httpx.Response(200, content=rss(link="https://example.test/delayed", days=30))
        )
    ) as c:
        second = ingestion.run_ingestion(client=c)
        assert second["inserted"] == 1
    assert store.stats()["total"] == 1
    detail = json.loads(store.state_value("ingestion_detail:SRC_TEST_A"))
    assert detail["seen"] == 1 and not detail["truncated"]


def test_cap_reports_potential_missing_items(monkeypatch):
    initialize_database()
    monkeypatch.setattr(ingestion, "sources", lambda: [source()])
    monkeypatch.setattr(ingestion, "settings", lambda: IngestionSettings(max_entries_per_source=1))
    a = rss().decode()
    body = a.replace(
        "</channel>",
        rss(link="https://example.test/b")
        .decode()
        .split("<item>")[1]
        .split("</channel>")[0]
        .join(["<item>", "</channel>"]),
    )
    with httpx.Client(
        transport=httpx.MockTransport(lambda r: httpx.Response(200, content=body))
    ) as c:
        result = ingestion.run_ingestion(client=c)
    assert result["sources"][0]["truncated"]


def test_web_metadata_uses_original_publication_not_modified():
    row = article(
        b"""<title>Fallback</title>
<meta property="article:modified_time" content="2026-01-01T00:00:00Z">
<script type="application/ld+json">
{"@type":"NewsArticle","headline":"New tool","description":"Original",
"datePublished":"2026-01-02T01:00:00Z"}</script>""",
        "https://example.test/news/tool",
        html_source(),
        1200,
    )
    assert row["published_at"] == "2026-01-02T01:00:00+00:00"
    assert row["summary"] == "Original"
    unknown = article(
        b"<title>Unknown date</title>"
        b'<meta property="article:modified_time" content="2026-01-01T00:00:00Z">',
        "https://example.test/news/unknown",
        html_source(),
        1200,
    )
    assert unknown["published_at"] is None


def test_html_respects_robots_and_stays_inside_news_path(monkeypatch):
    monkeypatch.setattr("radar.news.webpages.time.sleep", lambda s: None)
    calls = []

    def handle(r):
        calls.append(str(r.url))
        if r.url.path == "/robots.txt":
            return httpx.Response(200, text="User-agent: *\nDisallow: /news/private\n")
        if r.url.path == "/SRC_TEST_A":
            return httpx.Response(
                200,
                text=(
                    '<a href="/news/tool">tool</a><a href="/news/private">private</a>'
                    '<a href="https://evil.test/news/x">outside</a><a href="/pricing">nav</a>'
                ),
            )
        return httpx.Response(200, text="<title>AI tool</title>")

    with httpx.Client(transport=httpx.MockTransport(handle)) as c:
        rows, cache = collect_html(c, html_source(), IngestionSettings(), {}, ingestion.fetch_feed)
    assert len(rows) == 1 and rows[0]["title"] == "AI tool"
    assert calls == [
        "https://example.test/robots.txt",
        "https://example.test/SRC_TEST_A",
        "https://example.test/news/tool",
    ]
    assert not cache["_listing_truncated"]


def test_html_blocked_robots_does_not_fetch_listing(monkeypatch):
    calls = []

    def handle(r):
        calls.append(r.url.path)
        return httpx.Response(200, text="User-agent: *\nDisallow: /\n")

    with httpx.Client(transport=httpx.MockTransport(handle)) as c:
        with pytest.raises(ingestion.FeedFailure, match="robots_disallowed"):
            collect_html(c, html_source(), IngestionSettings(), {}, ingestion.fetch_feed)
    assert calls == ["/robots.txt"]


def test_time_and_source_type_filters_keep_historical_and_unknown(monkeypatch):
    initialize_database()
    media = source().model_copy(update={"category": "media"})
    research = source("SRC_TEST_B").model_copy(update={"category": "research"})
    monkeypatch.setattr("radar.news.config.sources", lambda: [media, research])
    store.save_items(parse_feed(rss(), media, 1000), store.utc_now())
    store.save_items(
        parse_feed(rss(link="https://example.test/old", days=10), research, 1000), store.utc_now()
    )
    store.save_items(
        parse_feed(rss(link="https://example.test/unknown", published=False), media, 1000),
        store.utc_now(),
    )
    assert store.news(30, 0, None, "", None, hours=24)["total"] == 1
    assert store.news(30, 0, None, "", None, source_category="media")["total"] == 2
    assert store.news(30, 0, None, "", None)["total"] == 3
    assert store.news(30, 0, None, "", None, source_category="no_such_category")["total"] == 0
    with TestClient(app) as c:
        assert c.get("/api/v1/news?hours=0").status_code == 422
        assert c.get("/api/v1/news?source_category=media&hours=24").json()["total"] == 1


@pytest.mark.parametrize(
    "url", ["https://localhost/rss", "https://127.0.0.1/rss", "https://10.0.0.2/rss"]
)
def test_private_source_endpoints_rejected(url):
    with pytest.raises(ValueError):
        Source(**{**source().model_dump(), "rss_url": url})


def test_general_feed_title_filter_ignores_ai_footer(monkeypatch):
    initialize_database()
    row = source().model_copy(update={"relevance_terms": ["ai"], "relevance_scope": "title"})
    monkeypatch.setattr(ingestion, "sources", lambda: [row])
    doc = rss().replace(b"AI &amp; research", b"Company financial report")
    doc = doc.replace(b"Original summary", b"Original summary. Try our AI assistant")
    with httpx.Client(
        transport=httpx.MockTransport(lambda r: httpx.Response(200, content=doc))
    ) as c:
        result = ingestion.run_ingestion(client=c)
    assert result["inserted"] == 0 and result["non_ai"] == 1
