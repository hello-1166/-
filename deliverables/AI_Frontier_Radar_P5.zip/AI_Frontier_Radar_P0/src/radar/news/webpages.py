"""Bounded public news-page discovery; no login, browser or unrestricted crawl."""

from __future__ import annotations

import json
import time
from datetime import UTC, datetime
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit
from urllib.robotparser import RobotFileParser
from uuid import NAMESPACE_URL, uuid5

from radar.news.config import IngestionSettings, Source
from radar.news.parser import canonical_url, plain_text


class Page(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.meta = {}
        self.title = []
        self.in_title = False
        self.json_blocks = []
        self.block = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "a" and a.get("href"):
            self.links.append(a["href"])
        if tag == "meta":
            self.meta[a.get("property", a.get("name", "")).lower()] = a.get("content", "")
        if tag == "title":
            self.in_title = True
        if tag == "script" and a.get("type") == "application/ld+json":
            self.block = []

    def handle_endtag(self, tag):
        if tag == "title":
            self.in_title = False
        if tag == "script" and self.block is not None:
            self.json_blocks.append("".join(self.block))
            self.block = None

    def handle_data(self, data):
        if self.in_title:
            self.title.append(data)
        if self.block is not None:
            self.block.append(data)


def published_time(value):
    if not value:
        return None
    try:
        d = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        # Do not invent a timezone for a date or naive timestamp.
        return d.astimezone(UTC).isoformat() if d.tzinfo else None
    except ValueError:
        return None


def article(data: bytes, url: str, source: Source, limit: int) -> dict | None:
    page = Page()
    page.feed(data.decode("utf-8", errors="replace"))
    title = page.meta.get("og:title") or " ".join(page.title)
    summary = page.meta.get("og:description") or page.meta.get("description", "")
    raw_date = page.meta.get("article:published_time", "")
    for block in page.json_blocks:
        try:
            value = json.loads(block)
        except ValueError:
            continue
        todo = value if isinstance(value, list) else [value]
        for obj in todo[:100]:
            if not isinstance(obj, dict):
                continue
            if isinstance(obj.get("@graph"), list):
                todo.extend(obj["@graph"][:30])
            kind = obj.get("@type", "")
            if kind in ("Article", "NewsArticle", "BlogPosting"):
                title = obj.get("headline") or title
                summary = obj.get("description") or summary
                raw_date = obj.get("datePublished") or raw_date
    if not title or not isinstance(title, str):
        return None
    canonical = canonical_url(url)
    return dict(
        id=str(uuid5(NAMESPACE_URL, canonical)),
        canonical_url=canonical,
        original_url=url,
        source_id=source.source_id,
        source_name=source.name,
        language=source.language,
        category=source.category,
        title=plain_text(title, 500),
        summary=plain_text(str(summary), limit),
        published_at=published_time(raw_date),
        published_at_raw=str(raw_date)[:200],
        entry_id=canonical,
    )


def collect_html(client, source: Source, config: IngestionSettings, state: dict, fetch):
    from radar.news.ingestion import FeedFailure

    base = urlsplit(source.rss_url)
    robots_url = f"https://{base.netloc}/robots.txt"
    policy = RobotFileParser()
    try:
        rules, _ = fetch(client, source.model_copy(update={"rss_url": robots_url}), config, {})
        policy.parse((rules or b"").decode("utf-8", errors="replace").splitlines())
    except FeedFailure as exc:
        if exc.code == "http_404":
            policy.parse([])
        else:
            raise FeedFailure("robots_unavailable") from None
    if not policy.can_fetch(config.user_agent, source.rss_url):
        raise FeedFailure("robots_disallowed")
    delay = max(config.html_interval_seconds, policy.crawl_delay(config.user_agent) or 0)
    if delay > 30:
        raise FeedFailure("robots_delay_too_long")
    time.sleep(delay)
    data, cache = fetch(client, source, config, state)
    if data is None:
        return None, cache
    page = Page()
    page.feed(data.decode("utf-8", errors="replace"))
    urls = []
    prefix = source.article_path_prefix
    for link in page.links:
        target = urljoin(source.rss_url, link)
        p = urlsplit(target)
        if (
            p.scheme != "https"
            or p.netloc != base.netloc
            or p.username
            or p.password
            or p.query
            or not prefix
            or not p.path.startswith(prefix)
        ):
            continue
        slug = p.path[len(prefix) :].strip("/")
        if not slug or "/" in slug or slug in {"announcements", "features", "rss", "feed"}:
            continue
        target = canonical_url(target)
        if target not in urls and policy.can_fetch(config.user_agent, target):
            urls.append(target)
    if not urls:
        raise FeedFailure("no_article_links")
    # No cache validators: articles may change while the listing stays identical.
    entries = []
    for url in urls[: config.max_html_articles]:
        time.sleep(delay)
        try:
            raw, _ = fetch(client, source.model_copy(update={"rss_url": url}), config, {})
        except FeedFailure:
            # Do not cache a partially scanned listing; preserve host rate-limit handling.
            raise
        row = article(raw or b"", url, source, config.summary_max_characters)
        if row:
            entries.append(row)
    if not entries:
        raise FeedFailure("no_article_metadata")
    return entries, {"_listing_truncated": len(urls) > config.max_html_articles}
