from __future__ import annotations

import ipaddress
from typing import Literal
from urllib.parse import urlsplit

from pydantic import BaseModel, Field, field_validator

from radar.core.config import load_yaml


class Source(BaseModel):
    source_id: str = Field(pattern=r"^[A-Z][A-Z0-9_]{2,60}$")
    name: str = Field(min_length=1, max_length=100)
    category: str
    language: str
    rss_url: str
    collection_method: Literal["rss", "html"] = "rss"
    article_path_prefix: str = ""
    relevance_scope: Literal["title", "title_summary"] = "title_summary"
    relevance_terms: list[str] = Field(default_factory=list)
    website: str
    enabled: bool = False
    priority: str = "A"
    verification_note: str = ""

    @field_validator("rss_url")
    @classmethod
    def public_https_feed(cls, value: str) -> str:
        parsed = urlsplit(value)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Feeds must use HTTPS without URL credentials")
        host = parsed.hostname.lower()
        if host == "localhost" or host.endswith((".local", ".internal")):
            raise ValueError("Feed must use a public host")
        try:
            address = ipaddress.ip_address(host)
        except ValueError:
            address = None
        if address is not None and not address.is_global:
            raise ValueError("Feed must use a public host")
        return value


class IngestionSettings(BaseModel):
    timeout_seconds: int = Field(default=12, ge=1, le=60)
    max_feed_bytes: int = Field(default=2_000_000, ge=1000, le=5_000_000)
    max_entries_per_source: int = Field(default=100, ge=1, le=5000)
    max_html_articles: int = Field(default=10, ge=1, le=30)
    html_interval_seconds: float = Field(default=1, ge=1, le=30)
    lookback_days: int = Field(default=7, ge=1, le=90)
    summary_max_characters: int = Field(default=1200, ge=0, le=3000)
    network_retries: int = Field(default=1, ge=0, le=2)
    user_agent: str = "AI-Frontier-Radar/0.2 (personal RSS reader)"


def sources() -> list[Source]:
    config = load_yaml("source_registry.yaml")
    rows = config.get("sources")
    if not isinstance(rows, list):
        raise ValueError("Source registry must contain a list")
    result = [Source.model_validate(row) for row in rows]
    if len({source.source_id for source in result}) != len(result):
        raise ValueError("Source IDs must be unique")
    return result


def settings() -> IngestionSettings:
    return IngestionSettings.model_validate(load_yaml("ingestion.yaml"))
