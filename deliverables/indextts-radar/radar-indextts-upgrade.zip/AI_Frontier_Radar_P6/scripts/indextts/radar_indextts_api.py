"""Local Gradio extension. Uses the existing loaded IndexTTS model; no new model process."""

from __future__ import annotations

import json
import math
import re
from pathlib import Path
from uuid import uuid4


def preset_data(root: Path, name: str) -> tuple[dict, Path]:
    if not isinstance(name, str) or not name.strip() or len(name) > 60:
        raise ValueError("Invalid preset name")
    if re.search(r'[\\/:*?"<>|\x00-\x1f.]', name):
        raise ValueError("Use the saved preset name, not a file path")
    safe = re.sub(r"\s+", "_", name.strip()).strip(". _")
    base = (root / "outputs/presets").resolve()
    folder = (base / safe).resolve()
    if not folder.is_relative_to(base) or folder == base:
        raise ValueError("Invalid preset directory")
    path = folder / "preset.json"
    if not path.is_file() or path.stat().st_size > 64000:
        raise ValueError("Preset not found. Save the voice preset in IndexTTS first.")
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    for key in ("prompt_audio", "emo_audio"):
        if value.get(key):
            audio = (folder / value[key]).resolve()
            if not audio.is_relative_to(folder) or not audio.is_file():
                raise ValueError("Preset audio missing or outside preset directory")
            value[key] = str(audio)
    if not value.get("prompt_audio"):
        raise ValueError("Preset has no reference audio")
    return value, folder


def number(value: object, low: float, high: float) -> float:
    value = float(value)
    if not math.isfinite(value) or not low <= value <= high:
        raise ValueError("Preset parameter outside supported bounds")
    return value


def synthesize(tts, root: Path, name: str, text: str, factor: float) -> str:
    if not isinstance(text, str) or not text.strip() or len(text) > 180:
        raise ValueError("Speech chunk must contain 1-180 characters")
    data, _ = preset_data(root, name)
    mode = int(data.get("emo_control_method", 0))
    if mode not in (0, 1, 2):
        raise ValueError(
            "Use speaker/reference/vector emotion mode; text emotion needs extra GPU memory"
        )
    advanced = data.get("advanced_params", {})
    bounds = {
        "top_p": (0.8, 0.01, 1),
        "temperature": (0.8, 0.1, 2),
        "length_penalty": (0, -2, 2),
        "repetition_penalty": (10, 0.1, 30),
        "max_text_tokens_per_segment": (120, 20, 200),
        "num_beams": (3, 1, 5),
        "max_mel_tokens": (1500, 100, 2400),
        "top_k": (30, 0, 100),
    }
    kwargs = {
        k: number(advanced.get(k, default), low, high) for k, (default, low, high) in bounds.items()
    }
    for key in ("max_text_tokens_per_segment", "num_beams", "max_mel_tokens", "top_k"):
        kwargs[key] = int(kwargs[key])
    kwargs["top_k"] = kwargs["top_k"] or None
    vector = None
    if mode == 2:
        raw = data.get("emo_vector", [0] * 8)
        if len(raw) != 8:
            raise ValueError("Expected eight emotion values")
        vector = tts.normalize_emo_vec([number(v, 0, 1.5) for v in raw], apply_bias=True)
    emotion_audio = data.get("emo_audio") if mode == 1 else None
    if mode == 1 and not emotion_audio:
        raise ValueError("Emotion reference audio missing")
    folder = root / "outputs/radar-api"
    folder.mkdir(parents=True, exist_ok=True)
    output = folder / (uuid4().hex + ".wav")
    try:
        tts.infer(
            spk_audio_prompt=data["prompt_audio"],
            text=text,
            output_path=str(output),
            lang="ZH",
            duration_factor=number(factor, 0.8, 1.2),
            emo_audio_prompt=emotion_audio,
            emo_alpha=number(data.get("emo_weight", 0.65), 0, 1),
            emo_vector=vector,
            use_emo_text=False,
            emo_text=None,
            use_random=bool(data.get("emo_random", False)),
            do_sample=bool(advanced.get("do_sample", True)),
            verbose=False,
            **kwargs,
        )
        if not output.is_file() or output.stat().st_size < 44:
            raise ValueError("IndexTTS returned no WAV audio")
        return str(output)
    except BaseException:
        output.unlink(missing_ok=True)
        raise


def attach(tts, root: Path) -> None:
    import gradio as gr

    name = gr.Textbox(visible=False)
    text = gr.Textbox(visible=False)
    factor = gr.Number(value=1, visible=False)
    output = gr.File(visible=False, type="filepath")
    button = gr.Button(visible=False)

    def release(filename: str) -> str:
        if not re.fullmatch(r"[a-f0-9]{32}\.wav", filename):
            raise ValueError("Invalid generated audio filename")
        (root / "outputs/radar-api" / filename).unlink(missing_ok=True)
        return "released"

    cleanup = gr.Button(visible=False)
    filename = gr.Textbox(visible=False)
    released = gr.Textbox(visible=False)
    cleanup.click(
        release,
        inputs=[filename],
        outputs=[released],
        api_name="radar_release",
        concurrency_id="radar_tts",
        concurrency_limit=1,
    )
    button.click(
        lambda n, t, f: synthesize(tts, root, n, t, f),
        inputs=[name, text, factor],
        outputs=output,
        api_name="radar_synthesize",
        concurrency_id="radar_tts",
        concurrency_limit=1,
    )
