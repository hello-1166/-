"""Install a reviewed, idempotent local API extension without replacing the user's WebUI."""

from __future__ import annotations

import argparse
import ast
import hashlib
import shutil
from pathlib import Path
from uuid import uuid4

MARKER = "# RADAR_LOCAL_SPEECH_API_V1"


def patch(root: Path, source: Path) -> Path:
    path = root / "webui.py"
    text = path.read_text(encoding="utf-8-sig")
    helper = root / "radar_indextts_api.py"
    payload = (source / helper.name).read_bytes()
    if helper.exists() and helper.read_bytes() != payload:
        raise ValueError("Existing custom radar_indextts_api.py needs review; no files changed")
    if MARKER in text:
        if helper.exists() and helper.read_bytes() == payload:
            return path
        raise ValueError("Incomplete previous patch; restore webui.py backup before retrying")
    anchor = "    gen_button.click(gen_single,"
    end = "outputs=[output_audio])"
    if text.count(anchor) != 1 or text.count(end) != 1:
        raise ValueError("Unknown WebUI layout; no files changed")
    updated = text.replace(
        anchor,
        "    " + MARKER + "\n"
        "    from radar_indextts_api import attach as radar_attach\n"
        "    from pathlib import Path as RadarPath\n"
        '    if cmd_args.host not in ("127.0.0.1", "localhost", "::1") or cmd_args.share:\n'
        '        raise ValueError("Radar integration requires --host 127.0.0.1 and no --share")\n'
        "    radar_attach(tts, RadarPath(__file__).resolve().parent)\n\n" + anchor,
    )
    updated = updated.replace(
        end, 'outputs=[output_audio], concurrency_id="radar_tts", concurrency_limit=1)'
    )
    ast.parse(updated)
    ast.parse(payload.decode())
    backup = root / ("webui.py.radar-backup-" + uuid4().hex[:8])
    shutil.copy2(path, backup)
    try:
        helper.write_bytes(payload)
        temporary = root / ("webui-radar-" + uuid4().hex + ".tmp")
        temporary.write_text(updated, encoding="utf-8")
        temporary.replace(path)
    except BaseException:
        shutil.copy2(backup, path)
        helper.unlink(missing_ok=True)
        raise
    print("WebUI backup: " + str(backup))
    print("Extension SHA256: " + hashlib.sha256(payload).hexdigest())
    return path


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    patch(args.root.resolve(), Path(__file__).resolve().parent)
    print("Local speech API installed. Restart IndexTTS with --host 127.0.0.1")
