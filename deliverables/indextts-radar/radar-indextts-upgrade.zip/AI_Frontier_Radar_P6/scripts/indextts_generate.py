"""Windows worker bridge: local Gradio only; never loads model weights itself."""

from __future__ import annotations

import argparse
import json
import math
import re
import tempfile
import urllib.request
import wave
import zipfile
from pathlib import Path
from urllib.parse import urlsplit


def local_url(value: str) -> str:
    address = urlsplit(value)
    if (
        address.scheme != "http"
        or address.hostname not in ("localhost", "127.0.0.1", "::1")
        or address.username
        or address.password
        or address.path not in ("", "/")
        or address.query
        or address.fragment
    ):
        raise ValueError("Use an HTTP loopback service URL without credentials or paths")
    return value.rstrip("/")


def still_armed(base: str, manifest: dict) -> None:
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(base + "/api/v1/videos/" + manifest["job_id"], timeout=15) as response:
        job = json.load(response)
    if (
        job["status"] != "draft"
        or not job["spec"].get("auto_requested")
        or job["spec"].get("automation_token") != manifest.get("automation_token")
    ):
        raise ValueError("Task was cancelled or replaced; no further speech will be generated")


def normalize_audio(source: Path, target: Path) -> float:
    import numpy as np
    import soundfile as sf
    from scipy.signal import resample_poly

    info = sf.info(str(source))
    if (
        source.stat().st_size > 64 * 1024 * 1024
        or not 0 < info.duration <= 120
        or not 1 <= info.channels <= 2
        or not 8000 <= info.samplerate <= 192000
    ):
        raise ValueError("Unexpected audio format or length from IndexTTS")
    audio, rate = sf.read(str(source), dtype="float32", always_2d=True)
    if not np.isfinite(audio).all():
        raise ValueError("Invalid samples in generated speech")
    mono = audio.mean(axis=1)
    if rate != 24000:
        divisor = math.gcd(rate, 24000)
        mono = resample_poly(mono, 24000 // divisor, rate // divisor)
    sf.write(str(target), np.clip(mono, -1, 1), 24000, subtype="PCM_16", format="WAV")
    return len(mono) / 24000


def generate(pack: Path, output: Path, url: str, radar: str, client_factory=None) -> None:
    url, radar = local_url(url), local_url(radar)
    with zipfile.ZipFile(pack) as archive:
        if archive.getinfo("voice-manifest.json").file_size > 200000:
            raise ValueError("Manifest too large")
        manifest_bytes = archive.read("voice-manifest.json")
    manifest = json.loads(manifest_bytes.decode("utf-8-sig"))
    if manifest.get("engine") != "indextts_local" or not manifest.get("automation_token"):
        raise ValueError("Download the current armed IndexTTS task pack")
    if not re.fullmatch("[a-f0-9]{32}", manifest.get("job_id", "")):
        raise ValueError("Invalid task ID")
    chunks = manifest.get("chunks", [])
    names = [c["file"] for c in chunks]
    if (
        not 1 <= len(chunks) <= 300
        or len(set(names)) != len(names)
        or any(not re.fullmatch(r"s[0-9]{2}-c[0-9]{3}\.wav", n) for n in names)
    ):
        raise ValueError("Invalid speech chunk list")
    if client_factory is None:
        from gradio_client import Client

        client_factory = Client
    with tempfile.TemporaryDirectory(prefix="radar-indextts-") as temporary:
        root = Path(temporary)
        cache = root / "downloads"
        cache.mkdir()
        client = client_factory(
            url,
            verbose=False,
            download_files=str(cache),
            httpx_kwargs={"trust_env": False, "timeout": 30},
        )
        total = 0.0
        for i, chunk in enumerate(chunks):
            still_armed(radar, manifest)
            text = chunk["text"]
            if not isinstance(text, str) or not 1 <= len(text) <= 180:
                raise ValueError("Invalid speech text length")
            target = root / chunk["file"]
            print(f"IndexTTS: {i + 1}/{len(chunks)}", flush=True)
            if not any(c.isalnum() for c in text):
                with wave.open(str(target), "wb") as silence:
                    silence.setparams((1, 2, 24000, 0, "NONE", "not compressed"))
                    silence.writeframes(b"\0" * 9600)
                total += 0.2
                continue
            future = client.submit(
                manifest["preset"],
                text,
                manifest.get("duration_factor", 1),
                api_name="/radar_synthesize",
            )
            try:
                source = Path(future.result(timeout=600)).resolve()
            except BaseException:
                future.cancel()
                raise
            if not source.is_relative_to(cache.resolve()) or not source.is_file():
                raise ValueError("Local speech service returned an unexpected file")
            try:
                total += normalize_audio(source, target)
            finally:
                try:
                    client.predict(source.name, api_name="/radar_release")
                except Exception:
                    print(
                        "Warning: speech cache cleanup failed; check outputs/radar-api.",
                        flush=True,
                    )
                source.unlink(missing_ok=True)
            if total > 600:
                raise ValueError("Generated narration exceeds 600 seconds; shorten this episode")
        still_armed(radar, manifest)
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("voice-manifest.json", manifest_bytes)
            for name in names:
                archive.write(root / name, name)
    print("IndexTTS voice result ready.", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--pack", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--url", default="http://127.0.0.1:7860")
    parser.add_argument("--radar", default="http://127.0.0.1:8000")
    args = parser.parse_args()
    generate(args.pack, args.output, args.url, args.radar)
