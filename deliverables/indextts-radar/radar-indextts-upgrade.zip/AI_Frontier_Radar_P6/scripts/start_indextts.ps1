param([string]$IndexTTSRoot='F:\AI_Tools\IndexTTS-2.5-fast')
$ErrorActionPreference='Stop'
$Python=Join-Path $IndexTTSRoot '.venv/Scripts/python.exe'
if (-not (Test-Path -LiteralPath $Python)) { throw 'IndexTTS environment not found. Set -IndexTTSRoot.' }
if (-not (Test-Path -LiteralPath (Join-Path $IndexTTSRoot 'radar_indextts_api.py'))) {
    throw 'Run .\scripts\setup_indextts_bridge.ps1 first.'
}
$env:USE_MODELSCOPE='true'
Push-Location $IndexTTSRoot
try {
    Write-Host 'Keep this window open. Save your voice preset at http://127.0.0.1:7860'
    & $Python webui.py --version 2.5 --host 127.0.0.1 --port 7860 --fp16
    if ($LASTEXITCODE -ne 0) { throw 'IndexTTS stopped with an error; inspect the output above.' }
} finally { Pop-Location }
