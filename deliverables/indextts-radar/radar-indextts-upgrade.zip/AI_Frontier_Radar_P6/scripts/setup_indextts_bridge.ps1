param([string]$IndexTTSRoot='F:\AI_Tools\IndexTTS-2.5-fast')
$ErrorActionPreference='Stop'
$Python=Join-Path $IndexTTSRoot '.venv/Scripts/python.exe'
if (-not (Test-Path -LiteralPath $Python)) { throw 'IndexTTS environment not found. Set -IndexTTSRoot.' }
& $Python (Join-Path $PSScriptRoot 'indextts/patch_webui.py') --root $IndexTTSRoot
if ($LASTEXITCODE -ne 0) { throw 'IndexTTS bridge setup failed. No model download is needed.' }
Write-Host 'Installed. Close the old IndexTTS window with Ctrl+C, then run .\scripts\start_indextts.ps1'
