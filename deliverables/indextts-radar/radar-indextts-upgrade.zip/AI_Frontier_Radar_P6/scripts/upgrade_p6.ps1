﻿param([Parameter(Mandatory=$true)][string]$ExistingProjectPath)
$ErrorActionPreference='Stop'
$SourceRoot=[IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
$TargetRoot=[IO.Path]::GetFullPath((Resolve-Path -LiteralPath $ExistingProjectPath).Path)
if ($SourceRoot -eq $TargetRoot) { throw 'Extract the upgrade to a separate folder.' }
if (-not (Test-Path (Join-Path $TargetRoot 'docker-compose.yml')) -or
    -not (Test-Path (Join-Path $TargetRoot 'src/radar/main.py'))) {
    throw 'Target is not the existing Radar project.'
}
$Manifest=[IO.File]::ReadAllText((Join-Path $SourceRoot 'p6_patch_manifest.json')) | ConvertFrom-Json
$Plan=@()
foreach ($Entry in $Manifest.files.PSObject.Properties) {
    $Relative=$Entry.Name
    if ($Relative -notmatch '^(src/radar/|scripts/|docs/P6_INDEXTTS\.md$|pyproject\.toml$)' -or
        $Relative -match '(^|/)\.\.?(/|$)|\\|:' -or $Relative -match '(^|/)(data|logs|\.env)(/|$)') {
        throw "Forbidden patch path: $Relative"
    }
    $Source=[IO.Path]::GetFullPath((Join-Path $SourceRoot $Relative))
    $Target=[IO.Path]::GetFullPath((Join-Path $TargetRoot $Relative))
    foreach ($Pair in @(@($Source,$SourceRoot),@($Target,$TargetRoot))) {
        if (-not $Pair[0].StartsWith($Pair[1]+[IO.Path]::DirectorySeparatorChar,
            [StringComparison]::OrdinalIgnoreCase)) { throw 'Path escaped project root.' }
    }
    # Stop on symlinks/junctions, including parent directories, before any mutation.
    foreach ($Candidate in @($Source,$Target)) {
        $Current=$Candidate
        while ($Current -and $Current -ne [IO.Path]::GetPathRoot($Current)) {
            if (Test-Path -LiteralPath $Current) {
                if ((Get-Item -LiteralPath $Current -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {
                    throw "Reparse point needs review: $Current"
                }
            }
            $Current=Split-Path -Parent $Current
        }
    }
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf) -or
        (Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Entry.Value) {
        throw "Patch checksum failed: $Relative"
    }
    if (Test-Path -LiteralPath $Target) {
        $Hash=(Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($Hash -eq $Entry.Value) { continue }
        $Known=$Manifest.allowed_hashes.PSObject.Properties[$Relative]
        if (-not $Known -or @($Known.Value) -notcontains $Hash) {
            throw "Locally modified file; no files changed: $Relative"
        }
    }
    $Plan+=@{Relative=$Relative;Source=$Source;Target=$Target}
}
if ($Plan.Count -eq 0) { Write-Host 'IndexTTS integration already installed.'; return }
$Backup=Join-Path $TargetRoot ('backups/p6-code-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8))
New-Item -ItemType Directory -Force -Path $Backup | Out-Null
$Changes=@()
foreach ($Item in $Plan) {
    $Existed=Test-Path -LiteralPath $Item.Target
    $Changes+=@{path=$Item.Relative;existed=$Existed}
    if ($Existed) {
        $Copy=Join-Path $Backup $Item.Relative
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Copy) | Out-Null
        Copy-Item -LiteralPath $Item.Target -Destination $Copy
    }
}
$Changes | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 (Join-Path $Backup 'changes.json')
$Applied=@()
try {
    foreach ($Item in $Plan) {
        $Applied+=$Item
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Item.Target) | Out-Null
        Copy-Item -LiteralPath $Item.Source -Destination $Item.Target -Force
    }
} catch {
    foreach ($Item in $Applied) {
        $Copy=Join-Path $Backup $Item.Relative
        if (Test-Path -LiteralPath $Copy) { Copy-Item -LiteralPath $Copy -Destination $Item.Target -Force }
        elseif (Test-Path -LiteralPath $Item.Target) { Remove-Item -LiteralPath $Item.Target }
    }
    throw
}
Write-Host "P6 IndexTTS integration installed. Backup: $Backup"
Write-Host 'Existing .env, database, models, audio, videos and Docker configuration were preserved.'
Write-Host 'Next: run scripts/start_p0.ps1, then scripts/setup_indextts_bridge.ps1 in the original project.'
