import importlib.util
import io
import json
import shutil
import wave
import zipfile
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
from test_video import create, pcm, plan, voice_zip

from radar.main import app
from radar.video import store
from radar.video.speech import neural_chunks, speech_manifest

ROOT = Path(__file__).parents[1]


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


bridge = module(ROOT / "scripts/indextts_generate.py", "bridge")
extension = module(ROOT / "scripts/indextts/radar_indextts_api.py", "extension")
patcher = module(ROOT / "scripts/indextts/patch_webui.py", "patcher")


def test_local_preset_creation_validation_and_backward_compatibility():
    with TestClient(app) as client:
        status = client.get("/api/v1/videos/status").json()
        assert "indextts_local" in status["voice_modes"]
        assert status["cloud_speech_calls"] is False
        saved = plan(client)
        for preset in ("../voice", "foo/bar", "   ", "a\\b", ".hidden", "a\x00b"):
            assert (
                create(client, saved, voice_mode="indextts_local", voice_preset=preset).status_code
                == 422
            )
        assert create(client, saved, voice_mode="indextts_local", voice_speed=0).status_code == 422
        job = create(client, saved, voice_mode="indextts_local").json()
        manifest = speech_manifest(job)
        assert manifest["engine"] == "indextts_local"
        assert manifest["preset"] == "AI前沿雷达男声"
        pack = client.get(f"/api/v1/videos/{job['id']}/voice-pack")
        with zipfile.ZipFile(io.BytesIO(pack.content)) as archive:
            assert "generate_voice.ps1" not in archive.namelist()
        windows = create(client, saved).json()
        assert set(speech_manifest(windows)) == {"job_id", "script_hash", "chunks"}


def test_change_voice_preserves_files_and_invalidates_old_pack():
    with TestClient(app) as client:
        job = create(client, plan(client)).json()
        endpoint = "/api/v1/videos/" + job["id"]
        original = voice_zip(job)
        old = client.post(endpoint + "/voice-import", content=original).json()
        old_path = store.directory(job["id"]) / old["audio"]["0"]["file"]
        changed = client.post(
            endpoint + "/voice-settings",
            json={
                "voice_mode": "indextts_local",
                "voice_preset": "科技男声",
                "voice_speed": 1,
            },
        ).json()
        assert old_path.is_file()
        assert changed["audio"] == {} and changed["result"] is None
        assert changed["spec"]["voice_revision"]
        assert changed["media"] == job["media"]
        assert client.post(endpoint + "/voice-import", content=original).status_code == 400
        result = client.post(endpoint + "/voice-import", content=voice_zip(changed)).json()
        assert result["audio"]["0"]["source"] == "IndexTTS · 科技男声"
        assert result["audio"]["0"]["timing"] == "indextts_sentence_estimated"
        assert result["audio"]["0"]["cues"][-1]["end"] == result["audio"]["0"]["seconds"]
        # Saving even the same preset explicitly requests another voice version.
        changed2 = client.post(
            endpoint + "/voice-settings",
            json={
                "voice_mode": "indextts_local",
                "voice_preset": "科技男声",
            },
        ).json()
        assert changed2["spec"]["voice_revision"] != changed["spec"]["voice_revision"]
        assert (
            client.post(endpoint + "/voice-import", content=voice_zip(changed)).status_code == 400
        )


def test_cancel_rearm_rejects_stale_speech_render_and_errors():
    with TestClient(app) as client:
        job = create(client, plan(client), voice_mode="indextts_local").json()
        endpoint = "/api/v1/videos/" + job["id"]
        armed = client.post(endpoint + "/arm", json={}).json()
        assert (
            client.post(
                endpoint + "/voice-settings",
                json={
                    "voice_mode": "upload",
                    "voice_preset": "test",
                },
            ).status_code
            == 409
        )
        old_zip = voice_zip(armed)
        client.post(endpoint + "/cancel", json={})
        latest = client.post(endpoint + "/arm", json={}).json()
        assert latest["spec"]["automation_token"] != armed["spec"]["automation_token"]
        assert (
            client.post(endpoint + "/voice-import?automation=true", content=old_zip).status_code
            == 400
        )
        assert (
            client.post(
                endpoint + "/render",
                json={
                    "automation": True,
                    "automation_token": armed["spec"]["automation_token"],
                },
            ).status_code
            == 409
        )
        stale = client.post(
            endpoint + "/automation-failed",
            json={
                "code": "indextts_speech_failed",
                "automation_token": armed["spec"]["automation_token"],
            },
        ).json()
        assert stale["spec"]["auto_requested"] and stale["status"] == "draft"
        result = client.post(endpoint + "/voice-import?automation=true", content=voice_zip(latest))
        assert result.status_code == 200
        failed = client.post(
            endpoint + "/automation-failed",
            json={
                "code": "indextts_speech_failed",
                "automation_token": latest["spec"]["automation_token"],
            },
        ).json()
        assert failed["status"] == "failed" and "IndexTTS" in failed["error"]
        assert not failed["spec"]["auto_requested"]


def test_speech_change_during_import_cannot_overwrite_new_settings(monkeypatch):
    from radar.video import speech

    with TestClient(app) as client:
        job = create(client, plan(client), voice_mode="indextts_local").json()
        original = speech.store.read
        changed = {**job, "spec": {**job["spec"], "voice_revision": "new"}}
        monkeypatch.setattr(speech.store, "read", lambda _: changed)
        with pytest.raises(Exception) as failure:
            speech.import_voice(job, io.BytesIO(voice_zip(job)))
        assert failure.value.status_code == 400
        assert not list(store.directory(job["id"]).glob("*.wav"))
        monkeypatch.setattr(speech.store, "read", original)


def test_neural_chunks_keep_context_and_bounds():
    text = "最近我一直在关注人工智能的新变化。有些功能看起来很厉害，"
    text += "但到底能不能帮我们省时间，还得放到真实任务里试一试。"
    assert neural_chunks(text) == [text]
    assert all(0 < len(c) <= 180 for c in neural_chunks(text * 40))
    assert neural_chunks("  \n") == []


@pytest.mark.parametrize(
    "url",
    [
        "https://127.0.0.1:7860",
        "http://example.com",
        "http://127.0.0.1.evil.test",
        "http://user:secret@localhost",
        "http://localhost/a",
        "http://localhost/?x=1",
    ],
)
def test_bridge_refuses_nonlocal_or_ambiguous_url(url):
    with pytest.raises(ValueError):
        bridge.local_url(url)


def preset(tmp_path, **changes):
    folder = tmp_path / "outputs/presets/科技男声"
    folder.mkdir(parents=True)
    (folder / "prompt.wav").write_bytes(pcm())
    value = {
        "prompt_audio": "prompt.wav",
        "emo_control_method": 0,
        "advanced_params": {"num_beams": 1, "temperature": 0.8},
    }
    value.update(changes)
    (folder / "preset.json").write_text(json.dumps(value))
    return folder, value


def test_extension_uses_existing_model_and_saved_parameters_and_cleans_failure(tmp_path):
    preset(tmp_path)
    calls = []

    class Model:
        def infer(self, **kwargs):
            calls.append(kwargs)
            Path(kwargs["output_path"]).write_bytes(pcm())

    output = extension.synthesize(Model(), tmp_path, "科技男声", "今天聊聊人工智能。", 0.95)
    assert Path(output).is_file()
    assert calls[0]["num_beams"] == 1
    assert calls[0]["duration_factor"] == 0.95 and calls[0]["lang"] == "ZH"
    assert calls[0]["use_emo_text"] is False
    assert calls[0]["spk_audio_prompt"].endswith("科技男声/prompt.wav")
    with pytest.raises(ValueError):
        extension.synthesize(Model(), tmp_path, "科技男声", "a" * 181, 1)

    class Broken:
        def infer(self, **kwargs):
            Path(kwargs["output_path"]).write_bytes(b"partial")
            raise RuntimeError("GPU unavailable")

    with pytest.raises(RuntimeError):
        extension.synthesize(Broken(), tmp_path, "科技男声", "测试", 1)
    assert list((tmp_path / "outputs/radar-api").glob("*.wav")) == [Path(output)]


def test_preset_paths_and_large_emotion_model_are_rejected(tmp_path):
    folder, data = preset(tmp_path)
    for name in ("../x", "a/b", "a.b", "", " "):
        with pytest.raises(ValueError):
            extension.preset_data(tmp_path, name)
    data["prompt_audio"] = "../../../outside.wav"
    (tmp_path / "outside.wav").write_bytes(pcm())
    (folder / "preset.json").write_text(json.dumps(data))
    with pytest.raises(ValueError):
        extension.preset_data(tmp_path, "科技男声")
    data.update(prompt_audio="prompt.wav", emo_control_method=3)
    (folder / "preset.json").write_text(json.dumps(data))
    with pytest.raises(ValueError, match="extra GPU"):
        extension.synthesize(None, tmp_path, "科技男声", "测试", 1)


def test_webui_patch_preserves_compatible_upload_is_idempotent_and_backs_up(tmp_path):
    text = (
        "# RADAR_GENERIC_REFERENCE_UPLOAD_V1\nwith demo:\n"
        "    gen_button.click(gen_single,\n        outputs=[output_audio])\n"
    )
    path = tmp_path / "webui.py"
    path.write_text(text)
    source = ROOT / "scripts/indextts"
    patcher.patch(tmp_path, source)
    once = path.read_bytes()
    patcher.patch(tmp_path, source)
    assert path.read_bytes() == once
    assert list(tmp_path.glob("webui.py.radar-backup-*"))[0].read_text() == text
    assert "RADAR_GENERIC_REFERENCE_UPLOAD_V1" in path.read_text()
    assert 'concurrency_id="radar_tts"' in path.read_text()
    assert "cmd_args.share" in path.read_text()
    (tmp_path / "radar_indextts_api.py").write_text("custom")
    with pytest.raises(ValueError, match="custom"):
        patcher.patch(tmp_path, source)
    assert path.read_bytes() == once


def test_unknown_webui_layout_is_not_changed(tmp_path):
    path = tmp_path / "webui.py"
    path.write_text("custom upstream")
    with pytest.raises(ValueError):
        patcher.patch(tmp_path, ROOT / "scripts/indextts")
    assert path.read_text() == "custom upstream"
    assert not (tmp_path / "radar_indextts_api.py").exists()


def test_bridge_generation_protocol_cleanup_and_cancel(monkeypatch, tmp_path):
    manifest = {
        "job_id": "a" * 32,
        "engine": "indextts_local",
        "preset": "科技男声",
        "automation_token": "b" * 32,
        "chunks": [
            {"scene": 0, "file": "s01-c001.wav", "text": "第一条新闻。"},
            {"scene": 0, "file": "s01-c002.wav", "text": "。"},
        ],
    }
    pack = tmp_path / "pack.zip"
    with zipfile.ZipFile(pack, "w") as archive:
        archive.writestr("voice-manifest.json", json.dumps(manifest))
    calls = []

    class Client:
        def __init__(self, url, **kwargs):
            assert url == "http://127.0.0.1:7860"
            assert kwargs["httpx_kwargs"]["trust_env"] is False
            self.folder = Path(kwargs["download_files"])

        def submit(self, name, text, factor, **kwargs):
            assert kwargs["api_name"] == "/radar_synthesize"
            calls.append((name, text))
            source = self.folder / ("a" * 32 + ".wav")
            source.write_bytes(pcm())
            return SimpleNamespace(result=lambda timeout: str(source), cancel=lambda: None)

        def predict(self, name, **kwargs):
            calls.append(kwargs["api_name"])

    monkeypatch.setattr(bridge, "still_armed", lambda *_: None)
    monkeypatch.setattr(
        bridge, "normalize_audio", lambda src, dst: (shutil.copy(src, dst), 0.45)[1]
    )
    result = tmp_path / "result.zip"
    bridge.generate(pack, result, "http://127.0.0.1:7860", "http://localhost:8000", Client)
    with zipfile.ZipFile(result) as archive:
        assert set(archive.namelist()) == {"voice-manifest.json", "s01-c001.wav", "s01-c002.wav"}
        with wave.open(io.BytesIO(archive.read("s01-c002.wav"))) as audio:
            assert audio.getnframes() == 4800  # punctuation-only fragment is bounded silence
    assert len(calls) == 2 and calls[-1] == "/radar_release"

    def cancel(*_):
        raise ValueError("cancelled")

    monkeypatch.setattr(bridge, "still_armed", cancel)
    with pytest.raises(ValueError, match="cancelled"):
        bridge.generate(
            pack, tmp_path / "cancel.zip", "http://127.0.0.1:7860", "http://localhost:8000", Client
        )
    assert not (tmp_path / "cancel.zip").exists()


@pytest.mark.skipif(not shutil.which("ffmpeg"), reason="FFmpeg required")
def test_indextts_result_can_drive_existing_real_video_renderer():
    from test_video import wait

    with TestClient(app) as client:
        job = create(client, plan(client), voice_mode="indextts_local").json()
        endpoint = "/api/v1/videos/" + job["id"]
        armed = client.post(endpoint + "/arm", json={}).json()
        assert (
            client.post(
                endpoint + "/voice-import?automation=true", content=voice_zip(armed)
            ).status_code
            == 200
        )
        started = client.post(
            endpoint + "/render",
            json={
                "automation": True,
                "automation_token": armed["spec"]["automation_token"],
            },
        )
        assert started.status_code == 200
        result = wait(client, job["id"])
        assert result["status"] == "completed", result.get("error")
        assert result["result"]["seconds"] > 0
        assert not result["result"]["silent_preview"]
        assert client.get(endpoint + "/download/video").content[4:8] == b"ftyp"
