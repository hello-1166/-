import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).parents[1]
PWSH = os.environ.get("P0_PWSH") or shutil.which("pwsh")
pytestmark = pytest.mark.skipif(not PWSH, reason="PowerShell required")


def digest(value):
    return hashlib.sha256(value).hexdigest()


def fixture(tmp_path):
    incoming, target = tmp_path / "incoming", tmp_path / "existing"
    for root in (incoming, target):
        (root / "src/radar").mkdir(parents=True)
        (root / "scripts").mkdir()
        (root / "docker-compose.yml").write_text("services: {}")
    shutil.copy(ROOT / "scripts/upgrade_p6.ps1", incoming / "scripts")
    (incoming / "src/radar/main.py").write_bytes(b"new")
    (target / "src/radar/main.py").write_bytes(b"old")
    (target / ".env").write_bytes(b"private unchanged")
    (target / "data").mkdir()
    (target / "data/radar.db").write_bytes(b"database audio and videos preserved")
    (incoming / "scripts/new.py").write_bytes(b"new helper")
    manifest = {
        "files": {"src/radar/main.py": digest(b"new"), "scripts/new.py": digest(b"new helper")},
        "allowed_hashes": {"src/radar/main.py": [digest(b"old")]},
    }
    (incoming / "p6_patch_manifest.json").write_text(json.dumps(manifest))
    return incoming, target, manifest


def run(incoming, target):
    return subprocess.run(
        [
            PWSH,
            "-NoProfile",
            "-File",
            str(incoming / "scripts/upgrade_p6.ps1"),
            "-ExistingProjectPath",
            str(target),
        ],
        capture_output=True,
        text=True,
        timeout=20,
    )


def test_upgrade_backs_up_code_and_preserves_private_runtime_idempotently(tmp_path):
    incoming, target, _ = fixture(tmp_path)
    result = run(incoming, target)
    assert result.returncode == 0, result.stderr
    assert (target / "src/radar/main.py").read_bytes() == b"new"
    assert (target / "scripts/new.py").read_bytes() == b"new helper"
    assert (target / ".env").read_bytes() == b"private unchanged"
    assert (target / "data/radar.db").read_bytes() == b"database audio and videos preserved"
    assert (target / "docker-compose.yml").read_text() == "services: {}"
    backup = list((target / "backups").iterdir())
    assert len(backup) == 1
    assert (backup[0] / "src/radar/main.py").read_bytes() == b"old"
    assert (backup[0] / "changes.json").is_file()
    result = run(incoming, target)
    assert result.returncode == 0, result.stderr
    assert len(list((target / "backups").iterdir())) == 1


@pytest.mark.parametrize("kind", ["custom", "checksum", "traversal", "symlink"])
def test_upgrade_refuses_unsafe_changes_before_writing(tmp_path, kind):
    incoming, target, manifest = fixture(tmp_path)
    if kind == "custom":
        (target / "src/radar/main.py").write_bytes(b"user custom")
    elif kind == "checksum":
        (incoming / "scripts/new.py").write_bytes(b"corrupted")
    elif kind == "traversal":
        manifest["files"]["scripts/../../escaped.py"] = digest(b"bad")
        (incoming / "p6_patch_manifest.json").write_text(json.dumps(manifest))
    else:
        (target / "scripts").rmdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        (target / "scripts").symlink_to(outside, target_is_directory=True)
    before = (target / "src/radar/main.py").read_bytes()
    result = run(incoming, target)
    assert result.returncode != 0
    assert (target / "src/radar/main.py").read_bytes() == before
    assert not (target / "backups").exists()
    assert (target / ".env").read_bytes() == b"private unchanged"
