# AGENTS.md — AI Frontier Radar

## Project objective
Build AI Frontier Radar V1.0: a local-first, semi-automated global AI news intelligence and content-preparation system for Xiaohongshu and Douyin.

## Current milestone
The user accepted P1 on Windows, including scheduled ingestion, and explicitly authorized
continuing automatic editorial screening on 2026-11-14 (Asia/Shanghai).
The user additionally authorized P2.1 classification on 2026-11-14: main news category,
availability, evidence type, content formats, and manual production status, with filters,
manual corrections and exports. Keep Plus-only operation without model calls.
Implement P2 topic selection: conservative event grouping, explainable rule ranking,
optional bounded model assistance, human shortlist/ignore decisions and local exports.
Default model calls off; no credentials are available in this environment. No publishing,
voice cloning, video rendering or automatic factual-verification claims. Full draft generation
is outside this increment. Existing P1 workflows and data must remain compatible.

P0 deliverables:
- Docker Compose local environment
- n8n service
- FastAPI service
- SQLite initialization and readiness check
- configuration validation for multi-provider LLM and Feishu
- tests, logs, documentation, PowerShell setup script

Do not implement news ingestion, scoring, fact-checking, content generation, video rendering, or platform publishing in P0.

## Required engineering rules
1. Inspect the existing repository before changing files.
2. Preserve user data and existing files. Never overwrite unreviewed files.
3. Do not invent API keys, Feishu app IDs, table IDs, model IDs, or credentials.
4. Do not hardcode secrets. Read secrets from environment variables.
5. Never print API keys, app secrets, access tokens, or encryption keys in logs or API responses.
6. Bind local development ports to `127.0.0.1`, not `0.0.0.0` on the host.
7. Keep the Python API accessible to n8n over the internal Docker network at `http://api:8000`.
8. Keep all service configuration outside business logic.
9. Use type hints, clear module boundaries, structured logging, and small testable functions.
10. Add or update tests for every behavior change.
11. Do not claim a test passed unless it was actually run and its output inspected.
12. Do not automatically publish to Xiaohongshu or Douyin.
13. Do not scrape login-protected sites or bypass rate limits/access controls.
14. Keep source URLs and attribution in all future news records.
15. Use UTC internally; use `Asia/Shanghai` for editorial schedules and display.

## P0 acceptance
- `docker compose config` succeeds.
- `docker compose up -d --build` starts `api` and `n8n`.
- `GET /health` returns healthy.
- `GET /ready` verifies SQLite initialization.
- configuration-status endpoints do not reveal secrets.
- `pytest` passes.
- no secrets or local runtime data are committed.

## Codex workflow
Work in small steps:
1. inspect;
2. propose a concise plan;
3. implement;
4. run tests;
5. inspect diffs;
6. summarize changed files, commands run, results, and unresolved issues.

P1 approval is recorded in the conversation: the user asked to continue according to the original
plan after P0 startup and n8n persistence checks passed. P2 approval is now recorded above; do not expand into automatic publication.
