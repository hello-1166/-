'use strict';
const el = id => document.getElementById(id);
let offset = 0, total = 0, state = null, running = false;
function node(tag, text, cls) {
  const e = document.createElement(tag);
  if (text !== undefined) e.textContent = text;
  if (cls) e.className = cls;
  return e;
}
async function api(path, options = {}) {
  const r = await fetch(path, {headers: {'Content-Type': 'application/json'}, ...options});
  const data = await r.json();
  if (!r.ok) throw new Error(data.error || data.detail || `请求失败 ${r.status}`);
  return data;
}
function message(text) { el('message').textContent = text; }
function list(parent, title, values) {
  parent.append(node('p', title)); const ul = node('ul');
  values.forEach(v => ul.append(node('li', v))); parent.append(ul);
}
function formatTime(s) {
  return s ? new Intl.DateTimeFormat('zh-CN', {timeZone:'Asia/Shanghai',dateStyle:'short',timeStyle:'short'}).format(new Date(s)) : '发布时间未知';
}
async function refreshStatus() {
  state = await api('/api/v1/selection/status');
  ['total','recommended','selected'].forEach(k => el(k).textContent = state.counts[k]);
  el('usage').textContent = `${state.budget.requests} / ${state.budget.daily_limit}`;
  el('audience').textContent = state.audience;
  el('model-status').textContent = state.model.available ? `已就绪 · ${state.model.provider} · 手动调用` : '未启用或未配置 · 规则筛选可正常使用';
  el('budget').textContent = `每天最多 ${state.budget.daily_limit} 次请求（失败也计入），每次输出上限 ${state.budget.max_output_tokens} tokens；不是金额上限，费用以服务商账单为准。`;
  el('last-screen').textContent = state.last_screen ? `上次初筛：${formatTime(state.last_screen.finished_at)}${state.last_screen.bounded ? ' · 达到单轮处理上限' : ''}` : '尚未初筛';
}
function card(t) {
  const c = node('article', undefined, 'topic-card'); const meta = node('div', undefined, 'topic-meta');
  meta.append(node('span', `规则分 ${t.score}/100`, 'badge'), node('span','待核实','badge warning'),node('span',formatTime(t.published_at)));
  if (t.articles.length > 1) meta.append(node('span',`${t.articles.length} 篇材料 · 疑似同一事件`,'badge'));
  const labels = {pending:'待选择',selected:'已选题',ignored:'已忽略'};
  meta.append(node('span',labels[t.decision])); c.append(meta,RadarTaxonomy.badges(t.taxonomy),node('h2',t.model ? t.model.headline : t.title));
  const reasons = t.analysis.reasons || []; list(c,'为什么进入候选',reasons);
  c.append(node('p',`建议角度：${t.model ? t.model.angle : t.analysis.angle}`));
  if (t.model) {
    const box = node('section',undefined,'model-box');
    box.append(node('p',`模型分析 · ${t.model.provider} · 参考价值 ${t.model.value}/10（主观估计）`),node('p',t.model.summary),node('p',t.model.reason));
    box.append(node('p',`材料：${t.model.materials.map(m => m.kind === 'public_page_excerpt' ? '公开网页片段' : 'RSS摘要回退').join(' / ')}；仍未独立核查。`,'hint')); c.append(box);
  }
  list(c,'发布前需核实',[...new Set([...(t.analysis.checks || []),...(t.model ? t.model.checks : [])])]);
  const details = node('details'); details.append(node('summary','查看原始出处与规则依据'));
  details.append(node('p',Object.entries(t.analysis.dimensions || {}).map(([k,v]) => `${k} ${v}`).join(' · '),'dimension-list'));
  t.articles.forEach(a => {
    const p = node('p'); const link = node('a',`${a.source_name}：${a.title}`);
    try {const u = new URL(a.original_url); if(['http:','https:'].includes(u.protocol)) link.href=u.href;} catch (_) { /* plain label */ }
    link.target='_blank';link.rel='noopener noreferrer';p.append(link);details.append(p,node('p',a.summary || '来源未提供摘要。','hint'));
  }); c.append(details);
  const actions = node('div',undefined,'topic-actions');
  [['selected','加入选题'],['ignored','忽略'],['pending','恢复待选择']].forEach(([decision,label]) => {
    if(t.decision === decision) return;
    const b = node('button',label);b.onclick=() => action(async() => {await api(`/api/v1/topics/${t.id}`,{method:'PATCH',body:JSON.stringify({decision})}); message('选择已保存。');});actions.append(b);
  });
  const model = node('button',t.model ? '已有模型分析' : '模型分析（可能收费）');
  model.disabled = !state.model.available || state.budget.requests >= state.budget.daily_limit || !!t.model || t.decision === 'ignored';
  model.onclick=() => {
    if(!confirm('将向已配置的模型服务商发送此选题的来源材料，可能产生费用。继续分析？')) return;
    action(async() => { const r=await api('/api/v1/selection/enrich',{method:'POST',body:JSON.stringify({topic_ids:[t.id]})}); message(`模型处理：${r.items.map(i=>i.error || i.status).join('，')}。请查看材料与待核实项。`);});
  }; actions.append(model);c.append(actions);
  c.append(RadarTaxonomy.editor(t.taxonomy,'topic',t.id,async()=>{message('分类已保存，人工修改下次初筛会保留。');await loadTopics();},message));return c;
}
async function loadTopics() {
  await refreshStatus();
  await RadarTaxonomy.init();
  const params=new URLSearchParams({limit:20,offset,q:el('query').value});if(el('status').value) params.set('status',el('status').value);
  RadarTaxonomy.query(params);
  const exportParams=RadarTaxonomy.query(new URLSearchParams());
  document.querySelector('a[href^="/api/v1/topics/export"]').href='/api/v1/topics/export?'+exportParams;
  const r=await api('/api/v1/topics?'+params);total=r.total;
  el('topics').replaceChildren(...r.items.map(card));
  if(!r.items.length) el('topics').append(node('p',el('status').value === 'recommended' ? '当前没有达到门槛的待选题。可切换“全部候选”，或采集新消息后再查看。' : '暂无符合条件的选题。','empty'));
  el('page-status').textContent=`共 ${total} 项 · 第 ${Math.floor(offset/20)+1} 页`;el('previous').disabled=offset===0;el('next').disabled=offset+20>=total;
}
async function action(fn) {
  if(running) return;running=true;el('screen').disabled=true;
  document.querySelectorAll('.topic-actions button').forEach(b=>b.disabled=true);
  try {await fn();await loadTopics();}catch(e){message(`操作未完成：${e.message}`);await loadTopics().catch(()=>{});}finally{running=false;el('screen').disabled=false;}
}
el('screen').onclick=()=>action(async()=>{const r=await api('/api/v1/selection/run',{method:'POST',body:'{}'});offset=0;message(`初筛完成：考虑 ${r.considered} 条素材，形成 ${r.topics} 个候选，推荐 ${r.recommended} 个。`);});
el('filters').onsubmit=e=>{e.preventDefault();offset=0;loadTopics().catch(e=>message(e.message));};
el('previous').onclick=()=>{offset=Math.max(0,offset-20);loadTopics().catch(e=>message(e.message));};
el('next').onclick=()=>{offset+=20;loadTopics().catch(e=>message(e.message));};
loadTopics().catch(e=>message(`读取失败：${e.message}`));
