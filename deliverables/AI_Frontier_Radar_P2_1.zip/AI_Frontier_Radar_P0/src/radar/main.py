from __future__ import annotations

import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Response
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from radar.core.config import provider_status
from radar.core.database import database_is_ready, initialize_database
from radar.core.logging import configure_logging
from radar.integrations.feishu import feishu_status
from radar.integrations.llm import llm_configuration_status
from radar.news.config import settings, sources
from radar.news.routes import router as news_router
from radar.selection.config import settings as selection_settings
from radar.selection.routes import router as selection_router
from radar.selection.service import screen
from radar.taxonomy.routes import router as taxonomy_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger = configure_logging()
    try:
        provider_status()
        sources()
        settings()
        selection_settings()
        initialize_database()
        screen()
    except Exception:
        # Do not log configuration values or exception details that may contain secrets.
        logger.error("Radar initialization failed; check local configuration and writable paths")
        raise RuntimeError("Radar initialization failed") from None
    logger.info("P2 initialized; SQLite ready")
    yield


app = FastAPI(
    title="AI Frontier Radar API",
    description="Local API foundation for AI Frontier Radar V1.0",
    version="0.3.1",
    lifespan=lifespan,
    docs_url=None,
    redoc_url=None,
)
app.mount("/static", StaticFiles(directory=Path(__file__).parent / "static"), name="static")
app.include_router(news_router)
app.include_router(selection_router)
app.include_router(taxonomy_router)


@app.get("/docs", include_in_schema=False)
def api_docs() -> HTMLResponse:
    return get_swagger_ui_html(
        openapi_url="/openapi.json",
        title="AI Frontier Radar API - Docs",
        swagger_js_url="/static/swagger-ui-bundle.js",
        swagger_css_url="/static/swagger-ui.css",
        swagger_favicon_url="/static/favicon-32x32.png",
    )


@app.get("/health", tags=["system"])
def health() -> dict[str, str]:
    return {"status": "healthy", "service": "radar-api"}


@app.get("/ready", tags=["system"])
def ready(response: Response) -> dict[str, object]:
    ready_state = database_is_ready()
    if not ready_state:
        response.status_code = 503
    return {
        "status": "ready" if ready_state else "not_ready",
        "database": "ready" if ready_state else "not_ready",
    }


@app.get("/api/v1/system/config-status", tags=["system"])
def config_status() -> dict[str, object]:
    return {
        "environment": os.getenv("APP_ENV", "local"),
        "timezone": os.getenv("TZ", "Asia/Shanghai"),
        "database_ready": database_is_ready(),
        "feishu_enabled": feishu_status()["enabled"],
        "llm_default_provider": provider_status()["default_provider"],
    }


@app.get("/api/v1/llm/providers", tags=["integrations"])
def llm_providers() -> dict[str, object]:
    return llm_configuration_status()


@app.get("/api/v1/integrations/feishu/status", tags=["integrations"])
def feishu_integration_status() -> dict[str, object]:
    return feishu_status()
