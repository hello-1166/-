# P0 验收清单

日期：2026-11-13（Asia/Shanghai）
执行环境：Linux 云环境 / rootless Docker / VFS / PowerShell 7.4.13。

只勾选已执行并观察到通过的事项。详见 `P0_EXECUTION_REPORT.md` 与 `evidence/`。

## A. 环境
- [ ] Windows Docker Desktop 已启动（当前环境不适用，需本机复验）。
- [x] `.env` 已由 `scripts/init_env.ps1` 创建。
- [x] `.env` 不在 Git 跟踪列表中。
- [x] `docker compose config --quiet` 成功。
- [x] API Docker 镜像构建成功。
- [ ] n8n 官方镜像拉取成功（云端解压空间不足）。

## B. 服务
- [x] `radar-api` 容器运行且健康。
- [ ] `radar-n8n` 容器运行且健康（空间与 inode 阻断）。
- [ ] n8n 页面可通过 `http://localhost:5678` 打开。
- [x] API 文档可通过 `http://localhost:8000/docs` 打开。
- [x] Chromium 浏览器在阻断外部请求时仍能加载 API 文档和接口列表。
- [ ] n8n 容器内部可访问 `http://api:8000`（未运行，未验证）。

## C. API
- [x] `GET /health` 返回 `{"status":"healthy","service":"radar-api"}`。
- [x] `GET /ready` 返回数据库 ready。
- [x] 数据库缺失、损坏或版本不符时 readiness 返回 503（单测）。
- [x] `GET /api/v1/system/config-status` 返回非敏感配置状态。
- [x] `GET /api/v1/llm/providers` 返回五个 provider 配置状态。
- [x] `GET /api/v1/integrations/feishu/status` 检查全部六个字段。
- [x] 注入密钥后检查响应及应用日志，没有密钥值；另检查实际生成的本地加密密钥。

## D. 数据库和文件
- [x] `data/radar.db` 自动创建。
- [x] `system_state` 表存在。
- [x] `logs/radar.log` 实际写入 UTC JSON 日志。
- [x] `docker compose down` 后 SQLite 测试行保留，API 重建后验证成功。
- [x] n8n 持久化卷在 compose down 后仍存在。
- [ ] n8n 业务数据在停止后保留（无运行实例，未验证）。
- [x] 未执行 `docker compose down -v`。

## E. 测试
- [x] pytest：28 passed，无 skip，1 条上游弃用提示。
- [x] Ruff 检查及格式检查通过。
- [x] 一键启动脚本的引擎、镜像拉取、内部通信失败与成功路径通过流程模拟测试。
- [x] PowerShell 初始化首次创建、不覆盖、缺失模板失败等测试通过。
- [x] 冒烟脚本遇到 Docker 原生命令失败会退出（单测）。
- [ ] `scripts/smoke_test.ps1` 全部通过（实际执行，n8n 不在运行状态时报错）。
- [x] API 容器和应用日志未包含实际生成的本地加密密钥。
- [ ] n8n 容器日志检查（容器未启动）。
- [x] Git diff 及本地数据忽略规则已检查。
- [x] 没有覆盖原始上传包或用户已有工程。

## F. 最终验收
- [x] 提供变更清单、实际执行命令、测试结果与未完成事项。
- [x] 工程包不包含 `.env`、密钥、数据库、运行日志、虚拟环境或 Git 内部目录。
- [ ] Windows README 完整启动流程实际通过。
- [ ] n8n 与 API 联合环境完成最终验收。

验收结论：**PASS WITH ISSUES（P0 实施及 API 验证完成，完整 P0 尚未验收通过）**。

剩余事项：在有足够磁盘和 inode 的 Windows Docker Desktop 本机执行 README 和 smoke test，核对 n8n 页面、内部 API 通信及 n8n 数据持久化。继续停留在 P0，不自行进入 P1。
