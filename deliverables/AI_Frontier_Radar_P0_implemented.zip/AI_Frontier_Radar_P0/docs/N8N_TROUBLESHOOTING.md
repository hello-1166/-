# n8n 启动与验收

## Windows 一键启动

先启动 Docker Desktop，确认使用 Linux containers 和 WSL 2 backend。将工程解压至可写目录，例如 `D:\Projects\AI_Frontier_Radar_P0`，在该目录打开 PowerShell：

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\start_p0.ps1
```

脚本检查 Docker 引擎、Linux 容器和 Compose，按需初始化 `.env`，拉取固定版本 n8n，启动两个服务并等待健康检查，最后验证页面、API 和 n8n 到 API 的内部连接。已有 `.env` 会保留。

首次启动较慢时可以将等待服务健康的时间从 300 秒提高到 600 秒：

```powershell
.\scripts\start_p0.ps1 -WaitTimeout 600
```

只有所有检查完成才显示 `P0 startup checks passed.`。之后打开 `http://localhost:5678`，按页面引导创建 owner 账号。无需先填写模型或飞书密钥。

## 按报错处理

| 报错或停止阶段 | 处理方法 |
| --- | --- |
| Docker CLI not found | 安装 Docker Desktop，重新打开 PowerShell，让 PATH 生效 |
| Docker engine unavailable | 启动 Docker Desktop，等到引擎 ready；用 `docker info` 确认 |
| Linux containers are required | 在 Docker Desktop 切换至 Linux containers，确认启用 WSL 2 backend |
| n8n image download failed，含 no space left on device | 先释放或扩展 Docker 数据所在磁盘的空间。建议预留 15–20GB 作为启动余量；实际需求取决于镜像、驱动和已有数据 |
| 镜像拉取含 timeout / DNS / TLS 错误 | 检查 Docker Desktop 的代理、网络及受信证书；不要关闭 TLS 验证，也不要把固定摘要改成任意镜像 |
| port is already allocated / address already in use | 用 `Get-NetTCPConnection -LocalPort 5678,8000 -State Listen` 找到占用进程，确认归属后停止冲突服务。不要随意结束未知进程 |
| 服务等待超时 | 先 `docker compose ps`，再在本机查看 `docker compose logs --tail 80 n8n` 和 API 日志，按具体错误处理；首次迁移可延长 WaitTimeout |
| mismatch encryption key | 保留原来的 `.env` 与 n8n 持久化卷，恢复原加密密钥；不要用新密钥覆盖已有凭据数据 |
| n8n cannot reach the API | 检查 API 是否 healthy；保留两个服务的 `radar_internal` 网络及内部地址 `http://api:8000` |

不要执行 `docker compose down -v` 或 `docker system prune --volumes` 来解决空间问题，这些命令可能删除凭据或工作流数据。脚本不会自动清理数据或更改 Docker 的存储驱动。

## VFS 云环境

VFS 会复制各层文件。本次云环境约 8GB、524,288 个 inode，n8n 镜像解压和容器创建实际耗尽资源。`df -h` 检查容量，`df -i` 检查 inode；`docker system df` 不包含所有复制与临时空间开销。

本次环境没有更改 Docker 存储驱动或重启守护进程的管理权限。继续在相同限制下重试不能确认问题已解决。可以在正常 Windows Docker Desktop 本机验收，或让环境管理员扩展容量与 inode。云端 API 已验证通过，但 n8n 尚未验证运行成功。

## 本机验证 n8n 数据保留

服务启动后，在 n8n 界面创建一个未激活的空白测试工作流并保存，记录名称。执行 `docker compose down`（不带 `-v`），再执行 `scripts/start_p0.ps1`。确认 owner 账号与该测试工作流仍在，完成后手动删除测试工作流。

这一步需在实际运行的 n8n 上完成；脚本单元测试不能代替该验收。
