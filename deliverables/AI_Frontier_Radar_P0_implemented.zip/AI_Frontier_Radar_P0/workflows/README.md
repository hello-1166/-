# n8n Workflows

P0 仅预留工作流目录，不导入业务工作流。

后续按阶段添加：
- 01_news_ingestion.json
- 02_news_filtering.json
- 03_fact_checking.json
- 04_content_generation.json
- 05_daily_digest.json

导入工作流前必须：
1. 检查所有凭据引用是否使用 n8n Credentials。
2. 不得把 API Key 或 App Secret 写入 JSON。
3. 检查重试、超时、错误分支和幂等性。
4. 保留人工审核节点。
