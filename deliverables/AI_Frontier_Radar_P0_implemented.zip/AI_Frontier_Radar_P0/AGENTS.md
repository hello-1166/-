# AGENTS.md — AI Frontier Radar

## Project objective
Build AI Frontier Radar V1.0: a local-first, semi-automated global AI news intelligence and content-preparation system for Xiaohongshu and Douyin.

## Current milestone
Only implement P0 infrastructure initialization unless the user explicitly authorizes a later phase.

P0 deliverables:
- Docker Compose local environment
- n8n service
- FastAPI service
- SQLite initialization and readiness check
- configuration validation for multi-provider LLM and Feishu
- tests, logs, documentation, PowerShell setup script

Do not implement news ingestion, scoring, fact-checking, content generation, video rendering, or platform publishing in P0.

## Required engineering rules
1. Inspect the existing repository before changing files.
2. Preserve user data and existing files. Never overwrite unreviewed files.
3. Do not invent API keys, Feishu app IDs, table IDs, model IDs, or credentials.
4. Do not hardcode secrets. Read secrets from environment variables.
5. Never print API keys, app secrets, access tokens, or encryption keys in logs or API responses.
6. Bind local development ports to `127.0.0.1`, not `0.0.0.0` on the host.
7. Keep the Python API accessible to n8n over the internal Docker network at `http://api:8000`.
8. Keep all service configuration outside business logic.
9. Use type hints, clear module boundaries, structured logging, and small testable functions.
10. Add or update tests for every behavior change.
11. Do not claim a test passed unless it was actually run and its output inspected.
12. Do not automatically publish to Xiaohongshu or Douyin.
13. Do not scrape login-protected sites or bypass rate limits/access controls.
14. Keep source URLs and attribution in all future news records.
15. Use UTC internally; use `Asia/Shanghai` for editorial schedules and display.

## P0 acceptance
- `docker compose config` succeeds.
- `docker compose up -d --build` starts `api` and `n8n`.
- `GET /health` returns healthy.
- `GET /ready` verifies SQLite initialization.
- configuration-status endpoints do not reveal secrets.
- `pytest` passes.
- no secrets or local runtime data are committed.

## Codex workflow
Work in small steps:
1. inspect;
2. propose a concise plan;
3. implement;
4. run tests;
5. inspect diffs;
6. summarize changed files, commands run, results, and unresolved issues.

Do not proceed to P1 without explicit user approval.
