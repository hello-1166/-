from __future__ import annotations

import os


def feishu_status() -> dict[str, object]:
    enabled = os.getenv("FEISHU_ENABLED", "false").strip().lower() == "true"
    required = {
        "app_id": bool(os.getenv("FEISHU_APP_ID", "").strip()),
        "app_secret": bool(os.getenv("FEISHU_APP_SECRET", "").strip()),
        "bitable_app_token": bool(os.getenv("FEISHU_BITABLE_APP_TOKEN", "").strip()),
        "news_table_id": bool(os.getenv("FEISHU_NEWS_TABLE_ID", "").strip()),
        "content_table_id": bool(os.getenv("FEISHU_CONTENT_TABLE_ID", "").strip()),
        "source_table_id": bool(os.getenv("FEISHU_SOURCE_TABLE_ID", "").strip()),
    }
    return {
        "enabled": enabled,
        "configured": enabled and all(required.values()),
        "fields_present": required,
        "note": "P0 checks configuration only; authentication and Bitable writes are later work.",
    }
