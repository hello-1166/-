from __future__ import annotations

import os
import sqlite3
from contextlib import closing
from pathlib import Path


def database_path() -> Path:
    return Path(os.getenv("RADAR_DB_PATH", "data/radar.db"))


def initialize_database() -> Path:
    path = database_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(path)) as connection:
        connection.execute(
            "CREATE TABLE IF NOT EXISTS system_state ("
            "state_key TEXT PRIMARY KEY, "
            "state_value TEXT NOT NULL, "
            "updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
        )
        connection.execute(
            "INSERT INTO system_state (state_key, state_value) "
            "VALUES ('schema_version', '1') "
            "ON CONFLICT(state_key) DO UPDATE SET "
            "state_value = excluded.state_value, "
            "updated_at = CURRENT_TIMESTAMP"
        )
        connection.commit()
    return path


def database_is_ready() -> bool:
    path = database_path()
    if not path.exists():
        return False
    try:
        with closing(sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)) as connection:
            row = connection.execute(
                "SELECT state_value FROM system_state WHERE state_key = 'schema_version'"
            ).fetchone()
        return row is not None and row[0] == "1"
    except sqlite3.Error:
        return False
