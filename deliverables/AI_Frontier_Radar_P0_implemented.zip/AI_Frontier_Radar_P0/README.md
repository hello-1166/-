# AI Frontier Radar V1.0

全球 AI 前沿情报与内容生产系统。V1.0 采用本地半自动化架构，面向小红书与抖音。

## 当前范围：P0 工程初始化

P0 只建立可运行、可测试、可扩展的工程底座：

- Windows + Docker Desktop 本地开发环境
- n8n 工作流引擎
- Python FastAPI 基础服务
- SQLite 本地运行状态数据库
- 飞书多维表格集成配置骨架
- 多模型 API 配置与状态检查骨架
- 日志、测试、配置和密钥管理

**P0 不包含**真实新闻采集、新闻评分、事实核查、内容生成、视频渲染或平台自动发布。这些属于后续阶段。

## 目录

- `docs/P0_IMPLEMENTATION_BRIEF.md`：P0 工程实施任务书
- `docs/CODEX_EXECUTION_PROMPT.md`：可直接交给 Codex 的执行指令
- `docs/P0_ACCEPTANCE_CHECKLIST.md`：验收清单
- `docs/ARCHITECTURE.md`：架构和数据流
- `docs/FEISHU_SETUP.md`：飞书应用准备说明
- `AGENTS.md`：Codex 项目级开发约束
- `docker-compose.yml`：本地服务编排
- `src/radar/`：Python 服务
- `config/`：非敏感配置
- `workflows/`：n8n 工作流存放位置

## Windows 本地启动

已经安装并启动 Docker Desktop 时，可在工程根目录直接运行：

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\start_p0.ps1
```

脚本包含配置初始化、n8n 镜像拉取、服务健康等待和完整冒烟检查。遇到报错时按 `docs/N8N_TROUBLESHOOTING.md` 处理。下方保留分步操作，便于定位问题。

### 1. 前置条件

安装并启动：

- Docker Desktop（启用 WSL 2 backend）
- Git
- Python 3.12+（仅用于本地运行测试；容器运行不要求本机 Python）
- Codex 或 VS Code

### 2. 初始化环境变量

在 PowerShell 中进入项目根目录：

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\init_env.ps1
```

脚本会从 `.env.example` 创建 `.env`，并生成本地 n8n 加密密钥。请勿将 `.env` 提交到 Git。

### 3. 安装本地 Python 开发依赖（用于运行 pytest）

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[dev]" -c requirements-dev.lock
pytest
```

如果只使用 Docker 运行服务，可以跳过本步骤。

### 4. 检查 Compose 配置

```powershell
docker compose config --quiet
```

### 5. 构建并启动

```powershell
docker compose up -d --build --wait --wait-timeout 180
docker compose ps
```

### 6. 验证服务

```powershell
Invoke-RestMethod http://localhost:8000/health
Invoke-RestMethod http://localhost:8000/ready
Invoke-RestMethod http://localhost:8000/api/v1/system/config-status
Invoke-RestMethod http://localhost:8000/api/v1/llm/providers
Invoke-RestMethod http://localhost:8000/api/v1/integrations/feishu/status
.\scripts\smoke_test.ps1
```

浏览器入口：

- n8n：<http://localhost:5678>
- Python API 文档：<http://localhost:8000/docs>

首次打开 n8n 时按页面引导创建本地 owner 账号。

### 7. 查看日志

```powershell
docker compose logs -f api
docker compose logs -f n8n
```

### 8. 停止服务

```powershell
docker compose down
```

这会停止容器但保留持久化数据。**不要随意执行 `docker compose down -v`**，该命令会删除 n8n 持久化卷及其工作流/凭据数据。

## 配置与诊断

- Python 运行依赖锁定在 `requirements.lock`，开发依赖锁定在 `requirements-dev.lock`；锁文件包含 Windows/Linux 平台标记。
- n8n 默认使用 2026-11-13 查询到的官方 stable 多平台镜像摘要。升级时主动更新 `N8N_IMAGE` 并重跑验收。
- `/health` 表示进程存活；`/ready` 验证 SQLite schema version，异常返回 HTTP 503。容器健康检查使用 `/ready`。
- provider YAML 格式错误会阻止启动；未填写 API Key 或模型 ID 不阻止启动，只报告未配置。
- 飞书 `configured=true` 需要启用开关以及全部六个字段；这些状态只表示配置齐全，没有验证远端凭据。
- `/docs` 的 Swagger UI 资源随 Python 包发布，不依赖外部 CDN，来源与许可证见 `docs/THIRD_PARTY_ASSETS.md`。
- 应用 JSON 日志写到 `logs/radar.log` 并按大小轮转，时间戳使用 UTC；启动信息不打印密钥。
- `docker compose config` 会展开 `.env`，日常验证使用 `--quiet`，不要分享展开后的完整输出。

Linux 扩展运行时，若 bind mount 写入被拒绝，在本地 `.env` 设置 `RADAR_UID` / `RADAR_GID`。普通 Docker 通常对应宿主机 `id -u` / `id -g`；rootless Docker 中宿主机当前用户可能映射为容器 `0:0`。Windows Docker Desktop 保留默认值即可。修改后重建容器，无需更改目录权限。

受管理云环境若使用自定义 CA，可通过 BuildKit 的可选 `proxy_ca` secret 传入受信证书束；不要禁用 TLS 校验。普通 Windows Docker Desktop 不需要此参数。

```sh
docker build --secret id=proxy_ca,src=/path/to/trusted-ca-bundle.pem -t ai_frontier_radar_p0-api .
```

P0 实测结果和环境限制见 `docs/P0_EXECUTION_REPORT.md`。请在 Windows 本机再次执行上述步骤，完成平台验收。

## 配置飞书与模型 API

P0 默认允许没有 API Key 的情况下启动。先完成基础设施验收，再按文档配置：

- `docs/FEISHU_SETUP.md`
- `.env.example`
- `config/providers.yaml`

任何密钥只放在本地 `.env` 或 Docker secret 管理中，不放进代码、工作流 JSON、截图或 Git。

## 开发原则

1. 先完成 P0 验收，再开发 P1 新闻采集。
2. 所有时间在数据库中统一使用 UTC；面向用户展示时转换为 `Asia/Shanghai`。
3. 新闻必须保留原始 URL、来源名称、原始发布时间和采集时间。
4. 不把企业宣传性描述写成独立验证结论。
5. 未经人工批准，不允许自动发布到小红书或抖音。
6. 不采集登录保护内容，不绕过访问控制，不复制整篇受版权保护的报道。
7. 外部 API 失败必须记录错误，不得伪造成功结果。
