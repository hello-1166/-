from pathlib import Path

import pytest


@pytest.fixture(autouse=True)
def isolated_runtime(monkeypatch, tmp_path):
    for name in (
        "OPENAI_API_KEY",
        "OPENAI_MODEL",
        "ANTHROPIC_API_KEY",
        "ANTHROPIC_MODEL",
        "GEMINI_API_KEY",
        "GEMINI_MODEL",
        "DEEPSEEK_API_KEY",
        "DEEPSEEK_MODEL",
        "DASHSCOPE_API_KEY",
        "QWEN_MODEL",
        "FEISHU_APP_ID",
        "FEISHU_APP_SECRET",
        "FEISHU_BITABLE_APP_TOKEN",
        "FEISHU_NEWS_TABLE_ID",
        "FEISHU_CONTENT_TABLE_ID",
        "FEISHU_SOURCE_TABLE_ID",
        "DEEPSEEK_API_BASE",
        "QWEN_API_BASE",
    ):
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("RADAR_DB_PATH", str(tmp_path / "data" / "radar.db"))
    monkeypatch.setenv("RADAR_LOG_DIR", str(tmp_path / "logs"))
    monkeypatch.setenv("RADAR_CONFIG_DIR", str(Path(__file__).parents[1] / "config"))
    monkeypatch.setenv("LLM_DEFAULT_PROVIDER", "openai")
    monkeypatch.setenv("FEISHU_ENABLED", "false")
    monkeypatch.setenv("RADAR_LOG_LEVEL", "INFO")
