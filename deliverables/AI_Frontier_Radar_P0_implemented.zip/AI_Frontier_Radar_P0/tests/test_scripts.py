import base64
import os
import shutil
import subprocess
from pathlib import Path

import pytest

PWSH = os.getenv("P0_PWSH") or shutil.which("pwsh") or shutil.which("powershell")
pytestmark = pytest.mark.skipif(not PWSH, reason="PowerShell is required for script tests")
ROOT = Path(__file__).parents[1]


def run_script(path):
    return subprocess.run(
        [PWSH, "-NoLogo", "-NoProfile", "-File", str(path)],
        capture_output=True,
        text=True,
        timeout=30,
    )


def test_initializer_creates_unique_key_and_preserves_existing_file(tmp_path):
    scripts = tmp_path / "scripts"
    scripts.mkdir()
    shutil.copy(ROOT / "scripts/init_env.ps1", scripts)
    shutil.copy(ROOT / ".env.example", tmp_path)
    script = scripts / "init_env.ps1"
    first = run_script(script)
    assert first.returncode == 0, first.stderr
    content = (tmp_path / ".env").read_bytes()
    assert not content.startswith(b"\xef\xbb\xbf")
    assert b"GENERATED_BY_init_env_ps1" not in content
    key = next(
        line.split("=", 1)[1]
        for line in content.decode().splitlines()
        if line.startswith("N8N_ENCRYPTION_KEY=")
    )
    assert len(base64.b64decode(key)) == 32
    assert key not in first.stdout + first.stderr
    second = run_script(script)
    assert second.returncode == 0
    assert (tmp_path / ".env").read_bytes() == content


def test_initializer_fails_without_example(tmp_path):
    scripts = tmp_path / "scripts"
    scripts.mkdir()
    shutil.copy(ROOT / "scripts/init_env.ps1", scripts)
    result = run_script(scripts / "init_env.ps1")
    assert result.returncode != 0
    assert not (tmp_path / ".env").exists()


def test_smoke_stops_on_native_docker_error():
    script = str(ROOT / "scripts/smoke_test.ps1").replace("'", "''")
    result = subprocess.run(
        [
            PWSH,
            "-NoLogo",
            "-NoProfile",
            "-Command",
            "function global:docker { $global:LASTEXITCODE = 17 }; & '" + script + "'",
        ],
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert result.returncode != 0
    assert "Docker Compose configuration failed" in result.stderr
    assert "P0 smoke tests passed" not in result.stdout


@pytest.mark.parametrize(
    "scenario,expected_error",
    [
        ("engine_down", "Docker engine unavailable"),
        ("windows_engine", "Linux containers are required"),
        ("pull_failed", "n8n image download failed"),
        ("api_build_failed", "API image build failed"),
        ("internal_network_failed", "n8n cannot reach the API"),
        ("success", None),
    ],
)
def test_startup_flow_stops_at_failures_and_preserves_existing_env(
    tmp_path,
    scenario,
    expected_error,
):
    scripts = tmp_path / "scripts"
    scripts.mkdir()
    for name in ["start_p0.ps1", "init_env.ps1", "smoke_test.ps1"]:
        shutil.copy(ROOT / "scripts" / name, scripts)
    env_path = tmp_path / ".env"
    if scenario not in ["engine_down", "windows_engine"]:
        env_path.write_text("N8N_ENCRYPTION_KEY=sentinel-existing-key\n")
    trace = tmp_path / "docker-calls.txt"
    wrapper = tmp_path / "mock-start.ps1"
    trace_ps = str(trace).replace("'", "''")
    script_ps = str(scripts / "start_p0.ps1").replace("'", "''")
    wrapper.write_text(
        r"""
$ErrorActionPreference = 'Stop'
function global:docker {
    Add-Content -LiteralPath '__TRACE__' -Value ($args -join ' ')
    $global:LASTEXITCODE = 0
    if ($args[0] -eq 'info') {
        if ('__SCENARIO__' -eq 'engine_down') { $global:LASTEXITCODE = 17; return }
        if ('__SCENARIO__' -eq 'windows_engine') {
            '{"OSType":"windows","Driver":"windowsfilter"}'
            return
        }
        '{"OSType":"linux","Driver":"overlay2"}'
        return
    }
    if ($args[1] -eq 'pull' -and '__SCENARIO__' -eq 'pull_failed') {
        $global:LASTEXITCODE = 9
        return
    }
    if ($args[1] -eq 'build' -and '__SCENARIO__' -eq 'api_build_failed') {
        $global:LASTEXITCODE = 9
        return
    }
    if ($args[1] -eq 'exec' -and '__SCENARIO__' -eq 'internal_network_failed') {
        $global:LASTEXITCODE = 23
        return
    }
    if ($args[1] -eq 'ps') { 'api'; 'n8n' }
}
function global:Invoke-RestMethod {
    param([string]$Uri, [int]$TimeoutSec)
    if ($Uri.EndsWith('/health')) { return @{status='healthy';service='radar-api'} }
    return @{status='ready';database='ready'}
}
function global:Invoke-WebRequest {
    param([string]$Uri, [switch]$UseBasicParsing, [int]$TimeoutSec)
    return @{StatusCode=200}
}
& '__SCRIPT__'
""".replace("__TRACE__", trace_ps)
        .replace("__SCENARIO__", scenario)
        .replace("__SCRIPT__", script_ps)
    )
    result = run_script(wrapper)
    calls = trace.read_text().splitlines()
    if expected_error:
        assert result.returncode != 0
        assert expected_error in result.stderr
        assert "P0 startup checks passed" not in result.stdout
        assert "P0 smoke tests passed" not in result.stdout
    else:
        assert result.returncode == 0, result.stderr
        assert "P0 startup checks passed" in result.stdout
        pull_index = calls.index("compose pull n8n")
        up_index = next(i for i, call in enumerate(calls) if call.startswith("compose up "))
        exec_index = next(i for i, call in enumerate(calls) if call.startswith("compose exec "))
        assert pull_index < up_index < exec_index
    if scenario in ["engine_down", "windows_engine"]:
        assert not env_path.exists()
        assert all("compose up" not in call and "compose pull" not in call for call in calls)
    else:
        assert env_path.read_text() == "N8N_ENCRYPTION_KEY=sentinel-existing-key\n"
    if scenario in ["pull_failed", "api_build_failed"]:
        assert all("compose up" not in call for call in calls)
    assert "sentinel-existing-key" not in result.stdout + result.stderr
