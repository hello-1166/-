from __future__ import annotations

import json
import re
from pathlib import Path
from threading import RLock
from uuid import uuid4

from fastapi import HTTPException

from radar.news.store import database, utc_now
from radar.video.settings import root

LOCK = RLock()


def directory(job_id: str, create: bool = False) -> Path:
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        raise HTTPException(404, "视频任务不存在")
    path = root() / job_id
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def read(job_id: str) -> dict:
    directory(job_id)
    with database() as c:
        row = c.execute("SELECT * FROM video_jobs WHERE id=?", (job_id,)).fetchone()
    if not row:
        raise HTTPException(404, "视频任务不存在")
    job = dict(row)
    for key in ("spec", "media", "audio", "result"):
        raw = job.pop(key + "_json")
        job[key] = json.loads(raw) if raw else None
    return job


def create(spec: dict) -> dict:
    job_id, now = uuid4().hex, utc_now()
    with database() as c:
        c.execute(
            "INSERT INTO video_jobs(id,plan_id,spec_json,created_at,updated_at) VALUES(?,?,?,?,?)",
            (job_id, spec["plan_id"], json.dumps(spec, ensure_ascii=False), now, now),
        )
    directory(job_id, create=True)
    return read(job_id)


def update_files(job_id: str, field: str, key: str, value: dict) -> dict:
    if field not in {"media", "audio"}:
        raise ValueError("Unknown file field")
    with LOCK:
        job = read(job_id)
        if job["status"] == "rendering":
            raise HTTPException(409, "合成期间不能更换素材，请先取消或等待完成")
        entries = job[field]
        entries[key] = value
        job["spec"]["auto_requested"] = False
        with database() as c:
            c.execute(
                f"UPDATE video_jobs SET {field}_json=?,spec_json=?,status='draft',"
                "result_json=NULL,error=NULL,"
                "updated_at=? WHERE id=?",
                (
                    json.dumps(entries, ensure_ascii=False),
                    json.dumps(job["spec"], ensure_ascii=False),
                    utc_now(),
                    job_id,
                ),
            )
        return read(job_id)


def recover() -> None:
    with database() as c:
        c.execute(
            "UPDATE video_jobs SET status='interrupted',"
            "error='服务重启中断了合成，请重新生成',updated_at=? WHERE status='rendering'",
            (utc_now(),),
        )
