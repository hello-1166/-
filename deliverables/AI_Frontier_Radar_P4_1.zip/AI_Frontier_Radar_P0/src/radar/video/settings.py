from __future__ import annotations

import os
import shutil
from pathlib import Path

from pydantic import BaseModel, Field

from radar.core.config import load_yaml
from radar.core.database import database_path


class VideoSettings(BaseModel):
    brand: str = Field(max_length=30)
    fps: int = Field(ge=12, le=30)
    default_width: int = Field(ge=360, le=1080)
    max_scenes: int = Field(ge=1, le=10)
    max_total_seconds: int = Field(ge=10, le=1200)
    max_upload_mb: int = Field(ge=1, le=100)
    max_job_mb: int = Field(ge=10, le=2000)
    max_pixels: int = Field(ge=1000000, le=33554432)
    render_timeout_seconds: int = Field(ge=30, le=3600)
    threads: int = Field(ge=1, le=4)
    caption_chars: int = Field(ge=10, le=30)
    preview_chars_per_second: float = Field(ge=1, le=10)
    font_family: str = Field(min_length=1, max_length=100)


def settings() -> VideoSettings:
    return VideoSettings.model_validate(load_yaml("video.yaml"))


def root() -> Path:
    return database_path().parent / "video_jobs"


def binaries() -> tuple[str | None, str | None]:
    return (
        shutil.which(os.getenv("RADAR_FFMPEG", "ffmpeg")),
        shutil.which(os.getenv("RADAR_FFPROBE", "ffprobe")),
    )
