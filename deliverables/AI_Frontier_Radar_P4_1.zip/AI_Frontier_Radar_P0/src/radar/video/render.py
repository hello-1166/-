from __future__ import annotations

import json
import math
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Event

from fastapi import HTTPException

from radar.news.store import database, utc_now
from radar.video import store
from radar.video.media import INPUT_FLAGS, approximate_cues, ass_text, ass_time, srt_time
from radar.video.settings import binaries, settings

EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="radar-video")
ACTIVE: dict[str, Event] = {}


def command(args: list[str], cwd: Path, cancel: Event, deadline: float) -> None:
    with (cwd / "ffmpeg.log").open("ab") as log:
        process = subprocess.Popen(args, cwd=cwd, stdout=subprocess.DEVNULL, stderr=log)
        try:
            while process.poll() is None:
                if cancel.wait(0.2):
                    raise InterruptedError("已取消合成")
                if time.monotonic() > deadline:
                    raise TimeoutError("合成超时，请缩短本期或使用720p")
            if process.returncode:
                raise ValueError("FFmpeg合成失败，请检查素材或本地任务目录中的ffmpeg.log")
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()


def ass_script(job: dict, scene: dict, cues: list[dict], seconds: float, silent: bool) -> str:
    family = settings().font_family
    header = (
        "[Script Info]\nScriptType: v4.00+\nPlayResX: 720\nPlayResY: 1280\n"
        "WrapStyle: 2\n[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, "
        "BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, "
        "BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
    )
    for name, size, color, bold in (
        ("Brand", 28, "&H00DE5226", 1),
        ("Title", 25, "&H00453220", 1),
        ("Body", 23, "&H00655543", 0),
        ("Caption", 32, "&H00453220", 1),
        ("Small", 16, "&H00847B70", 0),
    ):
        header += (
            f"Style: {name},{family},{size},{color},&H000000FF,&H00FFFFFF,&H00000000,"
            f"{bold},0,0,0,100,100,0,0,1,0,0,8,30,30,0,1\n"
        )
    header += (
        "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, "
        "MarginR, MarginV, Effect, Text\n"
    )
    lines = []

    def put(style: str, text: str, y: int, start=0.0, end=seconds, width=28, max_lines=3):
        safe = ass_text(text, width, max_lines)
        lines.append(
            f"Dialogue: 0,{ass_time(start)},{ass_time(end)},{style},,0,0,0,,"
            + r"{\pos(360,"
            + str(y)
            + r")}"
            + safe
        )

    spec = job["spec"]
    put("Brand", spec["brand"], 45, width=24, max_lines=1)
    put("Small", spec["edition"] + " · " + spec["date_label"], 98, width=40, max_lines=1)
    put("Title", scene["headline"], 150, width=27, max_lines=2)
    if not scene.get("has_media"):
        put("Small", "原文资料卡 · 未提供演示素材", 295, width=35, max_lines=1)
        put("Body", scene["snapshot"]["title"], 365, width=26, max_lines=6)
        articles = scene["snapshot"]["articles"]
        if articles:
            put(
                "Body",
                articles[0]["summary"] or "原文未提供摘要，请查看来源。",
                615,
                width=36,
                max_lines=6,
            )
    put("Small", scene["credit"], 940, width=46, max_lines=2)
    for cue in cues:
        put("Caption", cue["text"], 1010, cue["start"], cue["end"], width=22, max_lines=2)
    put("Title", spec["title"], 1140, width=28, max_lines=2)
    put(
        "Small",
        "静音预览 · 尚未配音" if silent else "来源与适用条件见本期材料包",
        1240,
        width=42,
        max_lines=1,
    )
    return header + "\n".join(lines) + "\n"


def run(job_id: str, silent: bool, cancel: Event) -> None:
    try:
        job = store.read(job_id)
        folder = store.directory(job_id)
        output = folder / f"render-{job['attempt']:03}"
        output.mkdir(exist_ok=True)
        cfg = settings()
        ffmpeg, _ = binaries()
        if not ffmpeg:
            raise ValueError("缺少FFmpeg，请重建P4镜像")
        deadline = time.monotonic() + cfg.render_timeout_seconds
        width, fps = job["spec"]["width"], job["spec"]["fps"]
        height, scale = width * 16 // 9, width / 720
        combined_cues, offset, timings, warnings = [], 0.0, [], []
        for i, original in enumerate(job["spec"]["scenes"]):
            if cancel.is_set():
                raise InterruptedError("已取消合成")
            scene = dict(original)
            audio = job["audio"].get(str(i))
            media = job["media"].get(str(i))
            if silent:
                seconds = max(3.0, len(scene["narration"]) / cfg.preview_chars_per_second)
                cues = approximate_cues(scene["narration"], seconds)
                timing = "silent_preview_estimate"
            else:
                if not audio:
                    raise ValueError("部分消息还没有配音，请导入配音或生成静音预览")
                seconds, cues, timing = audio["seconds"], audio["cues"], audio["timing"]
            seconds = math.ceil(seconds * fps) / fps
            if offset + seconds > cfg.max_total_seconds:
                raise ValueError("本期总时长超过配置上限，请减少事件或缩短旁白")
            timings.append(timing)
            scene["has_media"] = bool(media)
            if media and media["kind"] == "video" and media["seconds"] < seconds:
                warnings.append(f"第{i + 1}条素材短于旁白，已循环展示，请预览确认")
            (output / f"s{i:02}.ass").write_text(
                ass_script(job, scene, cues, seconds, silent),
                encoding="utf-8",
            )
            args = [
                ffmpeg,
                "-y",
                "-nostdin",
                "-loglevel",
                "error",
                "-filter_complex_threads",
                "1",
                "-f",
                "lavfi",
                "-i",
                f"color=c=0xf3f6fb:s={width}x{height}:r={fps}:d={seconds}",
            ]
            filters = (
                f"[0:v]drawbox=x={40 * scale}:y={250 * scale}:w={640 * scale}:"
                f"h={670 * scale}:color=white:t=fill[base];"
            )
            if media:
                args += (
                    ["-loop", "1", "-framerate", str(fps)]
                    if media["kind"] == "image"
                    else ["-stream_loop", "-1"]
                )
                args += [*INPUT_FLAGS, "-i", str(folder / media["file"])]
                box_w, box_h = round(640 * scale), round(670 * scale)
                filters += (
                    f"[1:v]fps={fps},scale={box_w}:{box_h}:force_original_aspect_ratio=decrease,"
                    f"pad={box_w}:{box_h}:(ow-iw)/2:(oh-ih)/2:color=white,setsar=1[media];"
                    f"[base][media]overlay={40 * scale}:{250 * scale}:shortest=1[scene];"
                    f"[scene]ass=s{i:02}.ass[v]"
                )
                audio_index = 2
            else:
                filters += f"[base]ass=s{i:02}.ass[v]"
                audio_index = 1
            if silent:
                args += ["-f", "lavfi", "-i", "anullsrc=r=24000:cl=mono"]
            else:
                args += [*INPUT_FLAGS, "-i", str(folder / audio["file"])]
            args += [
                "-filter_complex",
                filters,
                "-map",
                "[v]",
                "-map",
                f"{audio_index}:a:0",
                "-af",
                "apad",
                "-t",
                str(seconds),
                "-c:v",
                "libx264",
                "-preset",
                "veryfast",
                "-crf",
                "24",
                "-pix_fmt",
                "yuv420p",
                "-c:a",
                "aac",
                "-ar",
                "48000",
                "-ac",
                "2",
                "-threads",
                str(cfg.threads),
                "-movflags",
                "+faststart",
                f"s{i:02}.mp4",
            ]
            command(args, output, cancel, deadline)
            combined_cues += [
                {**cue, "start": cue["start"] + offset, "end": cue["end"] + offset} for cue in cues
            ]
            offset += seconds
        (output / "concat.txt").write_text(
            "\n".join(f"file 's{i:02}.mp4'" for i in range(len(job["spec"]["scenes"])))
        )
        command(
            [
                ffmpeg,
                "-y",
                "-nostdin",
                "-loglevel",
                "error",
                "-f",
                "concat",
                "-safe",
                "1",
                "-i",
                "concat.txt",
                "-c",
                "copy",
                "-movflags",
                "+faststart",
                "video.mp4",
            ],
            output,
            cancel,
            deadline,
        )
        command(
            [
                ffmpeg,
                "-y",
                "-nostdin",
                "-loglevel",
                "error",
                "-ss",
                "0",
                "-i",
                "video.mp4",
                "-frames:v",
                "1",
                "cover.jpg",
            ],
            output,
            cancel,
            deadline,
        )
        (output / "subtitles.srt").write_text(
            "\n\n".join(
                f"{n}\n{srt_time(c['start'])} --> {srt_time(c['end'])}\n{c['text']}"
                for n, c in enumerate(combined_cues, 1)
            )
            + "\n",
            encoding="utf-8-sig",
        )
        if any(t == "estimated_from_recording" for t in timings):
            warnings.append("上传录音的字幕按字数分配时长，未进行语音识别，请检查同步")
        notes = ["# " + job["spec"]["title"], "", "自动合成待预览稿；来源内容尚需人工核实。", ""]
        for i, scene in enumerate(job["spec"]["scenes"], 1):
            notes += [f"## {i}. {scene['headline']}", "", scene["narration"], "", scene["credit"]]
            notes += [
                a["source_name"]
                + "："
                + a["original_url"]
                + "；日期："
                + (a["published_at"] or "未知")
                for a in scene["snapshot"]["articles"]
            ]
            notes += [""]
        notes += ["## 预览提示", *warnings]
        (output / "materials.md").write_text("\n".join(notes), encoding="utf-8")
        prefix = output.name + "/"
        result = {
            "seconds": offset,
            "width": width,
            "height": height,
            "silent_preview": silent,
            "timings": timings,
            "warnings": warnings,
            "files": {
                "video": prefix + "video.mp4",
                "cover": prefix + "cover.jpg",
                "subtitles": prefix + "subtitles.srt",
                "materials": prefix + "materials.md",
            },
        }
        if cancel.is_set():
            raise InterruptedError("已取消合成")
        with database() as c:
            c.execute(
                "UPDATE video_jobs SET status='completed',result_json=?,error=NULL,"
                "updated_at=? WHERE id=?",
                (json.dumps(result, ensure_ascii=False), utc_now(), job_id),
            )
    except Exception as exc:
        status = "cancelled" if isinstance(exc, InterruptedError) else "failed"
        message = (
            str(exc)
            if isinstance(exc, (ValueError, InterruptedError, TimeoutError))
            else "合成未完成，请检查本地素材与任务日志"
        )
        with database() as c:
            c.execute(
                "UPDATE video_jobs SET status=?,error=?,updated_at=? WHERE id=?",
                (status, message, utc_now(), job_id),
            )
    finally:
        with store.LOCK:
            ACTIVE.pop(job_id, None)


def start(job_id: str, silent: bool, automation: bool = False) -> dict:
    with store.LOCK:
        job = store.read(job_id)
        if automation and (not job["spec"].get("auto_requested") or job["status"] != "draft"):
            raise HTTPException(409, "自动任务已取消或不在队列中")
        if ACTIVE or job["status"] == "rendering":
            raise HTTPException(409, "已有视频正在合成，请等待或取消后重试")
        if not all(binaries()):
            raise HTTPException(409, "缺少FFmpeg/FFprobe，请先构建P4镜像")
        if not silent and len(job["audio"]) != len(job["spec"]["scenes"]):
            raise HTTPException(409, "请先为每条消息导入配音，或选择静音预览")
        job["spec"]["auto_requested"] = False
        cancel = Event()
        ACTIVE[job_id] = cancel
        with database() as c:
            c.execute(
                "UPDATE video_jobs SET status='rendering',attempt=attempt+1,error=NULL,spec_json=?,"
                "updated_at=? WHERE id=?",
                (json.dumps(job["spec"], ensure_ascii=False), utc_now(), job_id),
            )
        EXECUTOR.submit(run, job_id, silent, cancel)
        return store.read(job_id)


def cancel(job_id: str) -> dict:
    with store.LOCK:
        store.read(job_id)
        if job_id in ACTIVE:
            ACTIVE[job_id].set()
        else:
            job = store.read(job_id)
            job["spec"]["auto_requested"] = False
            with database() as c:
                c.execute(
                    "UPDATE video_jobs SET spec_json=?,status='cancelled',updated_at=? WHERE id=?",
                    (json.dumps(job["spec"], ensure_ascii=False), utc_now(), job_id),
                )
    return store.read(job_id)


def stop_active() -> None:
    with store.LOCK:
        for event in ACTIVE.values():
            event.set()
