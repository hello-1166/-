from __future__ import annotations

import json
import re
import subprocess
import textwrap
from pathlib import Path

from radar.video.settings import binaries, settings

FORMATS = "mov,mp3,wav,ogg,flac,png_pipe,jpeg_pipe,webp_pipe"
INPUT_FLAGS = ["-protocol_whitelist", "file,pipe", "-format_whitelist", FORMATS]


def probe(path: Path) -> dict:
    _, ffprobe = binaries()
    if not ffprobe:
        raise ValueError("缺少FFprobe，请安装包含视频依赖的P4镜像")
    try:
        result = subprocess.run(
            [
                ffprobe,
                "-v",
                "error",
                *INPUT_FLAGS,
                "-show_entries",
                "format=duration,format_name:stream=codec_type,codec_name,width,height",
                "-of",
                "json",
                str(path),
            ],
            capture_output=True,
            timeout=15,
            check=True,
        )
        value = json.loads(result.stdout)
    except (subprocess.SubprocessError, ValueError):
        raise ValueError("无法读取素材；请使用有效的PNG/JPG/WebP、MP4/MOV或WAV/MP3音频") from None
    streams = value.get("streams", [])
    if not streams or len(streams) > 8:
        raise ValueError("素材流数量无效")
    if any(s.get("width", 0) * s.get("height", 0) > settings().max_pixels for s in streams):
        raise ValueError("素材分辨率过大，请先缩小至4K以内")
    value["duration"] = float(value.get("format", {}).get("duration", 0) or 0)
    return value


def captions(text: str) -> list[str]:
    """Deterministic subtitle chunks; no text generation or speech recognition."""
    chunks = []
    for phrase in re.split(r"(?<=[。！？!?；;])|\n+", text):
        phrase = phrase.strip()
        if phrase:
            chunks.extend(
                textwrap.wrap(
                    phrase,
                    width=settings().caption_chars,
                    break_long_words=True,
                    break_on_hyphens=False,
                )
            )
    return chunks


def approximate_cues(text: str, duration: float) -> list[dict]:
    chunks = captions(text)
    total = sum(len(c) for c in chunks)
    if not total:
        raise ValueError("旁白不能为空")
    result, offset = [], 0.0
    for chunk in chunks:
        end = offset + duration * len(chunk) / total
        result.append({"start": offset, "end": end, "text": chunk})
        offset = end
    return result


def ass_text(text: str, width: int = 28, max_lines: int = 6) -> str:
    clean = text.replace("\\", "＼").replace("{", "｛").replace("}", "｝")
    lines = []
    for line in clean.splitlines():
        lines.extend(textwrap.wrap(line, width=width) or [""])
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = lines[-1][:-1] + "…"
    return r"\N".join(lines)


def ass_time(seconds: float) -> str:
    centiseconds = max(0, round(seconds * 100))
    hours, rest = divmod(centiseconds, 360000)
    minutes, rest = divmod(rest, 6000)
    secs, cs = divmod(rest, 100)
    return f"{hours}:{minutes:02}:{secs:02}.{cs:02}"


def srt_time(seconds: float) -> str:
    millis = max(0, round(seconds * 1000))
    hours, rest = divmod(millis, 3600000)
    minutes, rest = divmod(rest, 60000)
    secs, ms = divmod(rest, 1000)
    return f"{hours:02}:{minutes:02}:{secs:02},{ms:03}"
