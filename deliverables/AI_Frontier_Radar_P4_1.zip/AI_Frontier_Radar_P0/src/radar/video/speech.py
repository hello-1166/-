from __future__ import annotations

import hashlib
import io
import json
import wave
import zipfile
from uuid import uuid4

from fastapi import HTTPException

from radar.video import store
from radar.video.media import captions
from radar.video.settings import settings


def speech_manifest(job: dict) -> dict:
    scenes = job["spec"]["scenes"]
    digest = hashlib.sha256(
        json.dumps(
            [s["narration"] for s in scenes],
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()
    return {
        "job_id": job["id"],
        "script_hash": digest,
        "chunks": [
            {"scene": i, "file": f"s{i + 1:02}-c{j + 1:03}.wav", "text": text}
            for i, scene in enumerate(scenes)
            for j, text in enumerate(captions(scene["narration"]))
        ],
    }


WINDOWS_SCRIPT = r"""param([string]$VoiceName = "", [ValidateRange(-5,5)][int]$Rate = 0)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Speech
$ManifestPath = Join-Path $PSScriptRoot 'voice-manifest.json'
$Manifest = [IO.File]::ReadAllText($ManifestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
$Synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
$Voices = @($Synth.GetInstalledVoices() | Where-Object { $_.Enabled } |
    ForEach-Object { $_.VoiceInfo })
if (-not $VoiceName) {
    $Chosen = $Voices | Where-Object { $_.Culture.Name -like 'zh*' } | Select-Object -First 1
    if (-not $Chosen) {
        throw 'No Chinese Windows speech voice found. Install one or upload your recordings.'
    }
    $VoiceName = $Chosen.Name
}
if (-not ($Voices | Where-Object { $_.Name -eq $VoiceName })) {
    throw 'The selected Windows speech voice is not installed.'
}
$Synth.SelectVoice($VoiceName)
$Synth.Rate = $Rate
$Bits = [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen
$Channel = [System.Speech.AudioFormat.AudioChannel]::Mono
$Format = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(24000, $Bits, $Channel)
$OutputRoot = Join-Path $PSScriptRoot ('voice-output-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $OutputRoot | Out-Null
Copy-Item -LiteralPath $ManifestPath -Destination (Join-Path $OutputRoot 'voice-manifest.json')
try {
    foreach ($Chunk in $Manifest.chunks) {
        if ($Chunk.file -notmatch '^s[0-9]{2}-c[0-9]{3}\.wav$') {
            throw 'Invalid audio chunk filename.'
        }
        $Synth.SetOutputToWaveFile((Join-Path $OutputRoot $Chunk.file), $Format)
        $Synth.Speak([string]$Chunk.text)
        $Synth.SetOutputToNull()
        Write-Host ('Generated: ' + $Chunk.file)
    }
} finally { $Synth.Dispose() }
$Suffix = [Guid]::NewGuid().ToString('N').Substring(0,8)
$Result = Join-Path $PSScriptRoot ('voice-result-' + $Suffix + '.zip')
Compress-Archive -Path (Join-Path $OutputRoot '*') -DestinationPath $Result
Write-Host 'Upload this ZIP using Import Windows voice in the video desk:'
Write-Host $Result
"""


def voice_pack(job: dict) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("voice-manifest.json", json.dumps(speech_manifest(job), ensure_ascii=False))
        z.writestr("generate_voice.ps1", WINDOWS_SCRIPT.encode("utf-8-sig"))
        z.writestr(
            "README.txt",
            (
                "解压本包，在解压目录打开Windows PowerShell。逐条运行：\n"
                "Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass\n"
                ".\\generate_voice.ps1\n"
                "将生成的voice-result-*.zip导入原视频任务。仅使用本机System.Speech，不调用API。\n"
                "没有安装中文系统语音时可在Windows设置安装，或上传自己的录音。\n"
            ).encode("utf-8-sig"),
        )
    return buffer.getvalue()


def import_voice(job: dict, archive, automation: bool = False) -> dict:
    expected = speech_manifest(job)
    cfg = settings()
    outputs = []
    try:
        with zipfile.ZipFile(archive) as z:
            names = z.namelist()
            allowed = {"voice-manifest.json", *(c["file"] for c in expected["chunks"])}
            if set(names) != allowed or len(names) != len(allowed):
                raise ValueError("配音包文件不匹配，请上传本任务生成的结果ZIP")
            if sum(i.file_size for i in z.infolist()) > cfg.max_upload_mb * 1024 * 1024:
                raise ValueError("配音包解压后超过上传上限")
            if z.getinfo("voice-manifest.json").file_size > 200000:
                raise ValueError("配音清单过大")
            manifest = json.loads(z.read("voice-manifest.json").decode("utf-8-sig"))
            if manifest != expected:
                raise ValueError("配音包属于其他任务或稿件版本，请重新下载配音包")
            folder = store.directory(job["id"])
            total = 0.0
            for i, _ in enumerate(job["spec"]["scenes"]):
                filename = uuid4().hex + ".wav"
                target = folder / filename
                outputs.append(target)
                cues, offset = [], 0.0
                with wave.open(str(target), "wb") as out:
                    out.setparams((1, 2, 24000, 0, "NONE", "not compressed"))
                    for chunk in (c for c in expected["chunks"] if c["scene"] == i):
                        with wave.open(io.BytesIO(z.read(chunk["file"])), "rb") as source:
                            if (
                                source.getnchannels(),
                                source.getsampwidth(),
                                source.getframerate(),
                                source.getcomptype(),
                            ) != (1, 2, 24000, "NONE"):
                                raise ValueError("系统配音必须是24kHz、16位单声道PCM WAV")
                            duration = source.getnframes() / 24000
                            if not 0 < duration <= cfg.max_total_seconds:
                                raise ValueError("配音时长无效")
                            total += duration
                            if total > cfg.max_total_seconds:
                                raise ValueError("配音总时长超过本期上限")
                            out.writeframes(source.readframes(source.getnframes()))
                            cues.append(
                                {"start": offset, "end": offset + duration, "text": chunk["text"]}
                            )
                            offset += duration
                job["audio"][str(i)] = {
                    "file": filename,
                    "seconds": offset,
                    "cues": cues,
                    "timing": "system_speech_chunks",
                    "source": "Windows系统语音",
                }
        with store.LOCK:
            current = store.read(job["id"])
            if current["status"] == "rendering":
                raise ValueError("合成期间不能导入配音")
            if automation and (
                not current["spec"].get("auto_requested") or current["status"] != "draft"
            ):
                raise ValueError("自动任务已取消或退出队列")
            from radar.news.store import database, utc_now

            with database() as c:
                c.execute(
                    "UPDATE video_jobs SET audio_json=?,status='draft',result_json=NULL,"
                    "error=NULL,updated_at=? WHERE id=?",
                    (json.dumps(job["audio"], ensure_ascii=False), utc_now(), job["id"]),
                )
        return store.read(job["id"])
    except (ValueError, zipfile.BadZipFile, wave.Error, RuntimeError, EOFError, KeyError):
        for p in outputs:
            p.unlink(missing_ok=True)
        raise HTTPException(
            400, "配音包无效或不匹配，请使用本任务的系统配音包，并检查文件和时长上限"
        ) from None
