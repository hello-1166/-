from __future__ import annotations

import math
from datetime import datetime
from pathlib import Path
from typing import Literal
from uuid import uuid4
from zoneinfo import ZoneInfo

from fastapi import APIRouter, HTTPException, Query, Request, Response
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict, Field, field_validator

from radar.news.store import database
from radar.planning.routes import read_plan
from radar.video import render, store
from radar.video.media import approximate_cues, probe
from radar.video.settings import binaries, settings
from radar.video.speech import import_voice, voice_pack

router = APIRouter()


@router.get("/api/v1/plans/{plan_id}/video-template", tags=["video"])
def script_template(plan_id: str):
    import json

    with database() as c:
        plan = read_plan(c, plan_id)
    value = {
        "plan_id": plan_id,
        "plan_revision": plan["revision"],
        "title": plan["title"][:100],
        "brand": settings().brand,
        "edition": "AI周报" if plan["content_format"] == "weekly" else "AI单条解读",
        "width": 720,
        "voice_mode": "windows_auto",
        "confirmed": False,
        "scenes": [
            {
                "topic_id": e["snapshot"]["topic_id"],
                "headline": e["snapshot"]["title"][:100],
                "narration": plan["script"] if len(plan["entries"]) == 1 else "",
                "credit": (
                    " / ".join(a["source_name"] for a in e["snapshot"]["articles"])
                    + " · 来源材料，未作本人实测"
                )[:160],
            }
            for e in plan["entries"]
        ],
    }
    return Response(
        json.dumps(value, ensure_ascii=False, indent=2),
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="video-script-{plan_id}.json"'},
    )


class SceneRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    topic_id: str = Field(min_length=1, max_length=200)
    headline: str = Field(min_length=1, max_length=100)
    narration: str = Field(min_length=1, max_length=2500)
    credit: str = Field(default="来源材料；未作本人实测", max_length=160)

    @field_validator("headline", "narration")
    @classmethod
    def nonblank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Text cannot be blank")
        return value.strip()


class CreateVideo(BaseModel):
    model_config = ConfigDict(extra="forbid")
    plan_id: str = Field(min_length=1, max_length=100)
    plan_revision: int = Field(ge=1)
    title: str = Field(min_length=1, max_length=100)
    brand: str = Field(default="AI前沿雷达", min_length=1, max_length=30)
    edition: Literal["AI日报", "AI周报", "AI单条解读"] = "AI周报"
    width: Literal[720, 1080] = 720
    confirmed: Literal[True]
    voice_mode: Literal["windows_auto", "upload"] = "windows_auto"
    scenes: list[SceneRequest] = Field(min_length=1, max_length=10)

    @field_validator("title", "brand")
    @classmethod
    def nonblank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Text cannot be blank")
        return value.strip()


class RenderRequest(BaseModel):
    silent_preview: bool = False
    automation: bool = False


@router.get("/videos", include_in_schema=False)
def page():
    return FileResponse(Path(__file__).parents[1] / "static" / "videos.html")


@router.get("/api/v1/videos/status", tags=["video"])
def status():
    cfg = settings()
    ffmpeg, ffprobe = binaries()
    return {
        "available": bool(ffmpeg and ffprobe),
        "active": bool(render.ACTIVE),
        "max_scenes": cfg.max_scenes,
        "max_total_seconds": cfg.max_total_seconds,
        "max_upload_mb": cfg.max_upload_mb,
        "default_width": cfg.default_width,
        "brand": cfg.brand,
        "model_calls": False,
    }


@router.get("/api/v1/videos", tags=["video"])
def listing(limit: int = Query(20, ge=1, le=100), offset: int = Query(0, ge=0)):
    with database() as c:
        total = c.execute("SELECT count(*) FROM video_jobs").fetchone()[0]
        rows = c.execute(
            "SELECT id FROM video_jobs ORDER BY updated_at DESC,id LIMIT ? OFFSET ?",
            (limit, offset),
        ).fetchall()
    items = []
    for row in rows:
        job = store.read(row["id"])
        items.append(
            {
                "id": job["id"],
                "title": job["spec"]["title"],
                "status": job["status"],
                "updated_at": job["updated_at"],
                "scene_count": len(job["spec"]["scenes"]),
            }
        )
    return {"items": items, "total": total, "limit": limit, "offset": offset}


@router.post("/api/v1/videos", status_code=201, tags=["video"])
def create(payload: CreateVideo):
    cfg = settings()
    if len(payload.scenes) > cfg.max_scenes:
        raise HTTPException(422, "本期事件数量超过上限")
    if len({s.topic_id for s in payload.scenes}) != len(payload.scenes):
        raise HTTPException(422, "同一事件不能重复加入视频")
    if sum(len(s.narration) for s in payload.scenes) > cfg.max_total_seconds * 10:
        raise HTTPException(422, "本期旁白过长，请拆分为多期")
    with database() as c:
        plan = read_plan(c, payload.plan_id)
    if plan["revision"] != payload.plan_revision:
        raise HTTPException(409, "策划已更新，请重新导入策划后创建视频")
    snapshots = {e["snapshot"]["topic_id"]: e["snapshot"] for e in plan["entries"]}
    if any(s.topic_id not in snapshots for s in payload.scenes):
        raise HTTPException(422, "视频事件必须来自所选策划")
    spec = payload.model_dump()
    spec.update(
        auto_requested=False,
        fps=cfg.fps,
        date_label=datetime.now(ZoneInfo("Asia/Shanghai")).strftime("%Y/%m/%d"),
    )
    for scene in spec["scenes"]:
        scene["snapshot"] = snapshots[scene["topic_id"]]
    return store.create(spec)


class AutomationFailure(BaseModel):
    code: Literal["windows_speech_failed", "worker_failed"] = "worker_failed"


@router.get("/api/v1/videos/automation/pending", tags=["video"])
def automation_pending():
    if render.ACTIVE:
        return {"items": []}
    with database() as c:
        rows = c.execute(
            "SELECT id FROM video_jobs WHERE status='draft' ORDER BY created_at,id"
        ).fetchall()
    items = [store.read(row["id"]) for row in rows]
    return {"items": [j for j in items if j["spec"].get("auto_requested")][:10]}


@router.post("/api/v1/videos/{job_id}/arm", tags=["video"])
def arm(job_id: str):
    with store.LOCK:
        job = store.read(job_id)
        if job["status"] == "rendering":
            raise HTTPException(409, "任务正在合成")
        if job["spec"]["voice_mode"] == "upload" and len(job["audio"]) != len(
            job["spec"]["scenes"]
        ):
            raise HTTPException(409, "请先上传每条消息的录音")
        job["spec"]["auto_requested"] = True
        import json

        from radar.news.store import utc_now

        with database() as c:
            c.execute(
                "UPDATE video_jobs SET spec_json=?,status='draft',error=NULL,updated_at=? "
                "WHERE id=?",
                (json.dumps(job["spec"], ensure_ascii=False), utc_now(), job_id),
            )
        return store.read(job_id)


@router.post("/api/v1/videos/{job_id}/automation-failed", tags=["video"])
def automation_failed(job_id: str, payload: AutomationFailure):
    with store.LOCK:
        job = store.read(job_id)
        if not job["spec"].get("auto_requested") or job["status"] != "draft":
            return job
        message = (
            "Windows配音未完成，请检查助手窗口、中文系统语音，或上传本人录音"
            if payload.code == "windows_speech_failed"
            else "助手未完成任务，请检查助手窗口后重新加入队列"
        )
        job["spec"]["auto_requested"] = False
        import json

        from radar.news.store import utc_now

        with database() as c:
            c.execute(
                "UPDATE video_jobs SET spec_json=?,status='failed',error=?,updated_at=? WHERE id=?",
                (json.dumps(job["spec"], ensure_ascii=False), message, utc_now(), job_id),
            )
        return store.read(job_id)


@router.get("/api/v1/videos/{job_id}", tags=["video"])
def detail(job_id: str):
    return store.read(job_id)


async def receive(request: Request, job_id: str, suffix: str) -> Path:
    cfg = settings()
    folder = store.directory(job_id)
    if store.read(job_id)["status"] == "rendering":
        raise HTTPException(409, "合成期间不能上传文件")
    used = sum(p.stat().st_size for p in folder.rglob("*") if p.is_file())
    path = folder / (uuid4().hex + suffix)
    count = 0
    try:
        with path.open("wb") as out:
            async for block in request.stream():
                count += len(block)
                if count > cfg.max_upload_mb * 1024 * 1024:
                    raise HTTPException(413, "上传文件超过上限，请先缩短或压缩素材")
                if used + count > cfg.max_job_mb * 1024 * 1024:
                    raise HTTPException(413, "本任务文件总量超过上限，请清理本地旧任务或新建任务")
                out.write(block)
        if not count:
            raise HTTPException(400, "上传文件为空")
        return path
    except BaseException:
        path.unlink(missing_ok=True)
        raise


@router.post("/api/v1/videos/{job_id}/upload/{kind}/{scene_index}", tags=["video"])
async def upload(
    job_id: str,
    kind: Literal["media", "audio"],
    scene_index: int,
    request: Request,
    filename: str = Query(max_length=200),
):
    job = store.read(job_id)
    if not 0 <= scene_index < len(job["spec"]["scenes"]):
        raise HTTPException(404, "消息位置不存在")
    suffix = Path(filename).suffix.lower()
    allowed = (
        {".png", ".jpg", ".jpeg", ".webp", ".mp4", ".mov"}
        if kind == "media"
        else {
            ".wav",
            ".mp3",
            ".m4a",
            ".ogg",
            ".flac",
        }
    )
    if suffix not in allowed:
        raise HTTPException(400, "不支持此文件类型")
    path = await receive(request, job_id, suffix)
    try:
        info = probe(path)
        seconds = info["duration"]
        if not math.isfinite(seconds) or seconds > settings().max_total_seconds:
            raise ValueError("素材时长超过上限")
        if kind == "audio":
            if seconds <= 0 or not any(s["codec_type"] == "audio" for s in info["streams"]):
                raise ValueError("文件中没有有效音频")
            value = {
                "file": path.name,
                "seconds": seconds,
                "source": "上传录音",
                "cues": approximate_cues(job["spec"]["scenes"][scene_index]["narration"], seconds),
                "timing": "estimated_from_recording",
            }
        else:
            if not any(s["codec_type"] == "video" for s in info["streams"]):
                raise ValueError("文件中没有有效画面")
            image = info["format"]["format_name"] in {"png_pipe", "jpeg_pipe", "webp_pipe"}
            if not image and seconds <= 0:
                raise ValueError("视频时长无效")
            value = {"file": path.name, "seconds": seconds, "kind": "image" if image else "video"}
        return store.update_files(job_id, kind, str(scene_index), value)
    except (ValueError, HTTPException) as exc:
        path.unlink(missing_ok=True)
        if isinstance(exc, HTTPException):
            raise
        raise HTTPException(400, str(exc)) from None


@router.get("/api/v1/videos/{job_id}/voice-pack", tags=["video"])
def download_voice_pack(job_id: str):
    return Response(
        voice_pack(store.read(job_id)),
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="radar-voice-{job_id}.zip"',
        },
    )


@router.post("/api/v1/videos/{job_id}/voice-import", tags=["video"])
async def upload_voice_result(job_id: str, request: Request, automation: bool = False):
    job = store.read(job_id)
    path = await receive(request, job_id, ".zip")
    try:
        return import_voice(job, path, automation)
    finally:
        path.unlink(missing_ok=True)


@router.post("/api/v1/videos/{job_id}/render", tags=["video"])
def generate(job_id: str, payload: RenderRequest):
    return render.start(job_id, payload.silent_preview, payload.automation)


@router.post("/api/v1/videos/{job_id}/cancel", tags=["video"])
def cancel_job(job_id: str):
    return render.cancel(job_id)


@router.get("/api/v1/videos/{job_id}/download/{kind}", tags=["video"])
def download(job_id: str, kind: Literal["video", "cover", "subtitles", "materials"]):
    job = store.read(job_id)
    if not job["result"]:
        raise HTTPException(404, "尚未生成输出文件")
    folder = store.directory(job_id).resolve()
    path = (folder / job["result"]["files"][kind]).resolve()
    if not path.is_relative_to(folder) or not path.is_file():
        raise HTTPException(404, "输出文件不存在")
    return FileResponse(
        path, filename=f"radar-{job_id}-{path.name}", headers={"Cache-Control": "no-store"}
    )
