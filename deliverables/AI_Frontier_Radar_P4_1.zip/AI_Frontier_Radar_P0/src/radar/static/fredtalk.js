'use strict';
(() => {
 let current=null,stamp='',requestNumber=0;
 const labels={prepared:'制作包已准备 · 等待Codex制作',returned:'成片已回传 · 待预览',reviewed:'已记录人工审看'};
 function link(path,title){const a=node('a',title);a.href=path;return a;}
 async function load(){
  if(!current)return;const number=++requestNumber,id=current.id;
  const data=await api(`/api/v1/videos/${id}/fredtalk`);if(number!==requestNumber||current?.id!==id)return;
  $('fredtalk-list').replaceChildren();
  for(const record of data.items){
   const base=`/api/v1/videos/${id}/fredtalk/${record.id}`;
   const box=node('article',undefined,'video-scene');box.append(node('h3',`${labels[record.status]}${record.stale?' · 原材料已改变':''}`),node('small',`版本 ${record.id.slice(0,8)} · ${date(record.created_at)}`));
   box.append(node('p','制作包包含实际旁白和来源材料，请交给你本机的Codex处理。','hint'));
   const actions=node('div',undefined,'video-actions');actions.append(link(base+'/download/bundle','下载FredTalk制作包 ↓'));box.append(actions);
   const upload=node('input');upload.type='file';upload.accept='.zip';
   const uploadLabel=node('label','导入FredTalk成片ZIP（video.mp4＋return-receipt.json）');uploadLabel.append(upload);
   upload.onchange=()=>task(async()=>{if(record.stale||record.status!=='prepared')throw new Error('请先准备新的制作包版本');message('正在检查成片文件、版本、比例和时长…');await uploadFile(base+'/return',upload.files[0]);await load();message('成片已回传。请完整预览动效、文字、声音和字幕，再记录审看结果。');});
   if(record.status==='prepared'&&!record.stale)box.append(uploadLabel);
   if(record.result){
    const p=node('p',record.result.note,'hint');box.append(p);
    if(record.stale)box.append(node('p','此版本的原材料已改变，保留历史成片；请新建制作包继续。','hint'));
    const video=node('video');video.controls=true;video.preload='metadata';video.playsInline=true;video.style.maxWidth='100%';video.style.width='320px';video.style.maxHeight='570px';video.src=base+'/download/video';box.append(video);
    const downloads=node('div',undefined,'video-actions');downloads.append(link(base+'/download/video','下载FredTalk成片'),link(base+'/download/cover','下载封面'),link(base+'/download/receipt','下载回传记录'));box.append(downloads);
    const checkbox=node('input');checkbox.type='checkbox';checkbox.checked=record.status==='reviewed';const label=node('label','我已检查本版动效、文字、声音与字幕；这不代表新闻已自动核实。');label.prepend(checkbox);box.append(label);
    const note=node('textarea');note.rows=2;note.maxLength=2000;note.placeholder='审看记录或修改意见';note.value=record.result.human_note||'';box.append(note);
    const save=node('button','保存人工审看记录');save.type='button';save.onclick=()=>task(async()=>{if(record.stale)throw new Error('旧材料版本不能标记为当前审看通过');await api(base+'/review',{method:'POST',body:JSON.stringify({reviewed:checkbox.checked,note:note.value})});await load();message('审看记录已保存。原P4视频与策划保持不变。');});box.append(save);
   }
   $('fredtalk-list').append(box);
  }
  if(!data.items.length)$('fredtalk-list').append(node('p','先完成配音，再准备制作包。FredTalk需要Node.js 22+、Python 3.11+、Git和本机Agent；原有本地合成仍可使用。','hint'));
 }
 window.addEventListener('radar-video-job',event=>{current=event.detail;const next=current.id+'-'+current.updated_at;if(next!==stamp){stamp=next;load().catch(e=>message(e.message));}});
 $('fredtalk-prepare').onclick=()=>task(async()=>{if(!current)return;message('正在整理实际音频、字幕和素材…');await api(`/api/v1/videos/${current.id}/fredtalk`,{method:'POST',body:'{}'});await load();message('FredTalk制作包已准备，可下载后交给本机Codex。尚未生成FredTalk动效或成片。');});
 $('fredtalk-refresh').onclick=()=>task(load);
 if(typeof job!=='undefined'&&job){current=job;stamp=job.id+'-'+job.updated_at;load().catch(e=>message(e.message));}
})();
