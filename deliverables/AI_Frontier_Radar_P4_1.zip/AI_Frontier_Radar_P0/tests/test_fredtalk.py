import hashlib
import io
import json
import os
import shutil
import subprocess
import zipfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from test_video import HAS_FFMPEG, create, pcm, plan, wait

from radar.core.database import database_path, initialize_database
from radar.main import app
from radar.news.store import database
from radar.video import store
from radar.video.fredtalk import config


def job_with_audio(client, count=2):
    job = create(client, plan(client, count)).json()
    for i in range(count):
        result = client.post(
            f"/api/v1/videos/{job['id']}/upload/audio/{i}?filename=voice.wav", content=pcm(0.7)
        )
        assert result.status_code == 200
    return store.read(job["id"])


def make_return(client, job, session, **changes):
    endpoint = f"/api/v1/videos/{job['id']}"
    assert client.post(endpoint + "/render", json={}).status_code == 200
    rendered = wait(client, job["id"])
    assert rendered["status"] == "completed", rendered["error"]
    video = client.get(endpoint + "/download/video").content
    receipt = {
        "schema": "radar-fredtalk-return-v1",
        "handoff_id": session["id"],
        "job_id": job["id"],
        "fingerprint": session["fingerprint"],
        "upstream_commit": config()["commit"],
        "notes": "桥接测试片段，非FredTalk组件渲染或实际视觉验收",
    }
    receipt.update(changes)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("video.mp4", video)
        z.writestr("return-receipt.json", json.dumps(receipt, ensure_ascii=False))
        z.writestr("checks/bridge_test.json", json.dumps({"test_only": True}))
    return buf.getvalue()


@pytest.mark.skipif(not HAS_FFMPEG, reason="FFmpeg required")
def test_bundle_contains_actual_audio_cues_media_sources_and_pending_contract():
    with TestClient(app) as c:
        job = job_with_audio(c)
        endpoint = f"/api/v1/videos/{job['id']}/fredtalk"
        before = store.read(job["id"])
        response = c.post(endpoint, json={})
        assert response.status_code == 201, response.text
        session = response.json()
        assert not session["stale"] and session["status"] == "prepared"
        archive = c.get(endpoint + f"/{session['id']}/download/bundle")
        assert archive.status_code == 200
        with zipfile.ZipFile(io.BytesIO(archive.content)) as z:
            manifest = json.loads(z.read("radar-handoff.json"))
            assert manifest["visual_review"] == "pending"
            assert manifest["target"]["width"] / manifest["target"]["height"] == 9 / 16
            assert manifest["upstream"]["commit"] == config()["commit"]
            assert all(s["component_selection"] == "pending" for s in manifest["scenes"])
            assert all(s["timingQuality"] == "estimated_from_recording" for s in manifest["scenes"])
            assert "https://openai.com/" in z.read("radar-handoff.json").decode()
            assert "这" in z.read("inputs/subtitles.srt").decode("utf-8-sig")
            assert "伪造PASS" in z.read("PROMPT_FOR_CODEX.md").decode()
            hashes = json.loads(z.read("input-sha256.json"))
            for name, digest in hashes.items():
                assert hashlib.sha256(z.read(name)).hexdigest() == digest
        assert store.read(job["id"]) == before
        assert c.get(endpoint).json()["items"][0]["id"] == session["id"]
        assert c.get("/api/v1/fredtalk/status").json()["native_render_api"] is False


def test_export_without_final_audio_or_while_queued_is_blocked():
    with TestClient(app) as c:
        job = create(c, plan(c)).json()
        endpoint = f"/api/v1/videos/{job['id']}"
        assert c.post(endpoint + "/fredtalk", json={}).status_code == 409
        c.post(endpoint + "/arm", json={})
        assert c.post(endpoint + "/fredtalk", json={}).status_code == 409


@pytest.mark.skipif(not HAS_FFMPEG, reason="FFmpeg required")
def test_return_preview_and_human_review_preserve_original_p4_output():
    with TestClient(app) as c:
        job = job_with_audio(c, 1)
        endpoint = f"/api/v1/videos/{job['id']}/fredtalk"
        session = c.post(endpoint, json={}).json()
        package = make_return(c, job, session)
        baseline = store.read(job["id"])["result"]
        returned = c.post(endpoint + f"/{session['id']}/return", content=package)
        assert returned.status_code == 200, returned.text
        item = returned.json()
        assert item["status"] == "returned"
        assert item["result"]["review"] == "pending_human_review"
        assert item["result"]["reports"] == ["checks/bridge_test.json"]
        for kind in ("video", "cover", "receipt"):
            assert c.get(endpoint + f"/{session['id']}/download/{kind}").status_code == 200
        assert store.read(job["id"])["result"] == baseline
        assert c.post(endpoint + f"/{session['id']}/return", content=package).status_code == 409
        review = c.post(
            endpoint + f"/{session['id']}/review", json={"reviewed": True, "note": "测试审看"}
        )
        assert review.json()["status"] == "reviewed"
        assert review.json()["result"]["human_note"] == "测试审看"


@pytest.mark.skipif(not HAS_FFMPEG, reason="FFmpeg required")
def test_stale_audio_blocks_return_and_review_without_changing_plan():
    with TestClient(app) as c:
        job = job_with_audio(c, 1)
        endpoint = f"/api/v1/videos/{job['id']}"
        session = c.post(endpoint + "/fredtalk", json={}).json()
        c.post(endpoint + "/upload/audio/0?filename=new.wav", content=pcm(0.8))
        assert c.get(endpoint + "/fredtalk").json()["items"][0]["stale"]
        assert (
            c.post(endpoint + f"/fredtalk/{session['id']}/return", content=b"unused").status_code
            == 409
        )
        assert (
            c.post(
                endpoint + f"/fredtalk/{session['id']}/review", json={"reviewed": True}
            ).status_code
            == 409
        )


@pytest.mark.skipif(not HAS_FFMPEG, reason="FFmpeg required")
def test_wrong_receipt_and_zip_paths_are_rejected():
    with TestClient(app) as c:
        job = job_with_audio(c, 1)
        endpoint = f"/api/v1/videos/{job['id']}/fredtalk"
        session = c.post(endpoint, json={}).json()
        archive = make_return(c, job, session, fingerprint="wrong")
        assert c.post(endpoint + f"/{session['id']}/return", content=archive).status_code == 400
        bad = io.BytesIO()
        with zipfile.ZipFile(bad, "w") as z:
            z.writestr("../video.mp4", b"bad")
            z.writestr("return-receipt.json", "{}")
        assert (
            c.post(endpoint + f"/{session['id']}/return", content=bad.getvalue()).status_code == 400
        )
        assert c.get(endpoint).json()["items"][0]["status"] == "prepared"


def test_schema6_backup_and_existing_video_task_survive():
    with TestClient(app) as c:
        job = create(c, plan(c)).json()
    with database() as db:
        db.execute("UPDATE system_state SET state_value='6' WHERE state_key='schema_version'")
        db.execute("DROP TABLE fredtalk_sessions")
    initialize_database()
    assert store.read(job["id"]) == job
    assert len(list((database_path().parent / "backups").glob("radar-before-p4-1-*.db"))) == 1


def test_setup_script_parses_without_installing_external_tools(tmp_path):
    powershell = os.getenv("P0_PWSH") or shutil.which("pwsh")
    if not powershell:
        pytest.skip("PowerShell required")
    source = Path(__file__).parents[1] / "scripts/setup_fredtalk.ps1"
    wrapper = tmp_path / "parse.ps1"
    wrapper.write_text(
        "param([string]$Path)\n$Tokens=$null;$Errors=$null\n"
        "[Management.Automation.Language.Parser]::ParseFile("
        "$Path,[ref]$Tokens,[ref]$Errors) | Out-Null\n"
        "if($Errors.Count){throw 'Parse failed'}\n"
    )
    result = subprocess.run(
        [powershell, "-NoProfile", "-File", str(wrapper), str(source)],
        capture_output=True,
        timeout=20,
    )
    assert result.returncode == 0, result.stderr
    # Syntax and no-reset policy are verified here; no repository or npm installation is performed.
    text = source.read_text()
    assert "reset --hard" not in text and "git clean" not in text
    assert "--filter=blob:none" in text and "--detach" in text


def test_setup_preserves_an_existing_non_repository_folder(tmp_path):
    powershell = os.getenv("P0_PWSH") or shutil.which("pwsh")
    if not powershell or not all(shutil.which(t) for t in ("node", "git", "npm", "python")):
        pytest.skip("PowerShell and local prerequisites required")
    existing = tmp_path / "my-fredtalk"
    existing.mkdir()
    note = existing / "my-notes.txt"
    note.write_text("keep my work")
    source = Path(__file__).parents[1] / "scripts/setup_fredtalk.ps1"
    result = subprocess.run(
        [powershell, "-NoProfile", "-File", str(source), "-FredTalkPath", str(existing)],
        capture_output=True,
        timeout=20,
    )
    assert result.returncode != 0
    assert b"already exists and is not a Git checkout" in result.stderr
    assert note.read_text() == "keep my work"
    assert not (existing / ".git").exists()


@pytest.mark.skipif(not HAS_FFMPEG, reason="FFmpeg required")
@pytest.mark.parametrize("size,duration", [("640x360", 0.7), ("360x640", 4)])
def test_wrong_aspect_or_duration_cannot_be_imported(size, duration, tmp_path):
    clip = tmp_path / "wrong.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            f"color=c=blue:s={size}:r=12:d={duration}",
            "-f",
            "lavfi",
            "-i",
            f"sine=frequency=440:duration={duration}",
            "-c:v",
            "libx264",
            "-c:a",
            "aac",
            "-threads",
            "1",
            str(clip),
        ],
        check=True,
        timeout=20,
    )
    with TestClient(app) as c:
        job = job_with_audio(c, 1)
        endpoint = f"/api/v1/videos/{job['id']}/fredtalk"
        session = c.post(endpoint, json={}).json()
        receipt = {
            "schema": "radar-fredtalk-return-v1",
            "job_id": job["id"],
            "handoff_id": session["id"],
            "fingerprint": session["fingerprint"],
            "upstream_commit": config()["commit"],
        }
        package = io.BytesIO()
        with zipfile.ZipFile(package, "w") as z:
            z.writestr("video.mp4", clip.read_bytes())
            z.writestr("return-receipt.json", json.dumps(receipt))
        response = c.post(endpoint + f"/{session['id']}/return", content=package.getvalue())
        assert response.status_code == 400
        assert c.get(endpoint).json()["items"][0]["result"] is None
