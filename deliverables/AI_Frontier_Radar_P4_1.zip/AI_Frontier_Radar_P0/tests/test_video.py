import io
import json
import math
import shutil
import struct
import subprocess
import time
import wave
import zipfile
from pathlib import Path
from threading import Event

import pytest
from fastapi.testclient import TestClient
from test_p2_selection import article, seed

from radar.core.database import database_path, initialize_database
from radar.main import app
from radar.news.store import database
from radar.selection import store as selection
from radar.video import render, store
from radar.video.media import ass_text, captions, probe
from radar.video.settings import settings
from radar.video.speech import WINDOWS_SCRIPT, speech_manifest

HAS_FFMPEG = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


def plan(client, count=1):
    topics = seed(*[article(str(i), f"Introducing creator video tool {i}") for i in range(count)])
    for topic in topics:
        selection.decide(topic["id"], "selected")
    return client.post(
        "/api/v1/plans",
        json={
            "title": "测试策划",
            "topic_ids": [t["id"] for t in topics],
            "script": "已定稿旁白。",
        },
    ).json()


def create(client, p, **changes):
    payload = {
        "title": "本地视频测试",
        "brand": "测试雷达",
        "edition": "AI日报",
        "width": 720,
        "confirmed": True,
        "plan_id": p["id"],
        "plan_revision": p["revision"],
        "scenes": [
            {
                "topic_id": e["snapshot"]["topic_id"],
                "headline": "本条测试消息",
                "narration": "这是视频合成测试。",
                "credit": "测试资料，非真实新闻",
            }
            for e in p["entries"]
        ],
    }
    payload.update(changes)
    return client.post("/api/v1/videos", json=payload)


def pcm(seconds=0.45):
    buf = io.BytesIO()
    with wave.open(buf, "wb") as out:
        out.setparams((1, 2, 24000, 0, "NONE", "not compressed"))
        samples = [
            round(1200 * math.sin(2 * math.pi * 440 * i / 24000))
            for i in range(round(seconds * 24000))
        ]
        out.writeframes(struct.pack("<" + "h" * len(samples), *samples))
    return buf.getvalue()


def voice_zip(job, **changes):
    manifest = speech_manifest(job)
    manifest.update(changes)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("voice-manifest.json", json.dumps(manifest, ensure_ascii=False))
        for chunk in manifest["chunks"]:
            z.writestr(chunk["file"], pcm())
    return buf.getvalue()


def wait(client, job_id, seconds=50):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        job = client.get("/api/v1/videos/" + job_id).json()
        if job["status"] != "rendering":
            return job
        time.sleep(0.1)
    pytest.fail("Render did not finish within the test deadline")


def test_creation_requires_review_and_saved_plan_version_and_preserves_snapshot():
    with TestClient(app) as c:
        p = plan(c)
        assert create(c, p, confirmed=False).status_code == 422
        assert create(c, p, title="  ").status_code == 422
        assert create(c, p, scenes=[]).status_code == 422
        assert create(c, p, plan_revision=999).status_code == 409
        r = create(c, p)
        assert r.status_code == 201
        job = r.json()
        assert job["status"] == "draft"
        assert job["spec"]["scenes"][0]["snapshot"] == p["entries"][0]["snapshot"]
        with database() as db:
            db.execute("UPDATE news_items SET title='changed after snapshot'")
        assert c.get("/api/v1/videos/" + job["id"]).json()["spec"] == job["spec"]
        assert c.get("/api/v1/videos").json()["total"] == 1
        assert c.get("/api/v1/videos/missing").status_code == 404
        assert c.get(f"/api/v1/videos/{job['id']}/download/video").status_code == 404
        assert c.get("/api/v1/selection/status").json()["budget"]["requests"] == 0


def test_windows_pack_is_static_local_speech_and_import_validates_job_and_pcm():
    with TestClient(app) as c:
        job = create(c, plan(c, 2)).json()
        pack = c.get(f"/api/v1/videos/{job['id']}/voice-pack")
        with zipfile.ZipFile(io.BytesIO(pack.content)) as z:
            assert "generate_voice.ps1" in z.namelist()
            script = z.read("generate_voice.ps1").decode("utf-8-sig")
            assert "System.Speech" in script and "Invoke-WebRequest" not in script
            assert "24000" in script and "SelectVoice" in script
        endpoint = f"/api/v1/videos/{job['id']}/voice-import"
        assert c.post(endpoint, content=voice_zip(job, job_id="other")).status_code == 400
        invalid = io.BytesIO()
        with zipfile.ZipFile(invalid, "w") as z:
            z.writestr("../outside.wav", pcm())
        assert c.post(endpoint, content=invalid.getvalue()).status_code == 400
        response = c.post(endpoint, content=voice_zip(job))
        assert response.status_code == 200
        result = response.json()
        assert len(result["audio"]) == 2
        for audio in result["audio"].values():
            assert audio["timing"] == "system_speech_chunks"
            assert audio["cues"][0]["start"] == 0
            assert audio["cues"][-1]["end"] == audio["seconds"]
            with wave.open(str(store.directory(job["id"]) / audio["file"])) as wav:
                assert wav.getnframes() / wav.getframerate() == audio["seconds"]


@pytest.mark.skipif(not HAS_FFMPEG, reason="FFmpeg required")
def test_real_video_from_imported_speech_chunks_and_uploaded_image(tmp_path):
    image = tmp_path / "image.png"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=c=0x63b7a4:s=160x90",
            "-frames:v",
            "1",
            "-threads",
            "1",
            str(image),
        ],
        check=True,
        timeout=15,
    )
    with TestClient(app) as c:
        job = create(c, plan(c)).json()
        endpoint = f"/api/v1/videos/{job['id']}"
        media = c.post(endpoint + "/upload/media/0?filename=image.png", content=image.read_bytes())
        assert media.status_code == 200, media.text
        assert c.post(endpoint + "/voice-import", content=voice_zip(job)).status_code == 200
        assert c.post(endpoint + "/render", json={}).status_code == 200
        result = wait(c, job["id"])
        assert result["status"] == "completed", result["error"]
        value = result["result"]
        assert not value["silent_preview"] and value["timings"] == ["system_speech_chunks"]
        for kind in ("video", "cover", "subtitles", "materials"):
            assert c.get(endpoint + "/download/" + kind).status_code == 200
        info = probe(store.directory(job["id"]) / value["files"]["video"])
        video = next(s for s in info["streams"] if s["codec_type"] == "video")
        assert video["width"] == 720 and video["height"] == 1280
        assert any(s["codec_type"] == "audio" for s in info["streams"])
        assert "测试资料" in c.get(endpoint + "/download/materials").text
        assert "https://openai.com/" in c.get(endpoint + "/download/materials").text


@pytest.mark.skipif(not HAS_FFMPEG, reason="FFmpeg required")
def test_real_silent_preview_and_uploaded_recording_cues():
    with TestClient(app) as c:
        p = plan(c)
        job = create(c, p).json()
        endpoint = f"/api/v1/videos/{job['id']}"
        assert c.post(endpoint + "/render", json={}).status_code == 409
        assert c.post(endpoint + "/render", json={"silent_preview": True}).status_code == 200
        value = wait(c, job["id"])
        assert value["status"] == "completed", value["error"]
        assert value["result"]["silent_preview"]
        response = c.post(endpoint + "/upload/audio/0?filename=recording.wav", content=pcm(0.7))
        assert response.status_code == 200
        assert response.json()["result"] is None
        assert response.json()["audio"]["0"]["timing"] == "estimated_from_recording"
        assert c.post(endpoint + "/render", json={}).status_code == 200
        result = wait(c, job["id"])
        assert result["status"] == "completed", result["error"]
        assert any("字数" in w for w in result["result"]["warnings"])


@pytest.mark.skipif(not HAS_FFMPEG, reason="FFmpeg required")
def test_invalid_upload_size_path_and_file_validation(monkeypatch):
    with TestClient(app) as c:
        job = create(c, plan(c)).json()
        endpoint = f"/api/v1/videos/{job['id']}"
        assert (
            c.post(endpoint + "/upload/media/0?filename=page.svg", content=b"x").status_code == 400
        )
        assert (
            c.post(endpoint + "/upload/audio/0?filename=x.wav", content=b"garbage").status_code
            == 400
        )
        assert c.post(endpoint + "/upload/audio/9?filename=x.wav", content=pcm()).status_code == 404
        cfg = settings().model_copy(update={"max_upload_mb": 1})
        monkeypatch.setattr("radar.video.routes.settings", lambda: cfg)
        assert (
            c.post(
                endpoint + "/upload/audio/0?filename=x.wav", content=b"x" * (1024 * 1024 + 1)
            ).status_code
            == 413
        )
        assert list(store.directory(job["id"]).iterdir()) == []


def test_single_worker_cancel_and_restart_recovery(monkeypatch):
    entered = Event()

    def worker(job_id, silent, cancel):
        try:
            entered.set()
            cancel.wait(5)
            with database() as db:
                db.execute("UPDATE video_jobs SET status='cancelled' WHERE id=?", (job_id,))
        finally:
            with store.LOCK:
                render.ACTIVE.pop(job_id, None)

    monkeypatch.setattr(render, "run", worker)
    monkeypatch.setattr(render, "binaries", lambda: ("ffmpeg", "ffprobe"))
    with TestClient(app) as c:
        p = plan(c)
        a, b = create(c, p).json(), create(c, p).json()
        endpoint = f"/api/v1/videos/{a['id']}"
        assert c.post(endpoint + "/render", json={"silent_preview": True}).status_code == 200
        assert entered.wait(2)
        assert (
            c.post(f"/api/v1/videos/{b['id']}/render", json={"silent_preview": True}).status_code
            == 409
        )
        assert c.post(endpoint + "/upload/audio/0?filename=x.wav", content=pcm()).status_code == 409
        assert c.post(endpoint + "/cancel", json={}).status_code == 200
        assert wait(c, a["id"])["status"] == "cancelled"
        with database() as db:
            db.execute("UPDATE video_jobs SET status='rendering' WHERE id=?", (b["id"],))
        store.recover()
        assert store.read(b["id"])["status"] == "interrupted"


def test_ass_payload_is_escaped_and_captions_preserve_text():
    assert "{\\pos" not in ass_text("{\\pos(1,1)}恶意覆盖")
    text = "这是一段测试。下一段还有内容！"
    assert "".join(captions(text)) == text


def test_schema5_backup_preserves_plans_and_notes():
    initialize_database()
    with database() as db:
        db.execute("UPDATE system_state SET state_value='5' WHERE state_key='schema_version'")
        db.execute("DROP TABLE video_jobs")
        db.execute("CREATE TABLE custom_video_notes(value TEXT)")
        db.execute("INSERT INTO custom_video_notes VALUES('keep')")
    initialize_database()
    backups = list((database_path().parent / "backups").glob("radar-before-p4-*.db"))
    assert len(backups) == 1
    with database() as db:
        assert db.execute("SELECT value FROM custom_video_notes").fetchone()[0] == "keep"
        assert db.execute("SELECT state_value FROM system_state").fetchone()[0] == "7"


@pytest.mark.parametrize("helper", [False, True])
def test_windows_speech_script_parses_without_executing_it(tmp_path, helper):
    powershell = "/workspace/work/powershell/pwsh"
    if not shutil.which(powershell):
        pytest.skip("PowerShell required")
    script = tmp_path / "generate_voice.ps1"
    script.write_text(
        (Path(__file__).parents[1] / "scripts/video_worker.ps1").read_text()
        if helper
        else WINDOWS_SCRIPT,
        encoding="utf-8-sig",
    )
    parser = tmp_path / "parse.ps1"
    parser.write_text(
        "param([string]$ScriptPath)\n$Tokens=$null;$Errors=$null\n"
        "[System.Management.Automation.Language.Parser]::ParseFile($ScriptPath,"
        "[ref]$Tokens,[ref]$Errors) | Out-Null\nif($Errors.Count){throw 'Parse failed'}\n"
    )
    result = subprocess.run(
        [powershell, "-NoProfile", "-File", str(parser), str(script)],
        capture_output=True,
        timeout=20,
    )
    assert result.returncode == 0, result.stderr


def test_automation_queue_requires_arming_and_cancel_prevents_late_worker_actions():
    with TestClient(app) as c:
        job = create(c, plan(c)).json()
        endpoint = f"/api/v1/videos/{job['id']}"
        assert c.get("/api/v1/videos/automation/pending").json()["items"] == []
        armed = c.post(endpoint + "/arm", json={})
        assert armed.status_code == 200
        assert c.get("/api/v1/videos/automation/pending").json()["items"][0]["id"] == job["id"]
        assert c.post(endpoint + "/cancel", json={}).status_code == 200
        assert c.get("/api/v1/videos/automation/pending").json()["items"] == []
        assert (
            c.post(endpoint + "/voice-import?automation=true", content=voice_zip(job)).status_code
            == 400
        )
        assert c.post(endpoint + "/render", json={"automation": True}).status_code == 409
        # A delayed worker error cannot overwrite a cancelled task.
        c.post(endpoint + "/automation-failed", json={"code": "windows_speech_failed"})
        assert c.get(endpoint).json()["status"] == "cancelled"
        upload = create(c, plan(c), voice_mode="upload").json()
        assert c.post(f"/api/v1/videos/{upload['id']}/arm", json={}).status_code == 409


def test_worker_failure_is_visible_and_disarms_auto_retry():
    with TestClient(app) as c:
        job = create(c, plan(c)).json()
        endpoint = f"/api/v1/videos/{job['id']}"
        c.post(endpoint + "/arm", json={})
        response = c.post(endpoint + "/automation-failed", json={"code": "windows_speech_failed"})
        assert response.json()["status"] == "failed"
        assert "中文系统语音" in response.json()["error"]
        assert c.get("/api/v1/videos/automation/pending").json()["items"] == []
        assert c.post(endpoint + "/arm", json={}).status_code == 200


@pytest.mark.skipif(not HAS_FFMPEG, reason="FFmpeg required")
def test_short_video_loops_and_uses_narration_instead_of_source_audio(tmp_path):
    clip = tmp_path / "clip.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=c=green:s=160x90:r=24:d=0.25",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=1000:duration=0.25",
            "-c:v",
            "libx264",
            "-c:a",
            "aac",
            "-threads",
            "1",
            str(clip),
        ],
        check=True,
        timeout=15,
    )
    with TestClient(app) as c:
        job = create(c, plan(c)).json()
        endpoint = f"/api/v1/videos/{job['id']}"
        assert (
            c.post(
                endpoint + "/upload/media/0?filename=clip.mp4", content=clip.read_bytes()
            ).status_code
            == 200
        )
        assert (
            c.post(endpoint + "/upload/audio/0?filename=speech.wav", content=pcm(0.8)).status_code
            == 200
        )
        c.post(endpoint + "/render", json={})
        result = wait(c, job["id"])
        assert result["status"] == "completed", result["error"]
        assert any("循环" in note for note in result["result"]["warnings"])
        output = store.directory(job["id"]) / result["result"]["files"]["video"]
        decoded = subprocess.run(
            [
                "ffmpeg",
                "-v",
                "error",
                "-i",
                str(output),
                "-vn",
                "-ac",
                "1",
                "-ar",
                "8000",
                "-f",
                "s16le",
                "pipe:1",
            ],
            capture_output=True,
            check=True,
            timeout=15,
        ).stdout
        samples = struct.unpack("<" + "h" * (len(decoded) // 2), decoded)
        crossings = sum(a <= 0 < b for a, b in zip(samples, samples[1:]))
        frequency = crossings / (len(samples) / 8000)
        assert 300 < frequency < 550  # 440Hz narration, not the source's 1000Hz soundtrack.


def test_script_template_keeps_plan_ids_and_never_auto_confirms_content():
    with TestClient(app) as c:
        p = plan(c, 2)
        response = c.get(f"/api/v1/plans/{p['id']}/video-template")
        assert response.status_code == 200
        value = response.json()
        assert value["plan_id"] == p["id"] and value["plan_revision"] == p["revision"]
        assert value["confirmed"] is False
        assert {s["topic_id"] for s in value["scenes"]} == {
            e["snapshot"]["topic_id"] for e in p["entries"]
        }
        assert all(not s["narration"] for s in value["scenes"])
        assert c.post("/api/v1/videos", json=value).status_code == 422
