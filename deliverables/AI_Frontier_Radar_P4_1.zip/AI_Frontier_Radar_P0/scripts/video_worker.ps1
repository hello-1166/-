param(
    [string]$BaseUrl = "http://localhost:8000",
    [string]$VoiceName = "",
    [ValidateRange(-5,5)][int]$Rate = 0,
    [ValidateRange(5,60)][int]$PollSeconds = 8,
    [switch]$Once
)
$ErrorActionPreference = "Stop"
$Address = [Uri]$BaseUrl
if ($Address.Scheme -ne 'http' -or $Address.Host -notin @('localhost','127.0.0.1','[::1]','::1')) {
    throw 'Use the local Radar URL, for example http://localhost:8000.'
}
$BaseUrl = $BaseUrl.TrimEnd('/')
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$WorkRoot = Join-Path $ProjectRoot 'data/video-worker'
New-Item -ItemType Directory -Force -Path $WorkRoot | Out-Null
$Mutex = New-Object System.Threading.Mutex($false, 'Local\AIFrontierRadarVideoWorker')
if (-not $Mutex.WaitOne(0)) { throw 'A video worker is already running. Keep only one worker window open.' }
Write-Host "Local video worker ready: $BaseUrl"
Write-Host 'Keep this window open. Only tasks armed in the video desk are processed. Press Ctrl+C to stop.'
try {
    do {
        try {
            $Pending = Invoke-RestMethod -Uri "$BaseUrl/api/v1/videos/automation/pending" -TimeoutSec 15
            $Job = $Pending.items | Select-Object -First 1
            if ($Job) {
                $JobId = [string]$Job.id
                if ($JobId -notmatch '^[a-f0-9]{32}$') { throw 'Invalid job ID.' }
                $Stage = 'worker_failed'
                $Temp = Join-Path $WorkRoot ($JobId + '-' + [Guid]::NewGuid().ToString('N'))
                New-Item -ItemType Directory -Path $Temp | Out-Null
                try {
                    Write-Host "Processing video task: $JobId"
                    if ($Job.spec.voice_mode -eq 'windows_auto' -and
                        @($Job.audio.PSObject.Properties).Count -ne @($Job.spec.scenes).Count) {
                        $Stage = 'windows_speech_failed'
                        $Pack = Join-Path $Temp 'voice-pack.zip'
                        Invoke-WebRequest -UseBasicParsing -Uri "$BaseUrl/api/v1/videos/$JobId/voice-pack" -OutFile $Pack -TimeoutSec 30
                        $VoiceRoot = Join-Path $Temp 'voice'
                        Expand-Archive -LiteralPath $Pack -DestinationPath $VoiceRoot
                        & (Join-Path $VoiceRoot 'generate_voice.ps1') -VoiceName $VoiceName -Rate $Rate
                        $Result = Get-ChildItem -LiteralPath $VoiceRoot -Filter 'voice-result-*.zip' |
                            Select-Object -First 1
                        if (-not $Result) { throw 'No speech result ZIP was produced.' }
                        Invoke-RestMethod -Uri "$BaseUrl/api/v1/videos/$JobId/voice-import?automation=true" `
                            -Method Post -ContentType 'application/octet-stream' `
                            -InFile $Result.FullName -TimeoutSec 180 | Out-Null
                    }
                    $Stage = 'worker_failed'
                    Invoke-RestMethod -Uri "$BaseUrl/api/v1/videos/$JobId/render" `
                        -Method Post -ContentType 'application/json' `
                        -Body '{"silent_preview":false,"automation":true}' -TimeoutSec 30 | Out-Null
                    Write-Host "Render started: $JobId. Preview in $BaseUrl/videos"
                    Remove-Item -LiteralPath $Temp -Recurse -Force
                } catch {
                    Write-Host "Task failed: $JobId. Check Windows Chinese speech and the local video desk."
                    Write-Host $_.Exception.Message
                    try {
                        $Body = @{code=$Stage} | ConvertTo-Json -Compress
                        Invoke-RestMethod -Uri "$BaseUrl/api/v1/videos/$JobId/automation-failed" `
                            -Method Post -ContentType 'application/json' -Body $Body -TimeoutSec 15 | Out-Null
                    } catch { Write-Host 'Could not update task status; retry from the video desk.' }
                }
            }
        } catch { Write-Host 'Radar is not ready. Waiting for the local API...' }
        if (-not $Once) { Start-Sleep -Seconds $PollSeconds }
    } while (-not $Once)
} finally {
    $Mutex.ReleaseMutex()
    $Mutex.Dispose()
}
