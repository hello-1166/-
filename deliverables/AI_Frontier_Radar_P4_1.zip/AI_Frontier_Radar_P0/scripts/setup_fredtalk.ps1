param(
    [string]$FredTalkPath = "",
    [switch]$InstallLibraryUI
)
$ErrorActionPreference = "Stop"
$Commit = '59b9e9957957dc9f3fd94ab78f95cec33c29e915'
$Repository = 'https://github.com/njrhts2kvv-star/FredTalk.git'
if (-not $FredTalkPath) {
    $FredTalkPath = Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) 'FredTalk-Radar'
}
$FredTalkPath = [IO.Path]::GetFullPath($FredTalkPath)
foreach ($Tool in @('git','node','npm','python')) {
    if (-not (Get-Command $Tool -ErrorAction SilentlyContinue)) {
        throw "Missing $Tool. Install Git, Node.js 22+, and Python 3.11+ before setup."
    }
}
$NodeVersion = & node --version
if ($LASTEXITCODE -ne 0 -or [int]($NodeVersion.TrimStart('v').Split('.')[0]) -lt 22) {
    throw 'Node.js 22 or later is required.'
}
& python -c 'import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)'
if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 or later is required.' }
function Git-Run([string[]]$GitArgs) {
    & git @GitArgs
    if ($LASTEXITCODE -ne 0) { throw 'Git setup failed. Existing files were not reset.' }
}
if (Test-Path -LiteralPath $FredTalkPath) {
    if (-not (Test-Path -LiteralPath (Join-Path $FredTalkPath '.git'))) {
        throw 'The target already exists and is not a Git checkout. Choose an empty new path.'
    }
    $Origin = & git -C $FredTalkPath remote get-url origin
    $Head = & git -C $FredTalkPath rev-parse HEAD
    if ($Origin.TrimEnd('/') -ne $Repository -or $Head -ne $Commit) {
        throw 'Existing FredTalk checkout differs. Choose a new path; no existing checkout was changed.'
    }
    Write-Host 'Pinned FredTalk checkout already exists; keeping local files.'
} else {
    New-Item -ItemType Directory -Path $FredTalkPath | Out-Null
    Git-Run -GitArgs @('-C',$FredTalkPath,'init')
    Git-Run -GitArgs @('-C',$FredTalkPath,'remote','add','origin',$Repository)
    Git-Run -GitArgs @('-C',$FredTalkPath,'config','remote.origin.promisor','true')
    Git-Run -GitArgs @('-C',$FredTalkPath,'config','remote.origin.partialclonefilter','blob:none')
    Git-Run -GitArgs @('-C',$FredTalkPath,'config','extensions.partialClone','origin')
    Git-Run -GitArgs @('-C',$FredTalkPath,'fetch','--depth','1','--filter=blob:none','origin',$Commit)
    Git-Run -GitArgs @('-C',$FredTalkPath,'sparse-checkout','init','--cone')
    Git-Run -GitArgs @('-C',$FredTalkPath,'sparse-checkout','set','skills','scripts','library','docs','apps/library')
    Git-Run -GitArgs @('-C',$FredTalkPath,'checkout','--detach',$Commit)
}
if ($InstallLibraryUI) {
    Push-Location (Join-Path $FredTalkPath 'apps/library')
    try {
        & npm ci
        if ($LASTEXITCODE -ne 0) { throw 'Library dependencies did not install.' }
        & npm run build
        if ($LASTEXITCODE -ne 0) { throw 'Library UI build failed.' }
    } finally { Pop-Location }
}
Write-Host "FredTalk pinned at: $FredTalkPath"
Write-Host "Skill: $FredTalkPath\skills\fred-remotion-output\SKILL.md"
Write-Host 'Only the library, instructions and tools are fetched initially.'
Write-Host 'After choosing a public component, materialize only its declared source and dependencies.'
Write-Host 'Use the original project lockfile. Do not download member assets or enable cloud rendering.'
Write-Host 'Give the exported Radar handoff folder and its PROMPT_FOR_CODEX.md to your local Codex.'
