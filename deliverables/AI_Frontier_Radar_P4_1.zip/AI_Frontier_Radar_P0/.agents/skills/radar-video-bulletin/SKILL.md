---
name: radar-video-bulletin
description: Use an existing AI Frontier Radar plan and approved narration to create local daily/weekly bulletin videos, prepare media, and inspect render outputs without adding an LLM API or automatically publishing.
---

# Radar bulletin video workflow

Use this skill when the user requests producing a video from their Radar content plan. The local
service and Windows helper execute rendering; installing this skill alone does not supply a renderer,
speech voice, factual verification, or source footage.

## Scope and authorization

- Read the user's selected plan and preserve its source URLs and source dates.
- Use narration the user has approved in the conversation or explicitly submitted as final in the
  video task. Do not ask again when that approval is already clear. If facts remain unverified,
  mark the gaps and keep the output a draft; never invent test results, availability, prices or footage.
- Never call an external writing model, cloud speech API or a local LLM as part of this workflow.
- Only use media supplied by the user or acquired within their authorized scope. A local still card
  is the fallback when no footage is available. Do not imply it is an actual product demonstration.
- Do not sign into protected sites, clone a voice or publish to social platforms.

## Prerequisites

1. Radar P4 running locally, normally `http://localhost:8000`.
2. `GET /api/v1/videos/status` reports local FFmpeg/FFprobe available.
3. For automatic Windows speech, the user runs `scripts/video_worker.ps1` on their Windows PC
   and has an enabled Chinese System.Speech voice. Uploading recordings is an alternative.
4. The agent running this skill must have access to that local service. A separate cloud chat does
   not automatically gain access to the user's Windows localhost.

## Procedure

1. Read `/api/v1/plans` and `/api/v1/plans/{id}`. Pick the plan the user identified, without
   modifying existing news or human selections. Keep its revision for stale-plan detection.
2. Prepare a short headline, approved narration and source credit for each included event.
   The role of a daily bulletin is recent change; a weekly bulletin explains a few significant changes.
   Do not fill a quota with irrelevant or duplicate news.
3. POST `/api/v1/videos` with `plan_id`, `plan_revision`, `title`, `brand`, `edition` (`AI日报`,
   `AI周报`, `AI单条解读`), `width` (720 or 1080), `voice_mode` (`windows_auto` or `upload`),
   `confirmed: true` only when supported by the user's approval, and `scenes` containing
   `topic_id`, `headline`, `narration`, `credit`.
4. Upload each local media file as raw bytes to
   `/api/v1/videos/{id}/upload/media/{index}?filename=...`. Indices start at zero. Use a safe URL
   encoder for filenames; do not interpolate narration or filenames into shell commands.
5. Upload recordings similarly with `/upload/audio/{index}` if using recorded speech. Uploaded
   recordings use estimated subtitle timing; Windows speech chunks use measured block durations.
6. When materials are ready, POST `/api/v1/videos/{id}/arm`. The Windows helper polls
   `/api/v1/videos/automation/pending`, creates speech locally when required, imports it, and
   requests rendering. Do not arm a task while still editing its materials.
7. Alternatively, download `/voice-pack`, run its script locally on Windows and upload the result
   to `/voice-import`; then POST `/render` with `{"silent_preview":false}`. A clearly labelled
   silent preview can be requested with `{"silent_preview":true}`.
8. Poll `/api/v1/videos/{id}`. Check `status`, `error`, and `result.warnings`. POST `/cancel`
   to cancel queued/running tasks. A failed or cancelled task does not publish anything.
9. Download `/download/video`, `/download/cover`, `/download/subtitles`, `/download/materials`.
   Inspect an actual frame, duration and audio presence. Review subtitle timing, source attribution,
   whether clips loop, and whether the narration claims more than the sources establish.
10. Return the resulting file links and precise verification limits. Do not call a synthetic test tone
    real speech or describe an unreviewed render as ready to publish.

## Deployment

Use `docs/P4_GUIDE.md` to upgrade an existing P3/P3.1 Windows installation. Preserve `.env`,
data, logs and n8n volumes. Existing plans and source snapshots must survive migration to schema 6.
