import sqlite3

from fastapi.testclient import TestClient
from test_p2_selection import article, seed

from radar.core.database import database_is_ready, database_path, initialize_database
from radar.main import app
from radar.news.store import database
from radar.selection import store


def selected():
    items = seed(article(), article("two", "New robot arm picks objects"))
    for item in items:
        store.decide(item["id"], "selected")
    return items


def update_payload(plan):
    excluded = {"id", "revision", "entries", "created_at", "updated_at"}
    return {
        **{k: v for k, v in plan.items() if k not in excluded},
        "revision": plan["revision"],
        "entries": [
            {"topic_id": e["snapshot"]["topic_id"], "note": e["note"]} for e in plan["entries"]
        ],
    }


def test_plan_creation_edit_reorder_export_and_restart_preserve_source_snapshot(monkeypatch):
    items = selected()
    with TestClient(app) as client:
        created = client.post(
            "/api/v1/plans",
            json={
                "title": "第一期",
                "topic_ids": [i["id"] for i in items],
                "content_format": "weekly",
            },
        )
        assert created.status_code == 201
        plan = created.json()
        first = plan["entries"][0]["snapshot"]
        with database() as c:
            c.execute("UPDATE news_items SET title='changed',summary='changed'")
        store.decide(items[0]["id"], "ignored")
        payload = update_payload(plan)
        payload.update(theme="普通人能用什么", script="我的口播", xhs="我的图文", status="ready")
        payload["entries"].reverse()
        payload["entries"][1]["note"] = "已核对原文，费用待确认"
        edited = client.put("/api/v1/plans/" + plan["id"], json=payload)
        assert edited.status_code == 200
        saved = edited.json()
        assert saved["revision"] == 2
        assert saved["entries"][1]["snapshot"] == first
        assert saved["entries"][1]["note"] == "已核对原文，费用待确认"
        exported = client.get(f"/api/v1/plans/{plan['id']}/export")
        text = exported.text
        assert (
            exported.status_code == 200 and "attachment" in exported.headers["content-disposition"]
        )
        assert "我的口播" in text and "我的图文" in text and "https://openai.com/one" in text
        assert "未核实" in text and "不代表事实已通过核查" in text
        assert first["articles"][0]["summary"] in text
        assert text.index(saved["entries"][0]["snapshot"]["title"]) < text.index(first["title"])
        assert client.get("/api/v1/plans?status=ready").json()["total"] == 1
        assert client.get("/api/v1/plans?status=published").json()["total"] == 0
    with TestClient(app) as client:
        assert client.get("/api/v1/plans/" + plan["id"]).json() == saved
        assert client.get("/api/v1/selection/status").json()["budget"]["requests"] == 0
        assert client.get("/plans").status_code == 200


def test_plan_validation_and_conflict_do_not_overwrite_saved_text():
    items = selected()
    with TestClient(app) as client:
        for ids, code in [([], 422), ([items[0]["id"]] * 2, 422), (["missing"], 409)]:
            assert (
                client.post("/api/v1/plans", json={"title": "本期", "topic_ids": ids}).status_code
                == code
            )
        store.decide(items[1]["id"], "pending")
        assert (
            client.post(
                "/api/v1/plans",
                json={
                    "title": "本期",
                    "topic_ids": [items[1]["id"]],
                },
            ).status_code
            == 409
        )
        assert (
            client.post(
                "/api/v1/plans",
                json={
                    "title": "  ",
                    "topic_ids": [items[0]["id"]],
                },
            ).status_code
            == 422
        )
        plan = client.post(
            "/api/v1/plans",
            json={
                "title": "本期",
                "topic_ids": [items[0]["id"]],
            },
        ).json()
        endpoint = "/api/v1/plans/" + plan["id"]
        payload = update_payload(plan)
        payload["script"] = "保留这个稿件"
        assert client.put(endpoint, json=payload).status_code == 200
        payload["script"] = "旧页面覆盖"
        assert client.put(endpoint, json=payload).status_code == 409
        saved = client.get(endpoint).json()
        assert saved["script"] == "保留这个稿件"
        payload = update_payload(saved)
        payload["entries"] = []
        assert client.put(endpoint, json=payload).status_code == 422
        assert client.get("/api/v1/plans/missing/export").status_code == 404
        assert client.get("/api/v1/plans/missing").status_code == 404
        assert client.get("/api/v1/plans?status=invalid").status_code == 422


def test_material_add_remove_and_reorder_keep_editorial_choices_separate():
    items = selected()
    with TestClient(app) as client:
        plan = client.post(
            "/api/v1/plans",
            json={
                "title": "本期",
                "topic_ids": [items[0]["id"]],
            },
        ).json()
        endpoint = "/api/v1/plans/" + plan["id"]
        payload = update_payload(plan)
        payload["entries"].insert(0, {"topic_id": items[1]["id"], "note": "新增材料"})
        result = client.put(endpoint, json=payload).json()
        assert result["entries"][0]["snapshot"]["topic_id"] == items[1]["id"]
        payload = update_payload(result)
        payload["entries"] = payload["entries"][:1]
        payload["status"] = "archived"
        assert client.put(endpoint, json=payload).status_code == 200
        assert store.topic(items[0]["id"])["decision"] == "selected"


def test_migrate_p2_1_database_backed_up_and_existing_choices_preserved():
    items = selected()
    path = database_path()
    with database() as c:
        c.execute("UPDATE system_state SET state_value='4' WHERE state_key='schema_version'")
        c.execute("DROP TABLE content_plans")
        c.execute("CREATE TABLE user_notes(value TEXT)")
        c.execute("INSERT INTO user_notes VALUES('keep')")
    initialize_database()
    backups = list((path.parent / "backups").glob("radar-before-p3-*.db"))
    assert len(backups) == 1 and database_is_ready()
    with sqlite3.connect(backups[0]) as c:
        assert c.execute("SELECT state_value FROM system_state").fetchone()[0] == "4"
    assert store.topic(items[0]["id"])["decision"] == "selected"
    with database() as c:
        assert c.execute("SELECT value FROM user_notes").fetchone()[0] == "keep"
    initialize_database()
    assert len(list((path.parent / "backups").glob("radar-before-p3-*.db"))) == 1
