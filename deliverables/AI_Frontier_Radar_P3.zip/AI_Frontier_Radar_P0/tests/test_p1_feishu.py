import json
import logging

import httpx
import pytest
from test_p1_ingestion import rss, source

from radar.core.database import initialize_database
from radar.integrations.feishu_sync import FIELD_TYPES, field_configuration, sync_news
from radar.news import store
from radar.news.parser import parse_feed


@pytest.fixture
def ready(monkeypatch):
    initialize_database()
    for name, value in {
        "FEISHU_ENABLED": "true",
        "FEISHU_APP_ID": "test-app",
        "FEISHU_APP_SECRET": "sentinel-app-secret",
        "FEISHU_BITABLE_APP_TOKEN": "testbase",
        "FEISHU_NEWS_TABLE_ID": "testtable",
    }.items():
        monkeypatch.setenv(name, value)
    item = parse_feed(rss(published=False), source(), 100)[0]
    store.save_items([item], store.utc_now())
    return item


def schema(wrong=False):
    mapping, label = field_configuration()
    fields = [{"field_name": name, "type": FIELD_TYPES[key]} for key, name in mapping.items()]
    for field in fields:
        if field["type"] == 3:
            field["property"] = {"options": [{"name": label}]}
    if wrong:
        fields[0]["type"] = 15
    return fields


def ok(data):
    return httpx.Response(200, json={"code": 0, "data": data})


def test_sync_reconciles_uncertain_create_without_duplicates_or_overwriting_review(ready):
    created = []
    remote = []

    def respond(request):
        if request.url.path.endswith("/tenant_access_token/internal"):
            assert json.loads(request.content)["app_secret"] == "sentinel-app-secret"
            return httpx.Response(
                200, json={"code": 0, "tenant_access_token": "sentinel-access-token"}
            )
        assert request.headers["Authorization"] == "Bearer sentinel-access-token"
        if request.url.path.endswith("/fields"):
            return ok({"items": schema()})
        if request.method == "GET":
            return ok({"items": remote, "has_more": False})
        fields = json.loads(request.content)["fields"]
        assert "发布时间" not in fields
        assert fields["审核状态"] == "待核查"
        assert fields["原文链接"]["link"] == ready["original_url"]
        assert isinstance(fields["采集时间"], int)
        created.append(fields)
        remote.append({"record_id": "rec-test", "fields": {"审核状态": "已采用"}})
        raise httpx.ReadTimeout("accepted but response lost", request=request)

    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        first = sync_news(client=client)
        assert first["status"] == "failed" and first["error"] == "network_error"
        second = sync_news(client=client)
        assert second["synced"] == 1
        third = sync_news(client=client)
    assert len(created) == 1 and third["synced"] == 0
    assert remote[0]["fields"]["审核状态"] == "已采用"
    assert store.stats()["synced"] == 1


def test_schema_mismatch_prevents_all_record_writes(ready):
    writes = []

    def respond(request):
        if "/auth/" in request.url.path:
            return httpx.Response(200, json={"code": 0, "tenant_access_token": "token"})
        if request.url.path.endswith("/fields"):
            return ok({"items": schema(wrong=True)})
        writes.append(request)
        return ok({})

    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        result = sync_news(client=client)
    assert result["status"] == "failed" and result["error"] == "table_schema_mismatch"
    assert not writes and store.stats()["synced"] == 0


def test_rate_limit_is_persisted_before_next_manual_sync(ready):
    calls = []

    def respond(request):
        calls.append(request)
        return httpx.Response(429, headers={"Retry-After": "120"})

    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        first = sync_news(client=client)
        second = sync_news(client=client)
    assert first["status"] == second["status"] == "rate_limited"
    assert len(calls) == 1


def test_duplicate_remote_ids_are_not_modified(ready):
    writes = []

    def respond(request):
        if "/auth/" in request.url.path:
            return httpx.Response(200, json={"code": 0, "tenant_access_token": "token"})
        if request.url.path.endswith("/fields"):
            return ok({"items": schema()})
        if request.method == "GET":
            return ok({"items": [{"record_id": "a"}, {"record_id": "b"}]})
        writes.append(request)
        return ok({})

    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        result = sync_news(client=client)
    assert result["error"] == "duplicate_remote_radar_id" and not writes


def test_auth_failure_does_not_return_or_log_remote_secret_body(ready, caplog):
    secret = "sentinel-provider-secret-response"
    with httpx.Client(
        transport=httpx.MockTransport(lambda r: httpx.Response(403, json={"error": secret}))
    ) as client:
        with caplog.at_level(logging.DEBUG):
            result = sync_news(client=client)
    assert result["error"] == "http_403"
    assert secret not in json.dumps(result) + caplog.text
    assert "sentinel-app-secret" not in json.dumps(result) + caplog.text
