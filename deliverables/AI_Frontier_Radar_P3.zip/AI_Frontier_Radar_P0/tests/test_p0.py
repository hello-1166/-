import json
import logging
import sqlite3
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from radar.core.config import provider_status, validate_provider_config
from radar.core.database import database_is_ready, database_path, initialize_database
from radar.integrations.feishu import feishu_status
from radar.main import app


def test_missing_keys_still_starts():
    with TestClient(app) as client:
        assert client.get("/ready").status_code == 200
        status = client.get("/api/v1/llm/providers").json()
        assert set(status["providers"]) == {"openai", "anthropic", "gemini", "deepseek", "qwen"}
        assert all(not row["configured"] for row in status["providers"].values())
        assert not client.get("/api/v1/integrations/feishu/status").json()["configured"]


def test_readiness_fails_without_creating_database(monkeypatch, tmp_path):
    with TestClient(app) as client:
        missing = tmp_path / "missing.db"
        monkeypatch.setenv("RADAR_DB_PATH", str(missing))
        response = client.get("/ready")
        assert response.status_code == 503
        assert response.json()["database"] == "not_ready"
        assert not missing.exists()


@pytest.mark.parametrize("contents", ["invalid sqlite", None, "wrong-version"])
def test_readiness_rejects_broken_schema(contents):
    path = database_path()
    path.parent.mkdir(parents=True)
    if contents == "invalid sqlite":
        path.write_text(contents)
    else:
        with sqlite3.connect(path) as connection:
            if contents:
                connection.execute("CREATE TABLE system_state (state_key TEXT, state_value TEXT)")
                connection.execute("INSERT INTO system_state VALUES ('schema_version', '999')")
    assert not database_is_ready()


def test_reinitialization_preserves_user_state():
    path = initialize_database()
    with sqlite3.connect(path) as connection:
        connection.execute("INSERT INTO system_state VALUES ('user_state', 'keep', '2026-01-01')")
    initialize_database()
    with sqlite3.connect(path) as connection:
        assert connection.execute(
            "SELECT state_value FROM system_state WHERE state_key='user_state'"
        ).fetchone() == ("keep",)


def test_feishu_requires_all_fields(monkeypatch):
    monkeypatch.setenv("FEISHU_ENABLED", " true ")
    fields = [
        "FEISHU_APP_ID",
        "FEISHU_APP_SECRET",
        "FEISHU_BITABLE_APP_TOKEN",
        "FEISHU_NEWS_TABLE_ID",
        "FEISHU_CONTENT_TABLE_ID",
        "FEISHU_SOURCE_TABLE_ID",
    ]
    for name in fields:
        monkeypatch.setenv(name, "test-only")
    assert feishu_status()["configured"]
    for name in fields:
        monkeypatch.setenv(name, " ")
        assert not feishu_status()["configured"]
        monkeypatch.setenv(name, "test-only")
    monkeypatch.setenv("FEISHU_ENABLED", "false")
    assert not feishu_status()["configured"]


def test_provider_requires_key_model_and_optional_base(monkeypatch):
    monkeypatch.setenv("LLM_DEFAULT_PROVIDER", "deepseek")
    monkeypatch.setenv("DEEPSEEK_API_KEY", "test-key")
    monkeypatch.setenv("DEEPSEEK_MODEL", "test-model")
    assert not provider_status()["default_provider_available"]
    monkeypatch.setenv("DEEPSEEK_API_BASE", "https://example.invalid")
    assert provider_status()["default_provider_available"]
    monkeypatch.setenv("LLM_DEFAULT_PROVIDER", "unknown")
    assert not provider_status()["default_provider_available"]


@pytest.mark.parametrize(
    "config",
    [
        {},
        {"providers": []},
        {"providers": {"bad": []}},
        {"providers": {"openai": {"api_key_env": "literal-key"}}},
        {"providers": {"INVALID NAME": {}}},
        {"default_provider_env": [], "providers": {"openai": {}}},
    ],
)
def test_malformed_provider_config_is_rejected(config):
    with pytest.raises(ValueError):
        validate_provider_config(config)


def test_invalid_config_prevents_startup(monkeypatch, tmp_path):
    (tmp_path / "providers.yaml").write_text("providers: []")
    monkeypatch.setenv("RADAR_CONFIG_DIR", str(tmp_path))
    with pytest.raises(RuntimeError, match="Radar initialization failed"), TestClient(app):
        pass


def test_responses_and_logs_do_not_leak_injected_secrets(monkeypatch, tmp_path):
    secrets = {
        "OPENAI_API_KEY": "sentinel-openai-secret-935",
        "OPENAI_MODEL": "sentinel-private-model-935",
        "FEISHU_APP_SECRET": "sentinel-feishu-secret-935",
        "FEISHU_BITABLE_APP_TOKEN": "sentinel-feishu-token-935",
        "N8N_ENCRYPTION_KEY": "sentinel-n8n-key-935",
    }
    for name, value in secrets.items():
        monkeypatch.setenv(name, value)
    with TestClient(app) as client:
        bodies = []
        for endpoint in [
            "/health",
            "/ready",
            "/api/v1/system/config-status",
            "/api/v1/llm/providers",
            "/api/v1/integrations/feishu/status",
        ]:
            response = client.get(endpoint)
            assert response.status_code == 200
            bodies.append(response.text)
    for handler in logging.getLogger("radar").handlers:
        handler.flush()
    log = (tmp_path / "logs" / "radar.log").read_text()
    for value in secrets.values():
        assert value not in "".join(bodies) + log
    record = json.loads(log.splitlines()[0])
    assert record["timestamp"].endswith("+00:00")
    assert record["level"] == "INFO"
    assert Path(tmp_path / "logs").is_dir()


def test_docs_serve_local_assets():
    with TestClient(app) as client:
        docs = client.get("/docs")
        assert docs.status_code == 200
        assert "cdn.jsdelivr.net" not in docs.text
        for asset in ["swagger-ui-bundle.js", "swagger-ui.css", "favicon-32x32.png"]:
            assert client.get("/static/" + asset).status_code == 200
        assert client.get("/openapi.json").json()["info"]["title"] == "AI Frontier Radar API"
