import sqlite3
from datetime import UTC, datetime, timedelta
from email.utils import format_datetime
from pathlib import Path
from xml.sax.saxutils import escape

import httpx
import pytest
from fastapi.testclient import TestClient

from radar.core.database import database_is_ready, database_path, initialize_database
from radar.main import app
from radar.news import ingestion, store
from radar.news.config import Source
from radar.news.parser import canonical_url, parse_feed


def source(key="SRC_TEST_A", name="Test source"):
    return Source(
        source_id=key,
        name=name,
        category="research",
        language="en",
        rss_url="https://example.test/" + key,
        website="https://example.test",
        enabled=True,
    )


def rss(link="https://example.test/news?id=1&utm_source=rss", published=True, days=0):
    date = format_datetime(datetime.now(UTC) - timedelta(days=days))
    publication = "<pubDate>" + date + "</pubDate>" if published else ""
    return (
        '<rss version="2.0"><channel><title>Test</title><link>https://example.test</link>'
        "<description>Test</description><item><title>AI &amp; research</title><link>"
        + escape(link)
        + "</link><guid>"
        + escape(link)
        + "</guid>"
        + publication
        + "<description><![CDATA[<p>Original summary</p><script>bad()</script>]]></description>"
        "</item></channel></rss>"
    ).encode()


def test_p0_migration_creates_backup_and_preserves_data():
    path = database_path()
    path.parent.mkdir(parents=True)
    with sqlite3.connect(path) as c:
        c.execute(
            "CREATE TABLE system_state(state_key TEXT PRIMARY KEY,state_value TEXT,updated_at TEXT)"
        )
        c.execute("INSERT INTO system_state VALUES ('schema_version','1','old')")
        c.execute("INSERT INTO system_state VALUES ('my_setting','keep','old')")
        c.execute("CREATE TABLE user_notes(note TEXT)")
        c.execute("INSERT INTO user_notes VALUES ('do not lose')")
    initialize_database()
    assert database_is_ready()
    backups = list((path.parent / "backups").glob("*.db"))
    assert len(backups) == 1
    with sqlite3.connect(backups[0]) as c:
        assert (
            c.execute(
                "SELECT state_value FROM system_state WHERE state_key='schema_version'"
            ).fetchone()[0]
            == "1"
        )
        assert c.execute("SELECT note FROM user_notes").fetchone()[0] == "do not lose"
    with sqlite3.connect(path) as c:
        assert (
            c.execute(
                "SELECT state_value FROM system_state WHERE state_key='my_setting'"
            ).fetchone()[0]
            == "keep"
        )
        assert c.execute("SELECT note FROM user_notes").fetchone()[0] == "do not lose"
    initialize_database()
    assert len(list((path.parent / "backups").glob("*.db"))) == 1


def test_unknown_schema_is_not_overwritten():
    initialize_database()
    with sqlite3.connect(database_path()) as c:
        c.execute("UPDATE system_state SET state_value='999' WHERE state_key='schema_version'")
    before = database_path().read_bytes()
    with pytest.raises(ValueError, match="Unsupported"):
        initialize_database()
    assert database_path().read_bytes() == before
    assert not database_is_ready()


def test_readiness_checks_p1_tables_and_marks_interrupted_runs():
    initialize_database()
    store.begin_run("abandoned", store.utc_now())
    initialize_database()
    assert store.runs()[0]["status"] == "interrupted"
    assert store.runs()[0]["finished_at"].endswith("+00:00")
    with sqlite3.connect(database_path()) as c:
        c.execute("DROP TABLE news_origins")
    assert not database_is_ready()


def test_canonicalization_preserves_meaningful_url_information():
    assert (
        canonical_url("https://EXAMPLE.test:443/Article?id=1&utm_source=x#part")
        == "https://example.test/Article?id=1"
    )
    assert canonical_url("https://example.test/Article?id=1") != canonical_url(
        "https://example.test/Article?id=2"
    )
    assert canonical_url("https://example.test/Article") != canonical_url(
        "https://example.test/article"
    )
    assert canonical_url("https://example.test/?x=2&x=1").endswith("x=2&x=1")
    with pytest.raises(ValueError):
        canonical_url("javascript:alert(1)")


def test_feed_summary_is_plain_text_and_missing_date_is_explicit():
    item = parse_feed(rss(published=False), source(), 1200)[0]
    assert item["published_at"] is None and item["published_at_raw"] == ""
    assert item["summary"] == "Original summary"
    assert item["title"] == "AI & research"
    assert item["original_url"].endswith("id=1&utm_source=rss")
    assert item["canonical_url"].endswith("id=1")
    atom = (
        b'<feed xmlns="http://www.w3.org/2005/Atom"><title>AI</title><entry>'
        b'<title>Paper</title><id>tag:paper</id><link href="https://example.test/paper"/>'
        b"<published>2026-11-13T10:00:00+08:00</published></entry></feed>"
    )
    assert parse_feed(atom, source(), 100)[0]["published_at"] == "2026-11-13T02:00:00+00:00"
    updated_only = atom.replace(b"<published>", b"<updated>").replace(
        b"</published>", b"</updated>"
    )
    assert parse_feed(updated_only, source(), 100)[0]["published_at"] is None


def test_repeated_and_cross_source_collection_preserves_all_origins(monkeypatch):
    initialize_database()
    rows = [source(), source("SRC_TEST_B", "Second source")]
    monkeypatch.setattr(ingestion, "sources", lambda: rows)

    def respond(request):
        url = "https://example.test/news?id=1&utm_source=" + request.url.path.rsplit("/", 1)[-1]
        return httpx.Response(200, content=rss(url))

    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        first = ingestion.run_ingestion(client=client)
        snapshot = store.news(20, 0, None, "", None)["items"][0]
        second = ingestion.run_ingestion(client=client)
    assert first["inserted"] == 1 and first["duplicates"] == 1
    assert second["inserted"] == 0 and second["duplicates"] == 2
    data = store.news(20, 0, None, "", None)
    assert data["total"] == 1 and len(data["items"][0]["origins"]) == 2
    assert data["items"][0]["first_collected_at"] == snapshot["first_collected_at"]
    assert store.news(20, 0, "SRC_TEST_B", "", None)["total"] == 1
    assert store.news(20, 0, None, "' OR 1=1 --", None)["total"] == 0


def test_partial_failure_is_recorded_and_valid_source_survives(monkeypatch):
    initialize_database()
    monkeypatch.setattr(ingestion, "sources", lambda: [source(), source("SRC_TEST_B")])

    def respond(request):
        return (
            httpx.Response(403)
            if request.url.path.endswith("B")
            else httpx.Response(200, content=rss())
        )

    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        result = ingestion.run_ingestion(client=client)
    assert result["status"] == "partial" and result["errors"] == 1
    assert result["sources"][1]["error"] == "http_403"
    assert store.stats()["total"] == 1
    assert store.runs()[0]["status"] == "partial"


def test_conditional_requests_and_304_preserve_records(monkeypatch):
    initialize_database()
    monkeypatch.setattr(ingestion, "sources", lambda: [source()])
    seen = []

    def respond(request):
        seen.append(request.headers.get("if-none-match"))
        if len(seen) == 1:
            return httpx.Response(200, content=rss(), headers={"ETag": "feed-v1"})
        return httpx.Response(304)

    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        ingestion.run_ingestion(client=client)
        result = ingestion.run_ingestion(client=client)
    assert seen == [None, "feed-v1"]
    assert result["sources"][0]["status"] == "not_modified"
    assert store.stats()["total"] == 1


def test_rate_limit_is_not_retried_and_cooldown_survives_runs(monkeypatch):
    initialize_database()
    monkeypatch.setattr(ingestion, "sources", lambda: [source()])
    calls = []

    def respond(request):
        calls.append(request)
        return httpx.Response(429, headers={"Retry-After": "120"})

    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        first = ingestion.run_ingestion(client=client)
        second = ingestion.run_ingestion(client=client)
    assert first["status"] == "failed" and first["sources"][0]["error"] == "rate_limited"
    assert second["sources"][0]["error"] == "source_cooldown"
    assert len(calls) == 1


@pytest.mark.parametrize(
    "body",
    [
        b"<html>Access challenge</html>",
        b'<!DOCTYPE rss [<!ENTITY x SYSTEM "file:///etc/passwd">]><rss>&x;</rss>',
    ],
)
def test_invalid_or_external_entity_feed_is_not_ingested(monkeypatch, body):
    initialize_database()
    monkeypatch.setattr(ingestion, "sources", lambda: [source()])
    with httpx.Client(
        transport=httpx.MockTransport(lambda r: httpx.Response(200, content=body))
    ) as client:
        result = ingestion.run_ingestion(client=client)
    assert result["status"] == "failed" and result["sources"][0]["error"] == "invalid_feed"
    assert store.stats()["total"] == 0


def test_old_items_are_skipped_unknown_dates_retained_and_run_lock_works(monkeypatch):
    initialize_database()
    monkeypatch.setattr(ingestion, "sources", lambda: [source()])
    with httpx.Client(
        transport=httpx.MockTransport(lambda r: httpx.Response(200, content=rss(days=30)))
    ) as client:
        result = ingestion.run_ingestion(client=client)
        assert result["skipped"] == 1 and store.stats()["total"] == 0
        ingestion.RUN_LOCK.acquire()
        try:
            with pytest.raises(ingestion.IngestionBusy):
                ingestion.run_ingestion(client=client)
        finally:
            ingestion.RUN_LOCK.release()
    item = parse_feed(rss(published=False), source(), 100)[0]
    store.save_items([item], store.utc_now())
    assert store.news(10, 0, None, "", None)["items"][0]["published_at_unknown"]


def test_inbox_api_limits_and_no_credentials_mode():
    with TestClient(app) as client:
        assert client.get("/radar").status_code == 200
        assert client.get("/api/v1/news").json()["total"] == 0
        assert client.get("/api/v1/news?limit=9999").status_code == 422
        assert (
            client.post("/api/v1/ingestion/run", json={"source_ids": ["UNKNOWN"]}).status_code
            == 400
        )
        assert client.post("/api/v1/ingestion/run").status_code == 422
        result = client.post("/api/v1/integrations/feishu/sync", json={})
        assert result.status_code == 409 and result.json()["status"] == "not_configured"
        assert client.get("/api/v1/news/stats").json()["model_calls_enabled"] is False


def test_retry_after_applies_to_other_feeds_on_same_host(monkeypatch):
    initialize_database()
    monkeypatch.setattr(ingestion, "sources", lambda: [source(), source("SRC_TEST_B")])
    calls = []

    def respond(request):
        calls.append(request)
        return httpx.Response(429, headers={"Retry-After": "172800"})

    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        result = ingestion.run_ingestion(client=client)
    assert len(calls) == 1
    assert result["sources"][0]["retry_after_seconds"] == 172800
    assert result["sources"][1]["error"] == "source_cooldown"


def test_n8n_workflow_is_inactive_has_error_branch_and_contains_no_credentials():
    import json

    root = Path(__file__).parents[1]
    workflow = json.loads((root / "workflows/01_news_ingestion.json").read_text())
    assert workflow["active"] is False
    names = {node["name"] for node in workflow["nodes"]}
    for node in workflow["nodes"]:
        assert not node.get("credentials")
        assert node["type"].startswith("n8n-nodes-base.")
    for outputs in workflow["connections"].values():
        for group in outputs["main"]:
            assert all(connection["node"] in names for connection in group)
    request = next(n for n in workflow["nodes"] if n["type"].endswith(".httpRequest"))
    assert request["parameters"]["url"] == "http://api:8000/api/v1/ingestion/run"
    assert request["onError"] == "continueRegularOutput"
    branch = workflow["connections"]["Collection has results"]["main"]
    assert len(branch) == 2 and branch[1][0]["node"] == "Collection needs attention"


@pytest.mark.parametrize(
    "scenario,expected",
    [
        ("large", "feed_too_large"),
        ("redirect", "unsafe_redirect"),
        ("timeout", "network_timeout"),
        ("maintenance", "upstream_unavailable"),
    ],
)
def test_feed_limits_redirects_timeouts_and_retry_after_without_retries(
    monkeypatch, scenario, expected
):
    from radar.news.config import IngestionSettings

    initialize_database()
    monkeypatch.setattr(ingestion, "sources", lambda: [source()])
    config = IngestionSettings(max_feed_bytes=1000, network_retries=0)
    monkeypatch.setattr(ingestion, "settings", lambda: config)
    calls = []

    def respond(request):
        calls.append(request)
        if scenario == "large":
            return httpx.Response(200, content=b"x" * 1001)
        if scenario == "redirect":
            return httpx.Response(302, headers={"Location": "https://other.test/rss"})
        if scenario == "maintenance":
            return httpx.Response(503, headers={"Retry-After": "120"})
        raise httpx.ReadTimeout("test timeout", request=request)

    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
        result = ingestion.run_ingestion(client=client)
    assert result["status"] == "failed" and result["sources"][0]["error"] == expected
    assert len(calls) == 1 and store.stats()["total"] == 0
    if scenario == "maintenance":
        assert result["sources"][0]["retry_after_seconds"] == 120
        assert store.feed_state(source().source_id)["next_allowed_at"]
