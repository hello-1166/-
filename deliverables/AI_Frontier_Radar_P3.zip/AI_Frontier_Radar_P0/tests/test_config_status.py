from fastapi.testclient import TestClient

from radar.main import app


def test_integration_status_endpoints_do_not_expose_secrets():
    with TestClient(app) as client:
        llm = client.get("/api/v1/llm/providers")
        feishu = client.get("/api/v1/integrations/feishu/status")

    assert llm.status_code == 200
    assert feishu.status_code == 200

    body = str(llm.json()) + str(feishu.json())
    assert "sk-" not in body
    assert "app_secret_value" not in body
    assert "access_token" not in body
