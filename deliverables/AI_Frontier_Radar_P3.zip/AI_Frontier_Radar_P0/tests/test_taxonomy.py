import json
import sqlite3
from datetime import UTC, datetime

import pytest
from fastapi.testclient import TestClient

from radar.core.database import database_path, initialize_database
from radar.main import app
from radar.news import store as news_store
from radar.selection import store
from radar.selection.service import screen
from radar.taxonomy.service import config, guess


def article(
    key, title, path=None, summary="A new feature for creators.", source_category="official_company"
):
    return {
        "id": key,
        "title": title,
        "canonical_url": "https://openai.com/" + key,
        "original_url": path or "https://openai.com/" + key,
        "entry_id": key,
        "source_id": "SRC_OPENAI_NEWS",
        "source_name": "OpenAI News",
        "language": "en",
        "category": source_category,
        "summary": summary,
        "published_at": datetime.now(UTC).isoformat(),
        "published_at_raw": "",
    }


def seed():
    initialize_database()
    news_store.save_items(
        [
            article(
                "wallet",
                "Introducing ChatGPT Wallet",
                summary="Built in partnership with banks. Limited availability.",
            ),
            article(
                "api",
                "Gemini Decisions API: Fast multimodal decisions",
                summary="Now available to everyone.",
            ),
        ],
        news_store.utc_now(),
    )
    screen()
    return store.listing(20, 0, None, "", news_store.utc_now())["items"]


@pytest.mark.parametrize(
    "title,path,expected",
    [
        ("Introducing ChatGPT Wallet", "https://openai.com/index/wallet", "product"),
        (
            "Helping caregivers use AI in everyday life",
            "https://openai.com/index/care",
            "work_society",
        ),
        (
            "Work at the Frontier: AI effect on freelance work",
            "https://openai.com/index/jobs",
            "work_society",
        ),
        (
            "We bring Adobe tools closer to Google apps",
            "https://blog.google/company/adobe-google-partnership",
            "business",
        ),
        ("Gemini Decisions API: Fast multimodal decisions", "https://blog.google/api", "developer"),
        ("Introducing AlphaProof Code", "https://deepmind.google/blog/proof", "model_research"),
        (
            "Shield helps technicians with OpenAI",
            "https://openai.com/business/customer-stories/shield",
            "industry",
        ),
        ("Try Tabletop: collaborative spaces", "https://blog.google/tabletop", "product"),
        ("Google Cloud launches Gemini for healthcare", "https://blog.google/health", "industry"),
        ("Introducing GPT-6 model", "https://openai.com/index/gpt", "model_research"),
    ],
)
def test_categories_prioritize_title_and_provenance(title, path, expected):
    value = guess(
        article("x", title, path, summary="An AI model built in partnership with developers."),
        config(),
    )
    assert value["category"] == expected
    assert value["evidence"] != "own_test" and value["stage"] != "published"


@pytest.mark.parametrize(
    "summary,expected",
    [
        ("Now available to everyone.", "available"),
        ("Public preview via waitlist.", "limited"),
        ("We will bring tools to more products.", "announced"),
        ("An interesting feature.", "unknown"),
        ("Not available today.", "unknown"),
        ("Not available today, coming soon.", "announced"),
    ],
)
def test_availability_conservative(summary, expected):
    assert (
        guess(article("x", "An example tool", summary=summary), config())["availability"]
        == expected
    )


def test_manual_axes_and_note_survive_rescreen_and_restart_and_reset_is_scoped():
    items = seed()
    tid = next(t["id"] for t in items if t["title"].startswith("Introducing"))
    with TestClient(app) as c:
        r = c.patch(
            "/api/v1/taxonomy/topic/" + tid,
            json={
                "category": "business",
                "availability": "limited",
                "evidence": "own_test",
                "formats": ["hands_on", "tutorial"],
                "stage": "published",
                "note": "人工记录，未由程序核验",
            },
        )
        assert r.status_code == 200, r.text
        for _ in range(2):
            c.post("/api/v1/selection/run", json={})
    with TestClient(app) as c:
        value = store.topic(tid)["taxonomy"]
        assert value["category"] == "business" and value["stage"] == "published"
        assert value["evidence"] == "own_test" and value["note"].startswith("人工")
        r = c.post(
            "/api/v1/taxonomy/topic/" + tid + "/reset",
            json={"fields": ["category", "availability"]},
        )
        assert r.status_code == 200
        assert r.json()["category"] == "product"
        assert r.json()["evidence"] == "own_test" and r.json()["stage"] == "published"
        assert r.json()["formats"] == ["hands_on", "tutorial"]
        assert store.topic(tid)["decision"] == "pending"  # progress is an independent marker


def test_filters_and_export_include_labels_and_manual_origin():
    items = seed()
    tid = next(t["id"] for t in items if t["title"].startswith("Introducing"))
    with TestClient(app) as c:
        c.patch("/api/v1/topics/" + tid, json={"decision": "selected"})
        c.patch(
            "/api/v1/taxonomy/topic/" + tid,
            json={"availability": "limited", "formats": ["news", "hands_on"]},
        )
        r = c.get(
            "/api/v1/topics?status=selected&category=product&availability=limited&content_format=hands_on"
        )
        assert r.status_code == 200 and r.json()["total"] == 1
        assert c.get("/api/v1/topics?category=industry").json()["total"] == 0
        assert c.get("/api/v1/news?category=developer&availability=available").json()["total"] == 1
        export = c.get("/api/v1/topics/export?category=product").text
        assert "产品与功能更新" in export and "限量或地区开放（人工）" in export
        assert "原始出处" in export and "工具实测" in export
        assert (
            "Introducing ChatGPT Wallet"
            not in c.get("/api/v1/topics/export?category=industry").text
        )
        counts = c.get("/api/v1/taxonomy").json()["counts"]
        assert counts["product"] == 1 and counts["developer"] == 1


@pytest.mark.parametrize(
    "payload",
    [
        {},
        {"category": None},
        {"category": "injected"},
        {"formats": ["news", "news"]},
        {"stage": "delete"},
        {"note": "x" * 501},
        {"extra": "ignored"},
    ],
)
def test_invalid_edits_rejected(payload):
    item = seed()[0]
    with TestClient(app) as c:
        assert c.patch("/api/v1/taxonomy/topic/" + item["id"], json=payload).status_code == 422
        assert (
            c.patch("/api/v1/taxonomy/topic/missing", json={"category": "product"}).status_code
            == 404
        )
        assert c.get("/api/v1/topics?category=invalid").status_code == 422
        assert c.get("/api/v1/news?stage=invalid").status_code == 422


def test_news_labels_separate_from_grouped_topic_labels():
    items = seed()
    item = next(t for t in items if t["title"].startswith("Introducing"))
    with TestClient(app) as c:
        c.patch("/api/v1/taxonomy/news/wallet", json={"category": "business"})
        assert c.get("/api/v1/news?category=business").json()["total"] == 1
        assert store.topic(item["id"])["taxonomy"]["category"] == "product"
        c.post("/api/v1/selection/run", json={})
        assert c.get("/api/v1/news?category=business").json()["total"] == 1


def test_schema3_backup_preserves_decisions_and_model_cache():
    seed()
    path = database_path()
    with sqlite3.connect(path) as c:
        c.execute("DROP TABLE editorial_taxonomy")
        c.execute("UPDATE system_state SET state_value='3' WHERE state_key='schema_version'")
        c.execute(
            "UPDATE editorial_topics SET decision='selected',model_json=?",
            (json.dumps({"headline": "keep model"}),),
        )
    initialize_database()
    screen()
    backups = list((path.parent / "backups").glob("radar-before-p2-1-*.db"))
    assert len(backups) == 1
    with sqlite3.connect(backups[0]) as c:
        assert (
            c.execute(
                "SELECT state_value FROM system_state WHERE state_key='schema_version'"
            ).fetchone()[0]
            == "3"
        )
    with news_store.database() as c:
        assert (
            c.execute("SELECT count(*) FROM editorial_topics WHERE decision='selected'").fetchone()[
                0
            ]
            == 2
        )
        assert all(
            json.loads(r[0])["headline"] == "keep model"
            for r in c.execute("SELECT model_json FROM editorial_topics")
        )
    assert store.listing(20, 0, "selected", "", news_store.utc_now())["total"] == 2
    assert all(
        t["taxonomy"]["stage"] == "selected"
        for t in store.listing(20, 0, "selected", "", news_store.utc_now())["items"]
    )
    initialize_database()
    assert len(list((path.parent / "backups").glob("*.db"))) == 1
