import json
import sqlite3
from datetime import UTC, datetime, timedelta

import httpx
import pytest
from fastapi.testclient import TestClient

from radar.core.database import database_path, initialize_database
from radar.main import app
from radar.news.store import database, save_items, utc_now
from radar.selection import models, store
from radar.selection.articles import article_evidence
from radar.selection.config import SelectionSettings
from radar.selection.ranking import likely_same_event, rank
from radar.selection.service import screen

NOW = datetime.now(UTC)


def article(key="one", title="Introducing Example video model 3 now available", hours=1):
    return {
        "id": key,
        "canonical_url": "https://openai.com/" + key,
        "original_url": "https://openai.com/" + key,
        "entry_id": key,
        "title": title,
        "summary": "A video model demo for creators. " * 5,
        "published_at": (NOW - timedelta(hours=hours)).isoformat() if hours is not None else None,
        "published_at_raw": "",
        "source_id": "SRC_OPENAI",
        "source_name": "OpenAI",
        "language": "en",
        "category": "model",
    }


def seed(*items):
    initialize_database()
    save_items(list(items or [article()]), utc_now())
    screen(NOW)
    return store.listing(100, 0, None, "", utc_now())["items"]


def model_config(monkeypatch, provider="openai"):
    monkeypatch.setenv("SELECTION_MODEL_ENABLED", "true")
    monkeypatch.setenv("LLM_DEFAULT_PROVIDER", provider)
    names = {
        "openai": ("OPENAI_API_KEY", "OPENAI_MODEL"),
        "anthropic": ("ANTHROPIC_API_KEY", "ANTHROPIC_MODEL"),
        "gemini": ("GEMINI_API_KEY", "GEMINI_MODEL"),
        "deepseek": ("DEEPSEEK_API_KEY", "DEEPSEEK_MODEL"),
        "qwen": ("DASHSCOPE_API_KEY", "QWEN_MODEL"),
    }
    key, model = names[provider]
    monkeypatch.setenv(key, "secret-for-tests-only")
    monkeypatch.setenv(model, "model-for-tests-only")
    monkeypatch.setenv("DEEPSEEK_API_BASE", "https://api.deepseek.com")
    monkeypatch.setenv("QWEN_API_BASE", "https://dashscope.aliyuncs.com/compatible-mode/v1")


def assessment(ids=None):
    return {
        "headline": "新视频功能值得试吗",
        "summary": "来源描述了一项视频能力，效果待测试。",
        "reason": "适合创作者关注。",
        "angle": "用相同输入对比新旧效果。",
        "checks": ["确认开放范围与收费条件"],
        "evidence_ids": ids or ["one"],
        "value": 7,
    }


def response(provider, value=None):
    text = json.dumps(value or assessment(), ensure_ascii=False)
    if provider == "anthropic":
        return {
            "stop_reason": "end_turn",
            "content": [{"type": "text", "text": text}],
            "usage": {"input_tokens": 123, "output_tokens": 45},
        }
    if provider == "gemini":
        return {
            "candidates": [{"finishReason": "STOP", "content": {"parts": [{"text": text}]}}],
            "usageMetadata": {"promptTokenCount": 123, "candidatesTokenCount": 45},
        }
    return {
        "choices": [{"finish_reason": "stop", "message": {"content": text}}],
        "usage": {"prompt_tokens": 123, "completion_tokens": 45},
    }


def test_screen_rerun_dedup_stable_human_choices_and_recommendation_slots():
    items = seed(
        article(),
        article("two", "Introducing Example video model 3 now available!"),
        article("three", "New audio assistant pricing available"),
    )
    assert len(items) == 2
    grouped = next(i for i in items if len(i["articles"]) == 2)
    store.decide(grouped["id"], "selected")
    again = screen(NOW)
    assert again["topics"] == 2
    assert store.topic(grouped["id"])["decision"] == "selected"
    assert len(store.topic(grouped["id"])["articles"]) == 2
    store.decide(grouped["id"], "ignored")
    screen(NOW)
    assert store.topic(grouped["id"])["decision"] == "ignored"
    assert all(
        t["id"] != grouped["id"]
        for t in store.listing(20, 0, "recommended", "", utc_now())["items"]
    )


def test_distinct_versions_do_not_merge():
    assert not likely_same_event(
        "New Example video model 3 released", "New Example video model 4 released", 0.82
    )
    assert not likely_same_event("AI model", "AI model", 0.82)


@pytest.mark.parametrize("hours", [None, -24, 200])
def test_missing_future_or_old_dates_are_not_recommended(hours):
    value = rank(article(hours=hours), NOW)
    assert value["timely"] is False
    items = seed(article(hours=hours))
    assert not any(i["recommended"] for i in items)


def test_rules_allow_zero_picks_no_forced_recommendations():
    item = article(title="Abstract theorem and proof", hours=48)
    item["source_id"] = "arxiv_ai"
    item["summary"] = ""
    seed(item)
    assert screen(NOW)["recommended"] == 0


def test_selected_history_survives_expiry_and_export():
    item = seed()[0]
    store.decide(item["id"], "selected")
    screen(NOW + timedelta(days=9))
    assert store.listing(20, 0, "selected", "", utc_now())["total"] == 1
    with TestClient(app) as client:
        text = client.get("/api/v1/topics/export").text
        assert "未独立核查" in text and "https://openai.com/one" in text


def test_migration_v2_backup_preserves_existing_news_and_custom_tables():
    path = database_path()
    path.parent.mkdir(parents=True)
    with sqlite3.connect(path) as c:
        c.execute(
            "CREATE TABLE system_state(state_key TEXT PRIMARY KEY,state_value TEXT,updated_at TEXT)"
        )
        c.execute("INSERT INTO system_state VALUES('schema_version','2','old')")
        c.execute("CREATE TABLE my_notes(value TEXT)")
        c.execute("INSERT INTO my_notes VALUES('keep me')")
    initialize_database()
    backups = list((path.parent / "backups").glob("radar-before-p2-*.db"))
    assert len(backups) == 1
    with sqlite3.connect(backups[0]) as c:
        assert c.execute("SELECT state_value FROM system_state").fetchone()[0] == "2"
    with database() as c:
        assert c.execute("SELECT * FROM my_notes").fetchone()[0] == "keep me"
        assert (
            c.execute(
                "SELECT state_value FROM system_state WHERE state_key='schema_version'"
            ).fetchone()[0]
            == "5"
        )
    initialize_database()
    assert len(list((path.parent / "backups").glob("*.db"))) == 1


def test_api_defaults_no_model_calls_and_validation(monkeypatch):
    with TestClient(app) as client:
        assert client.get("/topics").status_code == 200
        assert client.get("/api/v1/selection/status").json()["model"]["available"] is False
        assert client.post("/api/v1/selection/run").status_code == 422
        assert client.post("/api/v1/selection/run", json={}).status_code == 200
        assert client.get("/api/v1/topics?status=invalid").status_code == 422
        assert (
            client.patch("/api/v1/topics/missing", json={"decision": "selected"}).status_code == 404
        )
        assert (
            client.patch("/api/v1/topics/missing", json={"decision": "publish"}).status_code == 422
        )
        r = client.post("/api/v1/selection/enrich", json={"topic_ids": ["one"]})
        assert r.status_code == 409 and r.json()["error"] == "model_not_configured"


@pytest.mark.parametrize("provider", ["openai", "anthropic", "gemini", "deepseek", "qwen"])
def test_provider_adapters_cache_budget_and_secret_redaction(monkeypatch, provider):
    item = seed()[0]
    model_config(monkeypatch, provider)
    seen = []

    def handle(r):
        seen.append(r)
        if r.method == "GET":
            return httpx.Response(403)
        body = json.loads(r.content)
        assert "tools" not in body
        assert any(k in body for k in ("max_tokens", "max_completion_tokens", "generationConfig"))
        return httpx.Response(200, json=response(provider))

    with httpx.Client(transport=httpx.MockTransport(handle)) as client:
        result = models.enrich([item["id"]], client)
        again = models.enrich([item["id"]], client)
    assert result["status"] == "completed"
    assert again["items"][0]["status"] == "cached"
    assert len([r for r in seen if r.method == "POST"]) == 1
    assert store.usage()["requests"] == 1
    assert store.usage()["input_tokens"] == 123
    saved = store.topic(item["id"])
    assert saved["model"]["verification"] == "unverified"
    assert "secret-for-tests-only" not in json.dumps(saved)
    assert saved["score"] == item["score"]  # model cannot promote the rule shortlist


@pytest.mark.parametrize(
    "failure", ["timeout", "bad_json", "bad_evidence", "rate_limit", "redirect", "truncated"]
)
def test_failed_calls_bounded_redacted_and_do_not_replace_previous_analysis(monkeypatch, failure):
    item = seed()[0]
    model_config(monkeypatch)
    seen = []

    def handle(r):
        if r.method == "GET":
            return httpx.Response(403)
        seen.append(r)
        if failure == "timeout":
            raise httpx.ReadTimeout("secret-for-tests-only", request=r)
        if failure == "bad_json":
            return httpx.Response(200, text="secret-for-tests-only")
        if failure == "rate_limit":
            return httpx.Response(
                429, headers={"Retry-After": "3600"}, text="secret-for-tests-only"
            )
        if failure == "redirect":
            return httpx.Response(302, headers={"Location": "https://evil.test"})
        payload = response(
            "openai", assessment(["invented"]) if failure == "bad_evidence" else None
        )
        if failure == "truncated":
            payload["choices"][0]["finish_reason"] = "length"
        return httpx.Response(200, json=payload)

    with httpx.Client(transport=httpx.MockTransport(handle)) as client:
        result = models.enrich([item["id"]], client)
        if failure == "rate_limit":
            later = models.enrich([item["id"]], client)
            assert later["items"][0]["status"] == "provider_cooldown"
    assert len(seen) == 1
    assert result["items"][0]["status"] == "failed"
    assert "secret-for-tests-only" not in json.dumps(result) + json.dumps(store.usage())
    assert store.topic(item["id"])["model"] is None
    assert store.usage()["requests"] == 1


def test_daily_budget_is_persisted_and_failed_requests_count(monkeypatch):
    items = seed(article(), article("other", "Free image editing app released today"))
    model_config(monkeypatch)
    cfg = SelectionSettings(audience="测试受众", model_daily_requests=1)
    monkeypatch.setattr(models, "settings", lambda: cfg)
    seen = []

    def handle(r):
        if r.method == "POST":
            seen.append(r)
        return httpx.Response(403)

    with httpx.Client(transport=httpx.MockTransport(handle)) as client:
        models.enrich([items[0]["id"]], client)
        result = models.enrich([items[1]["id"]], client)
    assert result["items"][0]["status"] == "daily_limit"
    assert len(seen) == 1
    initialize_database()
    assert store.usage()["requests"] == 1


@pytest.mark.parametrize(
    "url",
    [
        "https://127.0.0.1/private",
        "http://openai.com/a",
        "https://evil.test/a",
        "https://openai.com:999/a",
        "https://user:pass@openai.com/a",
    ],
)
def test_article_reader_never_requests_unapproved_hosts(url):
    seed()
    item = article()
    item["original_url"] = url
    seen = []
    with httpx.Client(transport=httpx.MockTransport(lambda r: seen.append(r))) as client:
        result = article_evidence(item, ["openai.com"], client)
    assert result["kind"] == "rss_summary" and not seen


def test_article_excerpt_removes_script_and_cross_host_redirect_falls_back():
    seed()
    seen = []

    def handle(r):
        seen.append(r)
        return httpx.Response(
            200,
            headers={"Content-Type": "text/html"},
            text="<main>" + "Useful public material. " * 30 + "<script>evil()</script></main>",
        )

    with httpx.Client(transport=httpx.MockTransport(handle)) as client:
        result = article_evidence(article(), ["openai.com"], client)
    assert result["kind"] == "public_page_excerpt" and "evil()" not in result["text"]
    with httpx.Client(
        transport=httpx.MockTransport(
            lambda r: httpx.Response(302, headers={"Location": "https://evil.test"})
        )
    ) as client:
        result = article_evidence(article(), ["openai.com"], client)
    assert result["fetch_status"] == "host_not_allowed"


def test_real_registry_arxiv_category_is_not_promoted_as_ready_product():
    item = article()
    item["source_id"] = "SRC_ARXIV_AI"
    item["category"] = "research"
    value = rank(item, NOW)
    assert value["score"] <= 55
    assert sum(value["dimensions"].values()) == value["score"]
    assert not likely_same_event(
        "Example video model is now available", "Example video model is not now available", 0.82
    )


def test_new_report_joins_existing_event_after_restart_without_losing_selection():
    first = seed()[0]
    store.decide(first["id"], "selected")
    save_items([article("later", "Introducing Example video model 3 now available!")], utc_now())
    initialize_database()
    screen(NOW)
    assert len(store.topic(first["id"])["articles"]) == 2
    assert store.topic(first["id"])["decision"] == "selected"


def test_separated_publication_dates_do_not_merge_recurring_titles():
    items = seed(article(), article("later", hours=100))
    assert len(items) == 2


def test_model_prompt_has_total_size_bound(monkeypatch):
    seed()
    model_config(monkeypatch)
    with httpx.Client(transport=httpx.MockTransport(lambda r: pytest.fail("must not send"))) as c:
        with pytest.raises(models.ModelFailure, match="input_too_large"):
            models.request_model(c, [{"id": "one", "text": "x" * 13000}])
