import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

PWSH = os.getenv("P0_PWSH") or shutil.which("pwsh") or shutil.which("powershell")
pytestmark = pytest.mark.skipif(not PWSH, reason="PowerShell is required for upgrade tests")
ROOT = Path(__file__).parents[1]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def prepare(tmp_path):
    incoming, target = tmp_path / "incoming", tmp_path / "existing"
    for root in [incoming, target]:
        (root / "src/radar").mkdir(parents=True)
    (incoming / "scripts").mkdir()
    shutil.copy(ROOT / "scripts/upgrade_p1.ps1", incoming / "scripts")
    (target / "src/radar/main.py").write_text("old code")
    (incoming / "src/radar/main.py").write_text("new code")
    for root in [incoming, target]:
        (root / "docker-compose.yml").write_text("services: {}")
    (target / ".env").write_bytes(b"N8N_ENCRYPTION_KEY=local-existing-secret\r\n")
    (target / "data").mkdir()
    (target / "data/radar.db").write_bytes(b"user database must stay unchanged")
    (target / "my-notes.txt").write_text("user notes")
    manifest = {
        "files": {
            "src/radar/main.py": digest(b"new code"),
            "docker-compose.yml": digest(b"services: {}"),
        }
    }
    legacy = {
        "allowed_hashes": {"src/radar/main.py": [digest(b"old code")]},
        "normalized_dockerfile_hashes": [],
    }
    (incoming / "release_manifest.json").write_text(json.dumps(manifest))
    (incoming / "p0_upgrade_manifest.json").write_text(json.dumps(legacy))
    return incoming, target, manifest, legacy


def run_upgrade(incoming, target):
    return subprocess.run(
        [
            PWSH,
            "-NoLogo",
            "-NoProfile",
            "-File",
            str(incoming / "scripts/upgrade_p1.ps1"),
            "-ExistingProjectPath",
            str(target),
        ],
        capture_output=True,
        text=True,
        timeout=30,
    )


def test_upgrade_preserves_secrets_database_notes_and_is_repeatable(tmp_path):
    incoming, target, _, _ = prepare(tmp_path)
    secret = (target / ".env").read_bytes()
    data = (target / "data/radar.db").read_bytes()
    result = run_upgrade(incoming, target)
    assert result.returncode == 0, result.stdout + result.stderr
    assert (target / "src/radar/main.py").read_text() == "new code"
    assert (target / ".env").read_bytes() == secret
    assert (target / "data/radar.db").read_bytes() == data
    assert (target / "my-notes.txt").read_text() == "user notes"
    backups = list((target / "backups").glob("*"))
    assert len(backups) == 1
    assert (backups[0] / "src/radar/main.py").read_text() == "old code"
    assert not (backups[0] / ".env").exists()
    again = run_upgrade(incoming, target)
    assert again.returncode == 0 and "already installed" in again.stdout
    assert len(list((target / "backups").glob("*"))) == 1
    assert "local-existing-secret" not in result.stdout + result.stderr


def test_upgrade_stops_before_writing_locally_modified_files(tmp_path):
    incoming, target, _, _ = prepare(tmp_path)
    (target / "src/radar/main.py").write_text("my local custom code")
    result = run_upgrade(incoming, target)
    assert result.returncode != 0 and "manual review" in result.stderr
    assert (target / "src/radar/main.py").read_text() == "my local custom code"
    assert not (target / "backups").exists()


def test_upgrade_verifies_source_checksums_and_paths_before_writing(tmp_path):
    incoming, target, manifest, _ = prepare(tmp_path)
    (incoming / "src/radar/main.py").write_text("tampered payload")
    result = run_upgrade(incoming, target)
    assert result.returncode != 0 and "checksum failed" in result.stderr
    assert (target / "src/radar/main.py").read_text() == "old code"
    manifest["files"] = {"../outside.txt": digest(b"anything")}
    (incoming / "release_manifest.json").write_text(json.dumps(manifest))
    result = run_upgrade(incoming, target)
    assert result.returncode != 0 and "Unsafe release path" in result.stderr


def test_upgrade_accepts_known_docker_mirror_edit(tmp_path):
    incoming, target, manifest, legacy = prepare(tmp_path)
    (target / "Dockerfile").write_text(
        "#\r\nFROM public.ecr.aws/docker/library/python:3.12-slim\r\n"
    )
    (incoming / "Dockerfile").write_text(
        "ARG PYTHON_BASE_IMAGE=python:3.12-slim\nFROM ${PYTHON_BASE_IMAGE}\n"
    )
    legacy["normalized_dockerfile_hashes"] = [digest(b"FROM python:3.12-slim")]
    manifest["files"]["Dockerfile"] = digest((incoming / "Dockerfile").read_bytes())
    (incoming / "release_manifest.json").write_text(json.dumps(manifest))
    (incoming / "p0_upgrade_manifest.json").write_text(json.dumps(legacy))
    result = run_upgrade(incoming, target)
    assert result.returncode == 0, result.stdout + result.stderr
    assert (target / "Dockerfile").read_text().startswith("ARG PYTHON_BASE_IMAGE")
