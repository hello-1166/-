# 架构说明

## P0 组件边界

```text
Windows Host
  |
  +-- Docker Compose
       |
       +-- n8n :5678 (host loopback only)
       |     |
       |     +-- internal HTTP -> api:8000
       |
       +-- FastAPI :8000 (host loopback only)
             |
             +-- SQLite /app/data/radar.db
             +-- config/*.yaml (read-only mount)
             +-- logs/
             +-- provider status (no external calls in P0)
             +-- Feishu status (no external calls in P0)
```

## 后续业务流

```text
Official sources / RSS / APIs / research feeds
        |
        v
Collectors -> Normalization -> Deduplication
        |
        v
News Inbox (Feishu)
        |
        v
Classification -> Scoring -> Evidence verification
        |
        v
Human review
        |
        +--> Xiaohongshu content pack
        |
        +--> Douyin video script / storyboard pack
        |
        v
Manual publish -> Performance tracking
```

## 数据和时间

- 内部时间戳统一使用 UTC ISO 8601。
- 运营日报与发布时间窗口使用 `Asia/Shanghai`。
- 原始新闻发布时间与系统首次采集时间必须分开存储。
- 原始 URL 不应被覆盖成聚合页面 URL。
- 同一事件可有多个报道来源，后续应使用 event/entity 层关联，不应只依赖标题完全相同。

## 可扩展性

P0 使用 SQLite 以降低本地启动复杂度。后续若出现多用户并发、较高写入量或需要复杂查询，再评估 PostgreSQL。飞书作为运营工作台，不应成为唯一的原始数据备份。
