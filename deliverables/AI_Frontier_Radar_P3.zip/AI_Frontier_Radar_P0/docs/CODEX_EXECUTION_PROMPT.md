# 给 Codex 的 P0 执行指令

你正在接手 `AI Frontier Radar V1.0` 项目。请先完整阅读：
- `AGENTS.md`
- `README.md`
- `docs/P0_IMPLEMENTATION_BRIEF.md`
- `docs/ARCHITECTURE.md`
- `docs/P0_ACCEPTANCE_CHECKLIST.md`

## 任务目标
完成 P0 工程初始化，使项目能够在 Windows + Docker Desktop 本地运行。

## 执行步骤

### Step 1 — 仓库检查
1. 检查当前工作目录、Git 状态和现有文件。
2. 不要覆盖用户已有文件。
3. 对照任务书检查当前初始化包是否完整。
4. 输出简短实施计划后再操作。

### Step 2 — 静态检查
1. 检查 Docker Compose YAML 是否有效。
2. 检查 Python 包结构、导入路径和配置文件路径。
3. 检查 `.gitignore` 是否排除 `.env`、SQLite 文件、日志和运行数据。
4. 检查端口是否只绑定到 `127.0.0.1`。
5. 检查 API 响应和日志是否可能泄漏密钥。

### Step 3 — 本地环境准备
1. 如果 `.env` 不存在，执行 `scripts/init_env.ps1`。
2. 不覆盖已有 `.env`。
3. 不要求用户在 P0 阶段提供真实 API Key。
4. 执行 `docker compose config`。

### Step 4 — 构建和启动
1. 执行 `docker compose up -d --build`。
2. 检查 `docker compose ps`。
3. 检查 API 和 n8n 日志。
4. 等待健康检查完成。

### Step 5 — API 验证
依次请求：
- `/health`
- `/ready`
- `/api/v1/system/config-status`
- `/api/v1/llm/providers`
- `/api/v1/integrations/feishu/status`

确认没有密钥值出现在响应中。

### Step 6 — 测试
1. 在容器内执行 `pytest`，或在已安装项目依赖的 Python 环境中执行。
2. 执行 `scripts/smoke_test.ps1`。
3. 如果失败，定位并修复 P0 范围内的问题，再重新测试。

### Step 7 — 最终审查
1. 检查 Git diff。
2. 检查是否误提交 `.env`、数据库或日志。
3. 更新验收清单，但只勾选实际通过项。
4. 输出交付报告。

## 严格禁止
- 不得进入 P1 新闻采集开发。
- 不得编造真实模型 ID 或 API Key。
- 不得自动发布到小红书或抖音。
- 不得将宿主机端口暴露到公网。
- 不得删除用户数据或执行 `docker compose down -v`。
- 不得声称没有运行的测试已经通过。

## 最终报告格式
1. 完成的工作
2. 修改/新增文件
3. 实际执行的命令
4. 测试结果（逐项 PASS/FAIL）
5. 服务访问地址
6. 尚未完成事项
7. 是否满足 P0 验收
8. 建议的下一步（仅提出 P1，不要自行实施）
