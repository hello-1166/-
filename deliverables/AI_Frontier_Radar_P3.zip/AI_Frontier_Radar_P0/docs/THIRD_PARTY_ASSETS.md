# Third-party browser assets

swagger-ui-dist 5.34.1 (Apache-2.0).

Source: https://registry.npmjs.org/swagger-ui-dist/-/swagger-ui-dist-5.34.1.tgz

npm archive integrity was verified against its published SHA-512 integrity field.

Upstream LICENSE and NOTICE are included beside the assets.

SHA-256 checksums:

- `LICENSE`: `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30`
- `NOTICE`: `0d20d1adef18aee3f40dd258172155521ce702ac445cb5f7b7d60ed32dad2fb2`
- `favicon-32x32.png`: `3ed612f41e050ca5e7000cad6f1cbe7e7da39f65fca99c02e99e6591056e5837`
- `swagger-ui-bundle.js`: `36eeb4d5640b9c036b1d0f854499af1cceebbdb260b790a03a18be5e8488fbf5`
- `swagger-ui.css`: `c3cfe8248c4b0b89673600fb829924eafbac6de4bc4b2b06f5f5243483074d0a`
