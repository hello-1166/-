# 飞书集成准备说明

P0 只建立配置检查，不会访问飞书或创建多维表格。

## 1. 准备飞书开放平台应用

在飞书开放平台创建企业自建应用，记录：
- App ID
- App Secret

按实际使用场景申请多维表格相关权限。权限名称可能随飞书开放平台版本调整，以当前控制台显示为准。

## 2. 创建多维表格

建议后续建立一个 Base，包含以下表：
1. News Inbox
2. Source Registry
3. Content Studio
4. Performance Tracker

记录 Base 的 App Token，以及各表的 Table ID。

## 3. 配置 `.env`

填写：
- `FEISHU_ENABLED=true`
- `FEISHU_APP_ID`
- `FEISHU_APP_SECRET`
- `FEISHU_BITABLE_APP_TOKEN`
- `FEISHU_NEWS_TABLE_ID`
- `FEISHU_CONTENT_TABLE_ID`
- `FEISHU_SOURCE_TABLE_ID`

不要把这些值发到聊天、截图或 Git 仓库。

## 4. 后续验证顺序

P1/P2 实施时按以下顺序验证：
1. 获取 tenant_access_token。
2. 读取 Base 和表元数据。
3. 创建一条测试记录。
4. 读取该记录并核对字段。
5. 测试失败重试和限流处理。
6. 确认最小权限原则。

P0 不需要现在填写这些值。没有飞书凭据时，服务仍应正常启动，状态接口显示未配置即可。
