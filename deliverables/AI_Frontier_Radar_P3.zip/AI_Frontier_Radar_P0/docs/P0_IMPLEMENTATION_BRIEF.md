# AI Frontier Radar V1.0 — P0 工程实施任务书

版本：0.1.0  
里程碑：P0 / 工程初始化  
运行环境：Windows + Docker Desktop  
运营平台：小红书 + 抖音  
运行模式：本地半自动化  
运营数据库：飞书多维表格  
模型策略：多模型 API，统一配置入口

## 1. 项目目标

建立一个本地可运行、可测试、可扩展的工程底座，为后续全球 AI 新闻采集、去重、分类、事实核查、内容生成和双平台人工发布提供基础设施。

P0 的完成标准不是“新闻系统已经上线”，而是 Docker、n8n、Python API、SQLite、配置管理和基础测试能够稳定运行。

## 2. P0 范围

### 必须完成
1. 建立规范的 Git 项目结构。
2. 提供 Docker Compose 本地环境。
3. 启动 n8n，Web UI 仅绑定本机回环地址。
4. 启动 Python FastAPI 服务。
5. Python 服务启动时初始化 SQLite。
6. 提供 `/health`、`/ready`、模型配置状态、飞书配置状态接口。
7. 提供 `.env.example` 和 PowerShell 初始化脚本。
8. 提供多模型 provider 配置骨架。
9. 提供飞书应用配置骨架。
10. 建立 pytest 测试和 P0 验收文档。

### 不在 P0 范围
- RSS/网页/社交平台真实采集。
- 新闻事件聚类和智能去重。
- 新闻重要性评分执行逻辑。
- 事实核查 Agent。
- 小红书图文自动排版。
- 抖音配音、剪辑、视频渲染。
- 小红书/抖音自动发布。
- 云服务器部署。
- 多 Agent 自主协作。

## 3. 目标架构

- n8n：工作流编排，容器内通过 `http://api:8000` 访问 Python API。
- Python FastAPI：业务 API 和后续处理服务。
- SQLite：P0 本地运行状态与基础元数据。
- 飞书多维表格：后续新闻和内容运营工作台；P0 仅配置状态检查。
- LiteLLM：作为后续多模型调用适配层的技术候选；P0 不发起真实模型请求。
- Docker Compose：本地统一启动与停止。

## 4. 安全要求

1. `.env` 不得提交 Git。
2. 不在代码、日志、API 响应中输出密钥。
3. n8n 和 Python API 的宿主机端口必须绑定 `127.0.0.1`。
4. n8n 必须配置持久化卷和独立加密密钥。
5. 不将 n8n 加密密钥、飞书 App Secret 或模型 API Key 写进工作流 JSON。
6. 不在 P0 中启用外网 webhook。
7. 不自动发布任何社交平台内容。

## 5. 多模型策略

P0 只实现配置状态检查，不执行真实 API 调用。

预留 provider：
- OpenAI
- Anthropic
- Google Gemini
- DeepSeek
- Qwen / DashScope OpenAI-compatible endpoint

模型 ID 必须由用户根据其实际账号可用模型填写。不得猜测模型 ID，不得在代码中硬编码。

后续 P2/P3 再验证 LiteLLM 对各 provider 的当前调用参数、模型命名、API Base 和成本记录方式。

## 6. 飞书策略

P0 仅预留以下配置：
- App ID
- App Secret
- Bitable App Token
- News Table ID
- Content Table ID
- Source Table ID

P0 不创建表、不写入记录、不调用飞书 API。后续阶段先确认权限和字段，再实现最小读写测试。

## 7. 交付物

- 项目目录和源代码
- Dockerfile / docker-compose.yml
- `.env.example`
- PowerShell 初始化与 smoke test 脚本
- FastAPI 健康检查接口
- SQLite 初始化
- 飞书和多模型配置状态接口
- pytest 测试
- 架构、配置和验收文档
- Codex 执行记录

## 8. Codex 执行要求

严格按照 `AGENTS.md` 和 `docs/CODEX_EXECUTION_PROMPT.md` 执行。先检查文件，再实施；每一步运行测试；报告真实测试结果；不得跳到 P1。
