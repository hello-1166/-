from typing import Literal

from fastapi import APIRouter, HTTPException

from radar.news.store import database
from radar.taxonomy.service import ResetRequest, TaxonomyPatch, config, update

router = APIRouter()


@router.get("/api/v1/taxonomy", tags=["taxonomy"])
def taxonomy_options():
    cfg = config()
    with database() as c:
        counts = {
            r["category"]: r["count"]
            for r in c.execute(
                "SELECT x.category,count(*) AS count FROM editorial_taxonomy x "
                "JOIN editorial_topics t ON t.id=x.entity_id "
                "WHERE x.entity_type='topic' AND t.active=1 GROUP BY x.category"
            )
        }
    return {
        "labels": cfg["labels"],
        "counts": counts,
        "automatic_model_calls": False,
        "scope": "规则归类，不代表已开放、已核实或已完成实测；制作进度独立于选题决定",
    }


@router.patch("/api/v1/taxonomy/{entity_type}/{entity_id}", tags=["taxonomy"])
def edit(entity_type: Literal["news", "topic"], entity_id: str, payload: TaxonomyPatch):
    result = update(entity_type, entity_id, patch=payload)
    if not result:
        raise HTTPException(404, "Item not found")
    return result


@router.post("/api/v1/taxonomy/{entity_type}/{entity_id}/reset", tags=["taxonomy"])
def reset(entity_type: Literal["news", "topic"], entity_id: str, payload: ResetRequest):
    result = update(entity_type, entity_id, reset=payload.fields)
    if not result:
        raise HTTPException(404, "Item not found")
    return result
