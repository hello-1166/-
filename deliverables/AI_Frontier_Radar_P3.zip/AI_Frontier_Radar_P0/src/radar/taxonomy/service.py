from __future__ import annotations

import hashlib
import json
import re
from typing import Literal
from urllib.parse import urlsplit

from pydantic import BaseModel, ConfigDict, Field, model_validator

from radar.core.config import load_yaml
from radar.news.store import database, utc_now

Category = Literal[
    "model_research", "product", "developer", "industry", "business", "work_society", "unclassified"
]
Availability = Literal["available", "limited", "announced", "research", "unknown"]
Evidence = Literal["official", "research", "customer", "own_test", "unknown"]
Format = Literal["news", "hands_on", "explainer", "observation", "tutorial"]
Stage = Literal["pending", "selected", "producing", "published", "saved"]
Axis = Literal["category", "availability", "evidence", "formats", "stage"]
AXES = ("category", "availability", "evidence", "formats", "stage")


class TaxonomyPatch(BaseModel):
    model_config = ConfigDict(extra="forbid")
    category: Category | None = None
    availability: Availability | None = None
    evidence: Evidence | None = None
    formats: list[Format] | None = Field(default=None, max_length=5)
    stage: Stage | None = None
    note: str | None = Field(default=None, max_length=500)

    @model_validator(mode="after")
    def nonempty(self):
        if not self.model_fields_set or any(
            getattr(self, k) is None for k in self.model_fields_set
        ):
            raise ValueError("Provide at least one non-null classification field")
        if self.formats is not None and len(self.formats) != len(set(self.formats)):
            raise ValueError("Duplicate content format")
        return self


class ResetRequest(BaseModel):
    fields: list[Axis] = Field(min_length=1, max_length=5)


def config() -> dict:
    value = load_yaml("taxonomy.yaml")
    for name in ("category_rules", "availability_rules"):
        axis = "category" if name == "category_rules" else "availability"
        for rule in value[name]:
            if rule["value"] not in value["labels"][axis]:
                raise ValueError("Unknown taxonomy rule value")
            re.compile(rule["pattern"])
    return value


def guess(item: dict, cfg: dict, decision: str = "pending") -> dict:
    text = item["title"] + "\n" + item.get("summary", "")
    path = urlsplit(item["original_url"]).path.lower()
    category = "unclassified"
    reasons = []
    # Source provenance is stronger than generic words such as 'model' or 'API'.
    research = "arxiv" in item["source_id"].lower()
    customer = "/customer-stories/" in path
    if research:
        category = "model_research"
        reasons.append("arXiv来源，按研究材料归类")
    elif customer:
        category = "industry"
        reasons.append("来源路径为客户故事，按应用案例归类")
    elif re.search(r"partnership|acquisition|merger", path):
        category = "business"
        reasons.append("来源路径含合作或收购线索")
    else:
        for part in (item["title"], item.get("summary", "")):
            match = next(
                (
                    rule
                    for rule in cfg["category_rules"]
                    if re.search(rule["pattern"], part, flags=re.I)
                ),
                None,
            )
            if match:
                category = match["value"]
                reasons.append(match["reason"])
                break
    research_material = research or bool(
        re.search(
            r"\balphaproof\b|\bformal verification\b|\bpaper\b|\btheorem\b|研究论文|技术论文",
            item["title"],
            re.I,
        )
    )
    evidence = (
        "research"
        if research_material
        else "customer"
        if customer
        else "official"
        if item.get("category") in {"official_company", "research", "developer_ecosystem"}
        else "unknown"
    )
    availability = "research" if research else "unknown"
    # Only infer from explicit wording; research category alone does not establish product access.
    if not research:
        for rule in cfg["availability_rules"]:
            if rule["value"] == "available" and re.search(
                r"\b(not|isn.t|aren.t)\s+(yet\s+)?available\b|尚未开放|暂未开放", text, re.I
            ):
                continue
            if re.search(rule["pattern"], text, flags=re.I | re.S):
                availability = rule["value"]
                reasons.append(rule["reason"])
                break
        if research_material and availability == "unknown":
            availability = "research"
    formats = {
        "model_research": ["explainer"],
        "product": ["news"],
        "developer": ["explainer", "news"],
        "industry": ["observation"],
        "business": ["observation", "news"],
        "work_society": ["observation"],
    }.get(category, [])
    return {
        "category": category,
        "availability": availability,
        "evidence": evidence,
        "formats": formats,
        "stage": {"selected": "selected", "ignored": "saved"}.get(decision, "pending"),
        "reasons": reasons or ["标题与摘要不足以判断，保留待分类"],
        "scope": "依据主条目标题、RSS摘要与来源路径；不是事实核查",
    }


def save_auto(c, kind: str, entity_id: str, suggested: dict, fingerprint: str) -> None:
    previous = c.execute(
        "SELECT * FROM editorial_taxonomy WHERE entity_type=? AND entity_id=?", (kind, entity_id)
    ).fetchone()
    if previous and previous["fingerprint"] == fingerprint:
        return
    manual = json.loads(previous["manual_json"]) if previous else {}
    effective = {key: manual.get(key, suggested[key]) for key in AXES}
    c.execute(
        "INSERT INTO editorial_taxonomy "
        "(entity_type,entity_id,category,availability,evidence,formats_json,stage,"
        "manual_json,suggested_json,note,fingerprint,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?) "
        "ON CONFLICT(entity_type,entity_id) DO UPDATE SET category=excluded.category,"
        "availability=excluded.availability,evidence=excluded.evidence,"
        "formats_json=excluded.formats_json,stage=excluded.stage,"
        "suggested_json=excluded.suggested_json,fingerprint=excluded.fingerprint,"
        "updated_at=excluded.updated_at",
        (
            kind,
            entity_id,
            effective["category"],
            effective["availability"],
            effective["evidence"],
            json.dumps(effective["formats"]),
            effective["stage"],
            json.dumps(manual),
            json.dumps(suggested, ensure_ascii=False),
            previous["note"] if previous else "",
            fingerprint,
            utc_now(),
        ),
    )


def refresh(c) -> None:
    cfg = config()
    version = json.dumps(cfg, sort_keys=True, ensure_ascii=False)
    # In-place upserts avoid replacing user labels/decisions. Called within the screen transaction.
    for row in c.execute("SELECT * FROM news_items").fetchall():
        item = dict(row)
        fingerprint = hashlib.sha256(
            (version + json.dumps(item, sort_keys=True)).encode()
        ).hexdigest()
        save_auto(c, "news", item["id"], guess(item, cfg), fingerprint)
    for row in c.execute(
        "SELECT t.id AS topic_id,t.decision,n.* FROM editorial_topics t "
        "JOIN news_items n ON n.id=t.anchor_news_id"
    ).fetchall():
        item = dict(row)
        suggested = guess(item, cfg, item["decision"])
        # Topic tags have their own manual overrides. A corrected article remains visible as an
        # individual source; do not silently propagate a manual claim across a grouped event.
        fingerprint = hashlib.sha256(
            (version + json.dumps(item, sort_keys=True)).encode()
        ).hexdigest()
        save_auto(c, "topic", item["topic_id"], suggested, fingerprint)


def read(c, kind: str, entity_id: str) -> dict | None:
    row = c.execute(
        "SELECT * FROM editorial_taxonomy WHERE entity_type=? AND entity_id=?", (kind, entity_id)
    ).fetchone()
    if not row:
        return None
    value = dict(row)
    value["formats"] = json.loads(value.pop("formats_json"))
    value["manual_fields"] = sorted(json.loads(value.pop("manual_json")))
    value["suggested"] = json.loads(value.pop("suggested_json"))
    value.pop("fingerprint")
    return value


def update(
    kind: str, entity_id: str, patch: TaxonomyPatch | None = None, reset: list[str] | None = None
) -> dict | None:
    with database() as c:
        # Acquire write lock before reading overrides to prevent concurrent lost updates.
        c.execute("BEGIN IMMEDIATE")
        old = read(c, kind, entity_id)
        if not old:
            return None
        manual = {key: old[key] for key in old["manual_fields"]}
        values = patch.model_dump(exclude_unset=True) if patch else {}
        note = values.pop("note", old["note"])
        manual.update(values)
        for key in reset or []:
            manual.pop(key, None)
        effective = {key: manual.get(key, old["suggested"][key]) for key in AXES}
        c.execute(
            "UPDATE editorial_taxonomy SET category=?,availability=?,evidence=?,"
            "formats_json=?,stage=?,manual_json=?,note=?,updated_at=? "
            "WHERE entity_type=? AND entity_id=?",
            (
                effective["category"],
                effective["availability"],
                effective["evidence"],
                json.dumps(effective["formats"]),
                effective["stage"],
                json.dumps(manual),
                note,
                utc_now(),
                kind,
                entity_id,
            ),
        )
        return read(c, kind, entity_id)


def filters(
    alias: str, category=None, availability=None, evidence=None, content_format=None, stage=None
) -> tuple[str, list]:
    sql, args = "", []
    for column, value in [
        ("category", category),
        ("availability", availability),
        ("evidence", evidence),
        ("stage", stage),
    ]:
        if value:
            sql += f" AND {alias}.{column}=?"
            args.append(value)
    if content_format:
        sql += f" AND EXISTS (SELECT 1 FROM json_each({alias}.formats_json) WHERE value=?)"
        args.append(content_format)
    return sql, args
