'use strict';
window.RadarTaxonomy = (() => {
  let labels = {}, counts = {};
  const names = {category:'资讯类别',availability:'开放情况',evidence:'证据类型',formats:'内容栏目',stage:'制作进度'};
  const make = (tag,text,cls) => {const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
  async function request(path, options={}) {
    const r=await fetch(path,{...options,headers:{'Content-Type':'application/json'}});
    const d=await r.json();if(!r.ok)throw new Error(typeof d.detail==='string'?d.detail:'分类保存失败，请检查输入');return d;
  }
  async function init() {
    const d=await request('/api/v1/taxonomy');labels=d.labels;counts=d.counts;
    document.querySelectorAll('[data-tax-filter]').forEach(select => {
      const axis=select.dataset.taxFilter, old=select.value;
      select.replaceChildren(new Option('全部'+names[axis],''));
      Object.entries(labels[axis]).forEach(([value,label])=>select.append(new Option(label,value)));
      select.value=old;
    });
    const chips=document.getElementById('category-counts');
    if(chips){chips.replaceChildren();Object.entries(labels.category).forEach(([key,label])=>{
      const b=make('button',`${label} ${counts[key]||0}`,'tax-chip');b.type='button';
      b.onclick=()=>{document.querySelector('[data-tax-filter="category"]').value=key;document.getElementById('filters').requestSubmit();};chips.append(b);
    });}
  }
  function query(p) {
    document.querySelectorAll('[data-tax-filter]').forEach(s=>{if(s.value)p.set(s.dataset.taxFilter==='formats'?'content_format':s.dataset.taxFilter,s.value);});return p;
  }
  function badges(t) {
    const box=make('div',undefined,'tax-badges');if(!t)return box;
    ['category','availability','evidence','stage'].forEach(axis=>{
      const b=make('span',labels[axis]?.[t[axis]]||t[axis],'tax-badge'+(axis==='availability'?' tax-state':''));
      b.title=names[axis]+' · '+(t.manual_fields.includes(axis)?'人工标记':'规则建议');box.append(b);
    });
    t.formats.forEach(f=>box.append(make('span',labels.formats?.[f]||f,'tax-badge tax-format')));
    if(t.manual_fields.length)box.append(make('span','含人工调整','tax-manual'));
    return box;
  }
  function editor(t,kind,id,onSaved,onError) {
    const box=make('details',undefined,'taxonomy-editor');box.append(make('summary','调整分类与制作进度'));
    if(!t){box.append(make('p','分类尚未生成，请重新初筛。'));return box;}
    box.append(make('p','仅依据标题、RSS摘要与来源。栏目是制作计划；“本人实测”“已发布”为人工标记，不代表系统验证。制作进度与选题选择分别保存。','hint'));
    if(t.suggested.reasons?.length)box.append(make('p','规则依据：'+t.suggested.reasons.join('；'),'hint'));
    const controls={},grid=make('div',undefined,'tax-edit-grid');
    ['category','availability','evidence','stage'].forEach(axis=>{
      const label=make('label',names[axis]),s=make('select');s.setAttribute('aria-label',names[axis]+'设置');
      Object.entries(labels[axis]).forEach(([value,name])=>s.append(new Option(name,value)));
      s.value=t[axis];label.append(s);controls[axis]=s;grid.append(label);
    });box.append(grid);
    const formats=make('fieldset'),legend=make('legend','内容栏目（可多选）');formats.append(legend);
    Object.entries(labels.formats).forEach(([value,name])=>{
      const label=make('label'),check=make('input');check.type='checkbox';check.value=value;check.checked=t.formats.includes(value);check.setAttribute('aria-label',name+'栏目');label.append(check,document.createTextNode(name));formats.append(label);
    });box.append(formats);
    const noteLabel=make('label','人工备注（例如原文链接、开放条件或实测日期）'),note=make('textarea');note.maxLength=500;note.value=t.note;note.rows=2;note.setAttribute('aria-label','分类备注');noteLabel.append(note);box.append(noteLabel);
    const actions=make('div',undefined,'topic-actions'),save=make('button','保存分类'),reset=make('button','恢复自动分类'),feedback=make('p',undefined,'hint');
    save.type=reset.type='button';
    async function execute(fn){save.disabled=reset.disabled=true;feedback.textContent='正在保存…';try{await fn();await onSaved();}catch(e){feedback.textContent=e.message;onError(e.message);}finally{save.disabled=reset.disabled=false;}}
    save.onclick=()=>execute(async()=>{
      const patch={};Object.entries(controls).forEach(([key,s])=>{if(s.value!==t[key])patch[key]=s.value;});
      const chosen=Array.from(formats.querySelectorAll('input:checked'),c=>c.value);
      if(JSON.stringify(chosen.slice().sort())!==JSON.stringify(t.formats.slice().sort()))patch.formats=chosen;
      if(note.value!==t.note)patch.note=note.value;
      if(!Object.keys(patch).length){feedback.textContent='没有修改。';return;}
      await request(`/api/v1/taxonomy/${kind}/${id}`,{method:'PATCH',body:JSON.stringify(patch)});
    });
    reset.onclick=()=>{
      if(!confirm('恢复资讯类别、开放情况、证据类型与内容栏目的规则建议？人工制作进度和备注会保留。'))return;
      execute(()=>request(`/api/v1/taxonomy/${kind}/${id}/reset`,{method:'POST',body:JSON.stringify({fields:['category','availability','evidence','formats']})}));
    };
    actions.append(save,reset);box.append(actions,feedback);return box;
  }
  return {init,query,badges,editor};
})();
