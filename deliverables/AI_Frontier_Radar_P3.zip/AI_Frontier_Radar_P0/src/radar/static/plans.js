'use strict';
const $ = id => document.getElementById(id);
const fields = ['title','audience','content_format','status','theme','hook','outline','checks','visuals','script','xhs'];
const statuses = {draft:'策划中',checking:'待核实',ready:'待录制',recorded:'已录制',published:'已发布',archived:'已归档'};
let current = null, topics = [], entries = [], dirty = false, busy = false, offset = 0;
function node(tag, text, cls) {const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;}
function msg(text) {$('message').textContent=text;}
function time(value) {return value ? new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',dateStyle:'short',timeStyle:'short'}).format(new Date(value)) : '发布时间未知';}
async function api(path, options={}) {
  const r=await fetch(path,{...options,headers:{'Content-Type':'application/json'}});
  const data=await r.json();if(!r.ok)throw new Error(typeof data.detail==='string'?data.detail:`请求失败 ${r.status}，请检查输入长度和选题状态`);return data;
}
function markDirty(value=true) {dirty=value;$('dirty').textContent=value?'有未保存修改':'';}
function mayLeave() {return !dirty || confirm('有未保存的策划内容。确定放弃修改并切换吗？');}
function safeLink(url, text) {
  const a=node('a',text);try{const u=new URL(url);if(['http:','https:'].includes(u.protocol))a.href=u.href;}catch(_){/* keep text */}
  a.target='_blank';a.rel='noopener noreferrer';return a;
}
async function task(fn) {
  if(busy)return;busy=true;document.querySelectorAll('button').forEach(b=>b.disabled=true);
  $('editor').inert=true;$('composer').inert=true;
  try{await fn();}catch(e){msg(e.message);}finally{busy=false;$('editor').inert=false;$('composer').inert=false;document.querySelectorAll('button').forEach(b=>b.disabled=false);['prev','next'].forEach(id=>$(id).disabled=$(id).dataset.enabled!=='yes');}
}
async function loadList() {
  const params=new URLSearchParams({limit:20,offset});if($('plan-filter').value)params.set('status',$('plan-filter').value);
  const data=await api('/api/v1/plans?'+params);$('plan-list').replaceChildren();
  data.items.forEach(p=>{const b=node('button',p.title,'plan-link'+(current?.id===p.id?' active':''));b.type='button';b.append(node('small',`${statuses[p.status]} · ${p.topic_count} 个事件 · ${time(p.updated_at)}`));b.onclick=()=>{if(mayLeave())task(()=>openPlan(p.id));};$('plan-list').append(b);});
  if(!data.items.length)$('plan-list').append(node('p','暂无策划，点击“新建内容策划”开始。','hint'));
  $('pages').textContent=`共 ${data.total} 期 · 第 ${offset/20+1} 页`;
  // Handlers also guard page limits; task unlocks buttons after rendering.
  $('prev').dataset.enabled=offset>0?'yes':'no';$('next').dataset.enabled=offset+20<data.total?'yes':'no';
}
function pool(target, selectedIds=[]) {
  $(target).replaceChildren();const included=new Set(entries.map(e=>e.snapshot.topic_id));
  topics.forEach(t=>{
    if(target==='extra-pool'&&included.has(t.id))return;
    const row=node('div',undefined,'pool-row'),label=node('label'),check=node('input');check.type='checkbox';check.value=t.id;check.checked=selectedIds.includes(t.id);
    check.onchange=()=>{if(target==='topic-pool')markDirty();};label.append(check,node('span',t.title));row.append(label,node('small',`${time(t.published_at)} · ${t.articles.length} 篇来源 · 待核实`));
    if(t.articles[0])row.append(safeLink(t.articles[0].original_url,'查看原文 ↗'));$(target).append(row);
  });
  if(!$(target).children.length)$(target).append(node('p',target==='topic-pool'?'暂无已选题。先到选题工作台点击“加入选题”。':'没有其他已选题可添加。','hint'));
}
async function loadPool(selectedIds=[]) {
  topics=[];let page=0,total=1;
  while(topics.length<total){const d=await api(`/api/v1/topics?status=selected&limit=100&offset=${page}`);topics.push(...d.items);total=d.total;page+=100;if(!d.items.length)break;}
  $('pool-count').textContent=`已选题 ${topics.length} 条`;pool('topic-pool',selectedIds);pool('extra-pool');
}
function checked(target) {return [...$(target).querySelectorAll('input:checked')].map(c=>c.value);}
function renderEntries() {
  $('entries').replaceChildren();
  entries.forEach((e,index)=>{
    const s=e.snapshot,c=node('article',undefined,'entry-card');c.append(node('h4',`${index+1}. ${s.title}`));
    c.append(node('p',`加入时快照：${time(s.snapshot_at)} · 来源内容仍需核实`));
    const details=node('details');details.append(node('summary','来源、摘要与待核实项'));
    s.articles.forEach(a=>{details.append(safeLink(a.original_url,`${a.source_name}：${a.title}`),node('p',`发布：${time(a.published_at)}`),node('p',a.summary||'来源未提供摘要，请阅读原文。','source-summary'));});
    const ul=node('ul');s.checks.forEach(t=>ul.append(node('li',t)));details.append(ul);c.append(details);
    const label=node('label','本条角度、核实记录与画面备注'),area=node('textarea');area.rows=3;area.maxLength=4000;area.value=e.note;area.oninput=()=>{e.note=area.value;markDirty();};label.append(area);c.append(label);
    const actions=node('div',undefined,'entry-actions');
    [['上移',-1],['下移',1]].forEach(([title,step])=>{const b=node('button',title);b.type='button';b.onclick=()=>{const next=index+step;if(next<0||next>=entries.length)return;[entries[index],entries[next]]=[entries[next],entries[index]];renderEntries();markDirty();};actions.append(b);});
    const remove=node('button','移出本期');remove.type='button';remove.onclick=()=>{if(entries.length===1){msg('每期至少保留一个事件；不再制作可将进度改为“已归档”。');return;}if(!confirm('将此事件及其本期备注移出？原始选题保留。'))return;entries.splice(index,1);renderEntries();pool('extra-pool');markDirty();};actions.append(remove);c.append(actions);$('entries').append(c);
  });
}
function showPlan(p) {
  current=p;entries=structuredClone(p.entries);fields.forEach(k=>$('editor').elements.namedItem(k).value=p[k]);
  $('editor').querySelectorAll('[name=platform]').forEach(c=>c.checked=p.platforms.includes(c.value));
  $('saved-at').textContent=`已保存 · ${time(p.updated_at)} · 版本 ${p.revision}`;
  $('composer').hidden=true;$('editor').hidden=false;renderEntries();pool('extra-pool');markDirty(false);
  history.replaceState(null,'','/plans?id='+encodeURIComponent(p.id));
}
async function openPlan(id) {const p=await api('/api/v1/plans/'+encodeURIComponent(id));showPlan(p);await loadList();}
async function save() {
  if(!$('editor').reportValidity())return false;
  const value={revision:current.revision,entries:entries.map(e=>({topic_id:e.snapshot.topic_id,note:e.note})),platforms:[...$('editor').querySelectorAll('[name=platform]:checked')].map(c=>c.value)};
  fields.forEach(k=>value[k]=$('editor').elements.namedItem(k).value);
  const p=await api('/api/v1/plans/'+current.id,{method:'PUT',body:JSON.stringify(value)});showPlan(p);await loadList();return true;
}
$('editor').oninput=()=>markDirty();$('editor').onchange=()=>markDirty();
$('editor').onsubmit=e=>{e.preventDefault();task(async()=>{if(await save())msg('策划已保存到本地。');});};
$('export').onclick=()=>task(async()=>{if(!await save())return;const r=await fetch(`/api/v1/plans/${current.id}/export`);if(!r.ok)throw new Error('导出失败，策划已保存，可重试');const url=URL.createObjectURL(await r.blob());const a=node('a');a.href=url;a.download=`radar-plan-${current.id}.md`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);msg('已保存并导出。可将材料包上传到现有 Plus，完善稿件后粘贴回来。');});
$('create').onclick=()=>task(async()=>{
  const ids=checked('topic-pool');if(!ids.length){msg('请先勾选至少一条已选题。');return;}
  if(ids.length>30){msg('每期最多选择30个事件，请精简材料。');return;}
  const title=$('new-title').value.trim()||(ids.length===1?topics.find(t=>t.id===ids[0]).title:'本期 AI 资讯策划');
  const checks='待核实：原文日期、版本、开放地区、费用与账号条件。\n区分官方宣称、第三方测试与本人实测。\n记录核实依据和仍未知的条件。';
  const p=await api('/api/v1/plans',{method:'POST',body:JSON.stringify({title,topic_ids:ids,content_format:$('new-format').value,checks})});showPlan(p);await loadList();msg('策划已创建。先填写本期主旨，再核实材料、安排画面。');
});
$('add-entries').onclick=()=>{const ids=checked('extra-pool');if(entries.length+ids.length>30){msg('每期最多30个事件。');return;}ids.forEach(id=>{const t=topics.find(t=>t.id===id);entries.push({snapshot:{topic_id:id,title:t.title,articles:t.articles,checks:t.analysis.checks||[],snapshot_at:new Date().toISOString()},note:''});});renderEntries();pool('extra-pool');if(ids.length)markDirty();};
$('new-plan').onclick=()=>{if(!mayLeave())return;task(async()=>{await loadPool();current=null;entries=[];$('new-title').value='';$('composer').hidden=false;$('editor').hidden=true;history.replaceState(null,'','/plans');markDirty(false);await loadList();});};
$('new-title').oninput=()=>markDirty();$('new-format').onchange=()=>markDirty();
$('refresh-pool').onclick=()=>task(()=>loadPool(checked('topic-pool')));
$('plan-filter').onchange=()=>task(async()=>{offset=0;await loadList();});
$('prev').onclick=()=>{if($('prev').dataset.enabled==='yes')task(async()=>{offset-=20;await loadList();});};
$('next').onclick=()=>{if($('next').dataset.enabled==='yes')task(async()=>{offset+=20;await loadList();});};
window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
task(async()=>{const params=new URLSearchParams(location.search);const preselect=params.get('topic');await loadPool(preselect?[preselect]:[]);await loadList();const id=params.get('id');if(id)await openPlan(id);else if(preselect){const t=topics.find(t=>t.id===preselect);if(t)$('new-title').value=t.title;}});
