from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

import yaml


def config_dir() -> Path:
    return Path(os.getenv("RADAR_CONFIG_DIR", "config"))


def load_yaml(filename: str) -> dict[str, Any]:
    path = config_dir() / filename
    if not path.exists():
        raise FileNotFoundError(f"Required configuration file not found: {path}")
    with path.open("r", encoding="utf-8") as file:
        data = yaml.safe_load(file) or {}
    if not isinstance(data, dict):
        raise ValueError(f"Configuration root must be a mapping: {path}")
    return data


def env_value(name: str | None) -> str | None:
    if not name:
        return None
    value = os.getenv(name, "").strip()
    return value or None


def validate_provider_config(config: dict[str, Any]) -> None:
    """Reject malformed config without including config values in errors."""
    env_name = re.compile(r"^[A-Z][A-Z0-9_]*$")
    default_env = config.get("default_provider_env", "LLM_DEFAULT_PROVIDER")
    if not isinstance(default_env, str) or not env_name.fullmatch(default_env):
        raise ValueError("Invalid default provider environment variable name")
    providers = config.get("providers")
    if not isinstance(providers, dict) or not providers:
        raise ValueError("Provider configuration must contain a non-empty mapping")
    for name, item in providers.items():
        if not isinstance(name, str) or not re.fullmatch(r"[a-z][a-z0-9_]*", name):
            raise ValueError("Invalid provider name")
        if not isinstance(item, dict):
            raise ValueError("Each provider must be a mapping")
        for field in ("api_key_env", "model_env", "api_base_env"):
            value = item.get(field)
            if field == "api_base_env" and value is None:
                continue
            if not isinstance(value, str) or not env_name.fullmatch(value):
                raise ValueError("Invalid provider environment variable reference")


def provider_status() -> dict[str, Any]:
    config = load_yaml("providers.yaml")
    validate_provider_config(config)
    default_env = config.get("default_provider_env", "LLM_DEFAULT_PROVIDER")
    default_provider = os.getenv(default_env, "openai").strip().lower()

    result: dict[str, Any] = {
        "default_provider": default_provider,
        "providers": {},
    }

    for provider_name, item in config.get("providers", {}).items():
        key_name = item.get("api_key_env")
        model_name = item.get("model_env")
        api_key_present = bool(env_value(key_name))
        model_present = bool(env_value(model_name))
        api_base_present = (
            True if not item.get("api_base_env") else bool(env_value(item.get("api_base_env")))
        )
        result["providers"][provider_name] = {
            "configured": api_key_present and model_present and api_base_present,
            "api_key_present": api_key_present,
            "model_id_present": model_present,
            "api_base_present": api_base_present,
        }

    result["default_provider_available"] = bool(
        result["providers"].get(default_provider, {}).get("configured", False)
    )
    return result
