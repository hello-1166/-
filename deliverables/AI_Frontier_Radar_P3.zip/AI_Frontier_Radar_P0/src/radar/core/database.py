from __future__ import annotations

import os
import sqlite3
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

from radar.core.schema import SCHEMA_VERSION, STATEMENTS


def database_path() -> Path:
    return Path(os.getenv("RADAR_DB_PATH", "data/radar.db"))


def initialize_database() -> Path:
    path = database_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(path, timeout=10)) as connection:
        exists = connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='system_state'"
        ).fetchone()
        row = (
            connection.execute(
                "SELECT state_value FROM system_state WHERE state_key='schema_version'"
            ).fetchone()
            if exists
            else None
        )
        version = row[0] if row else None
        if version not in (None, "1", "2", "3", "4", SCHEMA_VERSION):
            raise ValueError("Unsupported database schema version")
        if version in ("1", "2", "3", "4"):
            backup_dir = path.parent / "backups"
            backup_dir.mkdir(exist_ok=True)
            milestone = "p3" if version == "4" else "p2-1"
            backup = backup_dir / ("radar-before-" + milestone + "-" + uuid4().hex + ".db")
            with closing(sqlite3.connect(backup)) as destination:
                connection.backup(destination)
        with connection:
            connection.execute("PRAGMA foreign_keys=ON")
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                "CREATE TABLE IF NOT EXISTS system_state ("
                "state_key TEXT PRIMARY KEY, state_value TEXT NOT NULL, "
                "updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
            )
            for statement in STATEMENTS:
                connection.execute(statement)
            connection.execute(
                "UPDATE ingestion_runs SET status='interrupted', finished_at=? "
                "WHERE status='running'",
                (datetime.now(UTC).isoformat(),),
            )
            connection.execute(
                "UPDATE editorial_model_calls SET status='interrupted',finished_at=? "
                "WHERE status='running'",
                (datetime.now(UTC).isoformat(),),
            )
            connection.execute(
                "INSERT INTO system_state (state_key, state_value) VALUES ('schema_version', ?) "
                "ON CONFLICT(state_key) DO UPDATE SET state_value=excluded.state_value, "
                "updated_at=CURRENT_TIMESTAMP",
                (SCHEMA_VERSION,),
            )
    return path


def database_is_ready() -> bool:
    path = database_path()
    if not path.exists():
        return False
    try:
        with closing(sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)) as connection:
            row = connection.execute(
                "SELECT state_value FROM system_state WHERE state_key = 'schema_version'"
            ).fetchone()
            tables = {
                r[0]
                for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")
            }
        required = {
            "news_items",
            "news_origins",
            "feed_state",
            "ingestion_runs",
            "editorial_topics",
            "editorial_members",
            "editorial_model_calls",
            "editorial_taxonomy",
            "content_plans",
        }
        return row is not None and row[0] == SCHEMA_VERSION and required.issubset(tables)
    except sqlite3.Error:
        return False
