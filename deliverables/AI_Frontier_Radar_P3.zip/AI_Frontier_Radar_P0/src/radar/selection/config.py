from __future__ import annotations

import os

from pydantic import BaseModel, Field

from radar.core.config import load_yaml, provider_status


class SelectionSettings(BaseModel):
    audience: str = Field(min_length=1, max_length=200)
    lookback_days: int = Field(default=7, ge=1, le=30)
    max_items: int = Field(default=1000, ge=1, le=3000)
    recommendation_threshold: int = Field(default=65, ge=0, le=100)
    recommendation_limit: int = Field(default=10, ge=1, le=30)
    cluster_similarity: float = Field(default=0.82, ge=0.75, le=1)
    article_hosts: list[str] = Field(default_factory=list, max_length=30)
    model_batch_limit: int = Field(default=3, ge=1, le=10)
    model_daily_requests: int = Field(default=12, ge=1, le=100)
    model_max_output_tokens: int = Field(default=1600, ge=200, le=4000)
    model_timeout_seconds: int = Field(default=35, ge=5, le=60)


def settings() -> SelectionSettings:
    return SelectionSettings.model_validate(load_yaml("selection.yaml"))


def model_status() -> dict:
    status = provider_status()
    enabled = os.getenv("SELECTION_MODEL_ENABLED", "false").strip().lower() == "true"
    return {
        "enabled": enabled,
        "configured": status["default_provider_available"],
        "available": enabled and status["default_provider_available"],
        "provider": status["default_provider"],
        "automatic_calls": False,
    }
