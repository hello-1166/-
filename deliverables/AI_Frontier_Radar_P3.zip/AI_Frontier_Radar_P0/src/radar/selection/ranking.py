from __future__ import annotations

import re
from datetime import UTC, datetime
from difflib import SequenceMatcher

# Fixed word boundaries avoid matching e.g. 'api' inside 'capital'.
PATTERNS = {
    "release": (
        r"\b(releas\w*|launch\w*|introduc\w*|announc\w*|available|new|unveil\w*)\b"
        r"|发布|上线|开放|推出"
    ),
    "useful": (
        r"\b(video|image|audio|voice|creat\w*|work\w*|app|assistant|agent\w*"
        r"|edit\w*|design|coding|code|model|search)\b|视频|图像|语音|创作|办公|助手|智能体|设计|编程|模型|搜索"
    ),
    "demo": (
        r"\b(demo\w*|video|image|audio|voice|tutorial|how.to|hands.on|try|edit\w*"
        r"|design)\b|演示|视频|图像|语音|教程|实测|试用|编辑|设计"
    ),
    "access": (
        r"\b(free|open.source|price|pricing|cheaper|cost|download|available|api)\b"
        r"|免费|开源|价格|降价|成本|下载|开放"
    ),
    "research": (
        r"\b(paper|theorem|proof|benchmark|dataset|framework|survey)\b"
        r"|论文|定理|证明|基准|数据集|综述"
    ),
}
STOP = {"a", "an", "the", "of", "in", "on", "and", "for", "to", "with", "ai", "new"}


def terms(title: str) -> set[str]:
    words = set(re.findall(r"[a-z0-9]+(?:[.-][a-z0-9]+)*", title.lower())) - STOP
    # Chinese bigrams allow conservative matching without adding a tokenizer dependency.
    for phrase in re.findall(r"[\u4e00-\u9fff]+", title):
        words.update(phrase[i : i + 2] for i in range(len(phrase) - 1))
    return words


def likely_same_event(left: str, right: str, threshold: float) -> bool:
    a, b = terms(left), terms(right)
    if len(a & b) < 3:
        return False

    # Distinct model versions or quantities must not be merged automatically.
    def digits(s):
        return set(re.findall(r"\d+(?:\.\d+)*", s))

    negatives = r"\b(not|never|no|deny|denies|fake)\b|并未|否认|不支持|无法|尚未"
    if bool(re.search(negatives, left.lower())) != bool(re.search(negatives, right.lower())):
        return False
    if digits(left) != digits(right):
        return False
    jaccard = len(a & b) / len(a | b)
    return (
        jaccard >= threshold and SequenceMatcher(None, left.lower(), right.lower()).ratio() >= 0.7
    )


def rank(item: dict, now: datetime) -> dict:
    text = (item["title"] + " " + item["summary"]).lower()
    flags = {key: bool(re.search(pattern, text)) for key, pattern in PATTERNS.items()}
    published = item.get("published_at")
    age = None
    if published:
        try:
            dt = datetime.fromisoformat(published.replace("Z", "+00:00"))
            if dt.tzinfo:
                age = (now - dt.astimezone(UTC)).total_seconds() / 3600
        except ValueError:
            pass
    timely = age is not None and 0 <= age <= 168
    freshness = 20 if timely and age <= 24 else 14 if timely and age <= 72 else 6 if timely else 0
    dimensions = {
        "时效性": freshness,
        "受众相关": 25 if flags["useful"] else 5,
        "变化线索": min(20, 12 * flags["release"] + 8 * flags["access"]),
        "演示潜力": 15 if flags["demo"] else 3,
        "来源可追溯": 10,
        "材料完整度": 10 if len(item["summary"]) >= 100 else 4 if item["summary"] else 0,
    }
    score = sum(dimensions.values())
    reasons = []
    if flags["release"]:
        reasons.append("标题或摘要含发布/开放线索，需确认实际开放条件")
    if flags["useful"]:
        reasons.append("含创作、办公或工具能力线索，可能与目标受众有关")
    if flags["demo"]:
        reasons.append("可能适合录屏或前后对比，仍需实际测试")
    if flags["access"]:
        reasons.append("含成本/获取方式线索，需核对价格和地区限制")
    if (
        flags["research"]
        or "arxiv" in item["source_id"].lower()
        or item.get("category") == "research"
    ):
        adjusted = min(55, max(0, score - 15))
        dimensions["研究材料调整"] = adjusted - score
        score = adjusted
        reasons.append("偏研究材料，不能直接推断已可作为产品使用")
    if not reasons:
        reasons.append("尚未识别明确的大众使用价值，可人工查看原文")
    checks = ["核对原文日期、版本、开放地区与收费条件", "官方描述不等于独立实测结果"]
    if not timely:
        checks.insert(0, "原始发布时间未知、在未来或已超时，不进入自动推荐")
    if not item["summary"]:
        checks.insert(0, "来源无摘要，目前仅凭标题初筛")
    return {
        "score": max(0, score),
        "dimensions": dimensions,
        "reasons": reasons,
        "checks": checks,
        "timely": timely,
        "angle": "用一个真实任务验证这次变化，对比结果、成本和使用限制",
        "evidence_level": "rss_summary" if item["summary"] else "title_only",
    }
