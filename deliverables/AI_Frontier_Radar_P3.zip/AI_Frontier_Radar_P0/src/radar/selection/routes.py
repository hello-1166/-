from pathlib import Path
from typing import Literal

from fastapi import APIRouter, HTTPException, Query, Response
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from radar.news.store import database, utc_now
from radar.selection import store
from radar.selection.config import model_status, settings
from radar.selection.models import ModelFailure, enrich
from radar.selection.service import last_screen, screen
from radar.taxonomy.service import Availability, Category, Evidence, Format, Stage, config

router = APIRouter()


class ScreenRequest(BaseModel):
    pass


class Decision(BaseModel):
    decision: Literal["pending", "selected", "ignored"]


class EnrichRequest(BaseModel):
    topic_ids: list[str] = Field(min_length=1, max_length=10)


@router.get("/topics", include_in_schema=False)
def topics_page():
    return FileResponse(Path(__file__).parents[1] / "static" / "topics.html")


@router.get("/api/v1/selection/status", tags=["selection"])
def status():
    cfg = settings()
    with database() as c:
        counts = dict(
            c.execute(
                "SELECT COALESCE(sum(active=1),0) AS total,"
                "COALESCE(sum(decision='selected'),0) AS selected,"
                "COALESCE(sum(decision='ignored'),0) AS ignored FROM editorial_topics"
            ).fetchone()
        )
        recommended = c.execute(
            "SELECT count(*) FROM editorial_topics WHERE active=1 AND recommended=1 "
            "AND decision='pending' AND expires_at>=?",
            (utc_now(),),
        ).fetchone()[0]
    return {
        "milestone": "P2",
        "audience": cfg.audience,
        "counts": {**counts, "recommended": recommended},
        "model": model_status(),
        "budget": {
            **store.usage(),
            "daily_limit": cfg.model_daily_requests,
            "batch_limit": cfg.model_batch_limit,
            "max_output_tokens": cfg.model_max_output_tokens,
        },
        "last_screen": last_screen(),
        "verification": "unverified",
        "rule_automation": True,
    }


@router.post("/api/v1/selection/run", tags=["selection"])
def run(payload: ScreenRequest, response: Response):
    result = screen()
    if result["status"] == "busy":
        response.status_code = 409
    return result


@router.get("/api/v1/topics", tags=["selection"])
def topics(
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    status: Literal["recommended", "selected", "ignored", "pending"] | None = None,
    q: str = Query(default="", max_length=200),
    category: Category | None = None,
    availability: Availability | None = None,
    evidence: Evidence | None = None,
    content_format: Format | None = None,
    stage: Stage | None = None,
):
    return store.listing(
        limit, offset, status, q, utc_now(), category, availability, evidence, content_format, stage
    )


@router.patch("/api/v1/topics/{topic_id}", tags=["selection"])
def update_topic(topic_id: str, payload: Decision):
    item = store.decide(topic_id, payload.decision)
    if not item:
        raise HTTPException(404, "Topic not found")
    # Refresh pending recommendation slots after a human decision.
    screen()
    return store.topic(topic_id)


@router.post("/api/v1/selection/enrich", tags=["selection"])
def analyze(payload: EnrichRequest, response: Response):
    try:
        return enrich(payload.topic_ids)
    except ModelFailure as e:
        response.status_code = 409
        return {"status": "unavailable", "error": str(e)}


@router.get("/api/v1/topics/export", tags=["selection"])
def export_topics(
    category: Category | None = None,
    availability: Availability | None = None,
    evidence: Evidence | None = None,
    content_format: Format | None = None,
    stage: Stage | None = None,
):
    items = store.listing(
        100, 0, "selected", "", utc_now(), category, availability, evidence, content_format, stage
    )["items"]
    lines = [
        "# AI 前沿雷达：人工选题清单",
        "",
        "仅为选题材料，未独立核查，不是可直接发布稿件。",
        "",
    ]
    labels = config()["labels"]
    for item in items:
        lines += ["## " + item["title"], "", f"规则分：{item['score']}/100（编辑估计）", ""]
        tags = item["taxonomy"]
        if tags:
            lines += ["分类与制作标记（非核查结论）："]
            for axis in ("category", "availability", "evidence", "stage"):
                origin = "人工" if axis in tags["manual_fields"] else "规则"
                lines += ["- " + labels[axis][tags[axis]] + "（" + origin + "）"]
            lines += ["- 内容栏目：" + "、".join(labels["formats"][f] for f in tags["formats"])]
            if tags["note"]:
                lines += ["- 人工备注：" + tags["note"]]
            lines += [""]
        if item["model"]:
            lines += ["模型摘要（待核实）：" + item["model"]["summary"], ""]
        lines += ["待核实："] + ["- " + s for s in item["analysis"]["checks"]]
        if item["model"]:
            lines += ["- " + s for s in item["model"]["checks"]]
        lines += ["", "原始出处："] + [
            "- " + a["source_name"] + "：" + a["original_url"] for a in item["articles"]
        ]
        lines += [""]
    if len(items) == 100:
        lines += ["本次最多导出100项，请在工作台核对其余选题。"]
    return Response(
        "\n".join(lines),
        media_type="text/markdown; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="radar-topics.md"'},
    )
