from __future__ import annotations

import re
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit

import httpx

from radar.news.ingestion import cooldown_until, retry_after_seconds
from radar.news.store import set_state, state_value, utc_now


class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.skip = 0
        self.chunks = []
        self.article = 0
        self.article_chunks = []

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style", "nav", "footer", "header", "noscript", "svg"}:
            self.skip += 1
        if tag in {"article", "main"}:
            self.article += 1

    def handle_endtag(self, tag):
        if tag in {"script", "style", "nav", "footer", "header", "noscript", "svg"}:
            self.skip = max(0, self.skip - 1)
        if tag in {"article", "main"}:
            self.article = max(0, self.article - 1)

    def handle_data(self, data):
        if not self.skip:
            self.chunks.append(data)
            if self.article:
                self.article_chunks.append(data)


def article_evidence(item: dict, hosts: list[str], client: httpx.Client) -> dict:
    """Best-effort public HTML excerpt, never a claim that full text was obtained."""
    fallback = {
        "id": item["id"],
        "title": item["title"],
        "url": item["original_url"],
        "text": item["summary"][:6000],
        "kind": "rss_summary",
        "fetch_status": "unavailable",
    }
    url = item["original_url"]
    if len(url) > 4096:
        return {**fallback, "fetch_status": "url_too_large"}
    for _ in range(3):
        try:
            p = urlsplit(url)
            port = p.port
        except ValueError:
            return {**fallback, "fetch_status": "invalid_url"}
        if (
            p.scheme != "https"
            or p.hostname not in hosts
            or p.username
            or p.password
            or port not in (None, 443)
        ):
            return {**fallback, "fetch_status": "host_not_allowed"}
        cooldown = state_value("article_cooldown:" + p.hostname)
        if cooldown and cooldown > utc_now():
            return {**fallback, "fetch_status": "cooldown"}
        try:
            with client.stream(
                "GET",
                url,
                headers={
                    "User-Agent": "AI-Frontier-Radar/0.3 public-reader",
                    "Accept": "text/html",
                },
            ) as r:
                if r.status_code in (301, 302, 303, 307, 308):
                    url = urljoin(url, r.headers.get("location", ""))
                    continue
                if r.status_code == 429 or (r.status_code == 503 and r.headers.get("Retry-After")):
                    set_state(
                        "article_cooldown:" + p.hostname,
                        cooldown_until(retry_after_seconds(r.headers.get("Retry-After"))),
                    )
                    return {**fallback, "fetch_status": "rate_limited"}
                if r.status_code != 200 or "text/html" not in r.headers.get("content-type", ""):
                    return {**fallback, "fetch_status": "not_public_html"}
                raw = bytearray()
                for chunk in r.iter_bytes():
                    raw.extend(chunk)
                    if len(raw) > 1_000_000:
                        return {**fallback, "fetch_status": "too_large"}
                parser = TextExtractor()
                parser.feed(raw.decode(r.encoding or "utf-8", errors="replace"))
                text = re.sub(r"\s+", " ", " ".join(parser.article_chunks or parser.chunks)).strip()
                if len(text) < 200:
                    return {**fallback, "fetch_status": "insufficient_text"}
                return {
                    **fallback,
                    "text": text[:6000],
                    "kind": "public_page_excerpt",
                    "fetch_status": "excerpt_only",
                }
        except (httpx.HTTPError, ValueError):
            return {**fallback, "fetch_status": "network_error"}
    return {**fallback, "fetch_status": "redirect_limit"}
