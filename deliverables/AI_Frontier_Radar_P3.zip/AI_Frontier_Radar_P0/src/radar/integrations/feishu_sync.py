from __future__ import annotations

import os
import re
from datetime import UTC, datetime
from threading import Lock

import httpx

from radar.core.config import load_yaml
from radar.news import store
from radar.news.ingestion import cooldown_until, retry_after_seconds

BASE_URL = "https://open.feishu.cn/open-apis"
SYNC_LOCK = Lock()
REQUIRED = [
    "FEISHU_APP_ID",
    "FEISHU_APP_SECRET",
    "FEISHU_BITABLE_APP_TOKEN",
    "FEISHU_NEWS_TABLE_ID",
]
FIELD_TYPES = {
    "radar_id": 1,
    "title": 1,
    "original_url": 15,
    "source_name": 1,
    "published_at": 5,
    "collected_at": 5,
    "review_status": 3,
}


class FeishuFailure(Exception):
    def __init__(self, code: str, retry_after: int = 0):
        self.code = code
        self.retry_after = retry_after
        super().__init__(code)


def sync_configuration() -> dict:
    missing = [name for name in REQUIRED if not os.getenv(name, "").strip()]
    enabled = os.getenv("FEISHU_ENABLED", "false").strip().lower() == "true"
    return {
        "enabled": enabled,
        "configured": enabled and not missing,
        "missing_environment_variables": missing,
        "mode": "manual_insert_only",
        "remote_credentials_verified": False,
    }


def field_configuration() -> tuple[dict, str]:
    config = load_yaml("feishu_fields.yaml")
    fields = config.get("fields")
    label = config.get("pending_review_label")
    if (
        not isinstance(fields, dict)
        or set(fields) != set(FIELD_TYPES)
        or not all(isinstance(v, str) and v.strip() for v in fields.values())
        or len(set(fields.values())) != len(fields)
        or not isinstance(label, str)
        or not label.strip()
    ):
        raise FeishuFailure("invalid_field_configuration")
    if any(char in fields["radar_id"] for char in '[]"\\\r\n'):
        raise FeishuFailure("invalid_field_configuration")
    return fields, label


class FeishuClient:
    def __init__(self, client: httpx.Client):
        self.client = client
        self.token = ""
        app = os.environ["FEISHU_BITABLE_APP_TOKEN"].strip()
        table = os.environ["FEISHU_NEWS_TABLE_ID"].strip()
        if not all(re.fullmatch(r"[A-Za-z0-9_-]+", item) for item in (app, table)):
            raise FeishuFailure("invalid_table_identifiers")
        self.table_path = f"/bitable/v1/apps/{app}/tables/{table}"

    def request(self, method: str, path: str, **kwargs) -> dict:
        headers = {"Authorization": "Bearer " + self.token} if self.token else {}
        try:
            response = self.client.request(
                method, BASE_URL + path, headers=headers, follow_redirects=False, **kwargs
            )
        except httpx.HTTPError:
            raise FeishuFailure("network_error") from None
        if response.status_code == 429:
            raise FeishuFailure(
                "rate_limited", retry_after_seconds(response.headers.get("Retry-After"))
            )
        if response.status_code != 200:
            raise FeishuFailure("http_" + str(response.status_code))
        try:
            data = response.json()
        except ValueError:
            raise FeishuFailure("invalid_response") from None
        if not isinstance(data, dict):
            raise FeishuFailure("invalid_response")
        if data.get("code") != 0:
            code = data.get("code")
            raise FeishuFailure(
                "feishu_" + str(code) if isinstance(code, int) else "invalid_response"
            )
        return data

    def authenticate(self) -> None:
        data = self.request(
            "POST",
            "/auth/v3/tenant_access_token/internal",
            json={
                "app_id": os.environ["FEISHU_APP_ID"].strip(),
                "app_secret": os.environ["FEISHU_APP_SECRET"].strip(),
            },
        )
        token = data.get("tenant_access_token")
        if not isinstance(token, str) or not token:
            raise FeishuFailure("invalid_response")
        self.token = token

    def validate_schema(self, mapping: dict, label: str) -> None:
        fields, page_token = [], None
        for _ in range(10):
            params = {"page_size": 100}
            if page_token:
                params["page_token"] = page_token
            data = self.request("GET", self.table_path + "/fields", params=params).get("data", {})
            fields.extend(data.get("items", []))
            if not data.get("has_more"):
                break
            page_token = data.get("page_token")
            if not page_token:
                raise FeishuFailure("invalid_response")
        else:
            raise FeishuFailure("too_many_table_fields")
        found = {f.get("field_name"): f for f in fields}
        for logical, name in mapping.items():
            if found.get(name, {}).get("type") != FIELD_TYPES[logical]:
                raise FeishuFailure("table_schema_mismatch")
        options = found[mapping["review_status"]].get("property", {}).get("options", [])
        if label not in {o.get("name") for o in options}:
            raise FeishuFailure("review_option_missing")

    def existing_record(self, radar_id: str, field_name: str) -> str | None:
        # IDs are generated UUIDs; never interpolate arbitrary source text into this filter.
        if not re.fullmatch(r"[a-f0-9-]{36}", radar_id):
            raise FeishuFailure("invalid_news_identifier")
        data = self.request(
            "GET",
            self.table_path + "/records",
            params={
                "page_size": 2,
                "filter": f'CurrentValue.[{field_name}] = "{radar_id}"',
            },
        ).get("data", {})
        records = data.get("items", [])
        if len(records) > 1 or data.get("has_more"):
            raise FeishuFailure("duplicate_remote_radar_id")
        if not records:
            return None
        record_id = records[0].get("record_id")
        if not isinstance(record_id, str) or not record_id:
            raise FeishuFailure("invalid_response")
        return record_id

    def create_record(self, item: dict, mapping: dict, label: str) -> str:
        fields = {
            mapping["radar_id"]: item["id"],
            mapping["title"]: item["title"],
            mapping["original_url"]: {"link": item["original_url"], "text": "原文"},
            mapping["source_name"]: item["source_name"],
            mapping["review_status"]: label,
            mapping["collected_at"]: int(
                datetime.fromisoformat(item["first_collected_at"]).timestamp() * 1000
            ),
        }
        if item["published_at"]:
            fields[mapping["published_at"]] = int(
                datetime.fromisoformat(item["published_at"]).timestamp() * 1000
            )
        data = self.request("POST", self.table_path + "/records", json={"fields": fields})
        record_id = data.get("data", {}).get("record", {}).get("record_id")
        if not isinstance(record_id, str) or not record_id:
            raise FeishuFailure("invalid_response")
        return record_id


def sync_news(limit: int = 25, client: httpx.Client | None = None) -> dict:
    configuration = sync_configuration()
    if not configuration["configured"]:
        return {"status": "not_configured", "synced": 0, "errors": 0, **configuration}
    cooldown = store.state_value("feishu_next_allowed_at")
    if cooldown and datetime.fromisoformat(cooldown) > datetime.now(UTC):
        return {"status": "rate_limited", "synced": 0, "errors": 0, "next_allowed_at": cooldown}
    if not SYNC_LOCK.acquire(blocking=False):
        return {"status": "busy", "synced": 0, "errors": 0}
    owned = client is None
    result = {"status": "completed", "synced": 0, "errors": 0}
    try:
        pending = store.pending_sync(limit)
        if not pending:
            return result
        mapping, label = field_configuration()
        client = client or httpx.Client(timeout=12)
        service = FeishuClient(client)
        service.authenticate()
        service.validate_schema(mapping, label)
        for item in pending:
            try:
                record = service.existing_record(item["id"], mapping["radar_id"])
                # Reconcile uncertain previous creates; never overwrite remote human review fields.
                record = record or service.create_record(item, mapping, label)
                store.record_sync(item["id"], record, None)
                result["synced"] += 1
            except FeishuFailure as error:
                store.record_sync(item["id"], None, error.code)
                result.update(status="partial" if result["synced"] else "failed", error=error.code)
                result["errors"] += 1
                if error.retry_after:
                    raise
        return result
    except FeishuFailure as error:
        result.update(status="partial" if result["synced"] else "failed", error=error.code)
        result["errors"] = max(result["errors"], 1)
        if error.retry_after:
            until = cooldown_until(error.retry_after)
            store.set_state("feishu_next_allowed_at", until)
            result.update(status="rate_limited", next_allowed_at=until)
        return result
    finally:
        if owned and client is not None:
            client.close()
        SYNC_LOCK.release()
