from __future__ import annotations

from radar.core.config import provider_status


def llm_configuration_status() -> dict[str, object]:
    # Return non-secret configuration status. Does not make external API calls.
    return provider_status()
