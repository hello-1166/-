"""Local editorial planning, with source snapshots and human-authored drafts."""
