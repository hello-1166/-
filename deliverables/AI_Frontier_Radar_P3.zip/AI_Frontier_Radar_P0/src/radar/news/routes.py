from pathlib import Path
from typing import Literal

from fastapi import APIRouter, HTTPException, Query, Response
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from radar.integrations.feishu_sync import sync_configuration, sync_news
from radar.news import store
from radar.news.config import settings, sources
from radar.news.ingestion import IngestionBusy, run_ingestion
from radar.taxonomy.service import Availability, Category, Evidence, Format, Stage

router = APIRouter()


class IngestionRequest(BaseModel):
    source_ids: list[str] | None = Field(default=None, max_length=20)


class SyncRequest(BaseModel):
    limit: int = Field(default=25, ge=1, le=50)


@router.get("/radar", include_in_schema=False)
def inbox():
    return FileResponse(Path(__file__).parents[1] / "static" / "radar.html")


@router.get("/api/v1/sources", tags=["news"])
def list_sources():
    result = []
    for source in sources():
        row = source.model_dump()
        row["state"] = store.feed_state(source.source_id)
        result.append(row)
    return {"items": result}


@router.get("/api/v1/news", tags=["news"])
def list_news(
    limit: int = Query(default=30, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    source_id: str | None = None,
    q: str = Query(default="", max_length=200),
    sync: Literal["pending", "synced"] | None = None,
    category: Category | None = None,
    availability: Availability | None = None,
    evidence: Evidence | None = None,
    content_format: Format | None = None,
    stage: Stage | None = None,
):
    return store.news(
        limit, offset, source_id, q, sync, category, availability, evidence, content_format, stage
    )


@router.get("/api/v1/news/stats", tags=["news"])
def news_stats():
    return {
        **store.stats(),
        "feishu": sync_configuration(),
        "milestone": "P2",
        "content_status": "unverified",
        "model_calls_enabled": False,
        "lookback_days": settings().lookback_days,
    }


@router.get("/api/v1/ingestion/runs", tags=["news"])
def ingestion_history():
    return {"items": store.runs()}


@router.post("/api/v1/ingestion/run", tags=["news"])
def ingest(payload: IngestionRequest, response: Response):
    try:
        result = run_ingestion(payload.source_ids)
    except ValueError:
        raise HTTPException(400, "No valid enabled sources selected") from None
    except IngestionBusy:
        raise HTTPException(409, "A collection run is already in progress") from None
    if result["status"] == "failed":
        response.status_code = 502
    return result


@router.post("/api/v1/integrations/feishu/sync", tags=["news"])
def sync_to_feishu(payload: SyncRequest, response: Response):
    result = sync_news(payload.limit)
    status = result["status"]
    if status == "not_configured":
        response.status_code = 409
    elif status == "busy":
        response.status_code = 409
    elif status == "rate_limited":
        response.status_code = 429
    elif status == "failed":
        response.status_code = 502
    return result
