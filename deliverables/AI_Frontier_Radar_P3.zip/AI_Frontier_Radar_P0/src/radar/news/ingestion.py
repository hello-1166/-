from __future__ import annotations

import logging
import math
import time
from datetime import UTC, datetime, timedelta
from email.utils import parsedate_to_datetime
from threading import Lock
from urllib.parse import urljoin, urlsplit
from uuid import uuid4

import httpx

from radar.news import store
from radar.news.config import IngestionSettings, Source, settings, sources
from radar.news.parser import parse_feed

RUN_LOCK = Lock()
logger = logging.getLogger("radar.ingestion")


class IngestionBusy(Exception):
    pass


class FeedFailure(Exception):
    def __init__(self, code: str, retry_after: int = 0):
        self.code = code
        self.retry_after = retry_after
        super().__init__(code)


def retry_after_seconds(value: str | None) -> int:
    try:
        if value and value.isdigit():
            return max(int(value), 1)
        date = parsedate_to_datetime(value or "")
        return max(math.ceil((date - datetime.now(UTC)).total_seconds()), 1)
    except (ValueError, TypeError, OverflowError):
        return 60


def cooldown_until(seconds: int) -> str:
    try:
        return (datetime.now(UTC) + timedelta(seconds=seconds)).isoformat()
    except OverflowError:
        return datetime.max.replace(tzinfo=UTC).isoformat()


def fetch_feed(
    client: httpx.Client, source: Source, config: IngestionSettings, state: dict
) -> tuple[bytes | None, dict]:
    headers = {
        "Accept": "application/rss+xml, application/atom+xml, application/xml",
        "User-Agent": config.user_agent,
    }
    for field, name in [("etag", "If-None-Match"), ("last_modified", "If-Modified-Since")]:
        if state.get(field):
            headers[name] = state[field]
    for attempt in range(config.network_retries + 1):
        url = source.rss_url
        try:
            for _ in range(4):
                with client.stream("GET", url, headers=headers) as response:
                    if response.status_code in (301, 302, 303, 307, 308):
                        target = urljoin(url, response.headers.get("location", ""))
                        parts = urlsplit(target)
                        if (
                            parts.scheme != "https"
                            or parts.hostname != urlsplit(source.rss_url).hostname
                            or parts.username
                            or parts.password
                            or target == url
                        ):
                            raise FeedFailure("unsafe_redirect")
                        url = target
                        continue
                    if response.status_code == 304:
                        return None, {}
                    if response.status_code == 429:
                        raise FeedFailure(
                            "rate_limited", retry_after_seconds(response.headers.get("Retry-After"))
                        )
                    if response.status_code >= 500 and response.headers.get("Retry-After"):
                        raise FeedFailure(
                            "upstream_unavailable",
                            retry_after_seconds(response.headers["Retry-After"]),
                        )
                    if response.status_code >= 500 and attempt < config.network_retries:
                        break
                    if response.status_code != 200:
                        raise FeedFailure("http_" + str(response.status_code))
                    data = bytearray()
                    for chunk in response.iter_bytes():
                        data.extend(chunk)
                        if len(data) > config.max_feed_bytes:
                            raise FeedFailure("feed_too_large")
                    return bytes(data), {
                        "etag": response.headers.get("etag"),
                        "last_modified": response.headers.get("last-modified"),
                    }
            else:
                raise FeedFailure("too_many_redirects")
        except httpx.TimeoutException:
            if attempt == config.network_retries:
                raise FeedFailure("network_timeout") from None
        except httpx.HTTPError:
            if attempt == config.network_retries:
                raise FeedFailure("network_error") from None
        if attempt < config.network_retries:
            time.sleep(0.25 * (attempt + 1))
    raise FeedFailure("upstream_unavailable")


def run_ingestion(source_ids: list[str] | None = None, client: httpx.Client | None = None) -> dict:
    registry = sources()
    selected = [
        s for s in registry if s.enabled and (source_ids is None or s.source_id in source_ids)
    ]
    if source_ids is not None and set(source_ids) - {s.source_id for s in selected}:
        raise ValueError("Requested source is unknown or disabled")
    if not selected:
        raise ValueError("No enabled sources selected")
    config = settings()
    if not RUN_LOCK.acquire(blocking=False):
        raise IngestionBusy("An ingestion run is already in progress")
    owned_client = client is None
    result = {
        "id": str(uuid4()),
        "started_at": store.utc_now(),
        "status": "running",
        "seen": 0,
        "inserted": 0,
        "duplicates": 0,
        "skipped": 0,
        "errors": 0,
        "sources": [],
    }
    try:
        client = client or httpx.Client(timeout=config.timeout_seconds, follow_redirects=False)
        store.begin_run(result["id"], result["started_at"])
        for source in selected:
            detail = {
                "source_id": source.source_id,
                "status": "success",
                "seen": 0,
                "inserted": 0,
                "duplicates": 0,
                "skipped": 0,
            }
            state = store.feed_state(source.source_id)
            host_key = "feed_cooldown:" + urlsplit(source.rss_url).hostname
            try:
                cooldown = state.get("next_allowed_at")
                host_cooldown = store.state_value(host_key)
                if any(
                    value and datetime.fromisoformat(value) > datetime.now(UTC)
                    for value in (cooldown, host_cooldown)
                ):
                    raise FeedFailure("source_cooldown")
                data, cache = fetch_feed(client, source, config, state)
                if data is None:
                    detail["status"] = "not_modified"
                else:
                    try:
                        entries = parse_feed(data, source, config.summary_max_characters)
                    except Exception:
                        raise FeedFailure("invalid_feed") from None
                    detail["available_in_feed"] = len(entries)
                    entries = entries[: config.max_entries_per_source]
                    detail["seen"] = len(entries)
                    cutoff = datetime.now(UTC) - timedelta(days=config.lookback_days)
                    recent = [
                        e
                        for e in entries
                        if e["published_at"] is None
                        or datetime.fromisoformat(e["published_at"]) >= cutoff
                    ]
                    detail["skipped"] = len(entries) - len(recent)
                    detail["inserted"], detail["duplicates"] = store.save_items(
                        recent, store.utc_now()
                    )
                store.save_feed_state(
                    source.source_id,
                    {
                        **cache,
                        "last_checked_at": store.utc_now(),
                        "last_status": detail["status"],
                        "last_error": None,
                        "next_allowed_at": None,
                    },
                )
            except FeedFailure as error:
                detail.update(status="error", error=error.code)
                update = {
                    "last_checked_at": store.utc_now(),
                    "last_status": "error",
                    "last_error": error.code,
                }
                if error.retry_after:
                    update["next_allowed_at"] = cooldown_until(error.retry_after)
                    store.set_state(host_key, update["next_allowed_at"])
                    detail["retry_after_seconds"] = error.retry_after
                store.save_feed_state(source.source_id, update)
                result["errors"] += 1
            result["sources"].append(detail)
            for field in ["seen", "inserted", "duplicates", "skipped"]:
                result[field] += detail[field]
            logger.info("Source %s completed: %s", source.source_id, detail["status"])
        result["status"] = (
            "failed"
            if result["errors"] == len(selected)
            else "partial"
            if result["errors"]
            else "completed"
        )
        result["finished_at"] = store.utc_now()
        store.finish_run(result)
        # Rule-only screening; never triggers paid model calls from the ingestion workflow.
        from radar.selection.service import screen

        try:
            result["selection"] = screen()
        except Exception:
            logger.error("Editorial rule screening failed; ingestion data retained")
            result["selection"] = {"status": "failed"}
        return result
    finally:
        if owned_client and client is not None:
            client.close()
        RUN_LOCK.release()
