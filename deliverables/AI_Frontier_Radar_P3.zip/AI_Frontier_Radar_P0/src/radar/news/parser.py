from __future__ import annotations

import calendar
import re
from datetime import UTC, datetime
from html.parser import HTMLParser
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit
from uuid import NAMESPACE_URL, uuid5

import feedparser
from defusedxml.ElementTree import fromstring

from radar.news.config import Source


class PlainText(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.ignored = 0

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag in ("script", "style"):
            self.ignored += 1

    def handle_endtag(self, tag: str) -> None:
        if tag in ("script", "style"):
            self.ignored = max(0, self.ignored - 1)

    def handle_data(self, data: str) -> None:
        if not self.ignored:
            self.parts.append(data)


def plain_text(value: str, limit: int) -> str:
    parser = PlainText()
    parser.feed(value)
    return re.sub(r"\s+", " ", " ".join(parser.parts)).strip()[:limit]


def canonical_url(value: str) -> str:
    p = urlsplit(value.strip())
    if p.scheme.lower() not in ("http", "https") or not p.hostname or p.username or p.password:
        raise ValueError("Invalid article URL")
    if any(ord(char) < 32 for char in value):
        raise ValueError("Invalid article URL")
    host = p.hostname.lower()
    if ":" in host:
        host = "[" + host + "]"
    port = p.port
    if (
        port
        and not (p.scheme.lower() == "https" and port == 443)
        and not (p.scheme.lower() == "http" and port == 80)
    ):
        host += ":" + str(port)
    query = [
        (k, v)
        for k, v in parse_qsl(p.query, keep_blank_values=True)
        if not k.lower().startswith("utm_")
        and k.lower() not in {"fbclid", "gclid", "dclid", "mc_cid", "mc_eid"}
    ]
    return urlunsplit((p.scheme.lower(), host, p.path or "/", urlencode(query), ""))


def parse_feed(data: bytes, source: Source, summary_limit: int) -> list[dict]:
    root = fromstring(data, forbid_dtd=True, forbid_entities=True, forbid_external=True)
    if root.tag.rsplit("}", 1)[-1].lower() not in ("rss", "feed", "rdf"):
        raise ValueError("Not an RSS/Atom feed")
    parsed = feedparser.parse(data)
    if not parsed.version:
        raise ValueError("Unsupported feed format")
    result = []
    for entry in parsed.entries:
        title = plain_text(entry.get("title", ""), 500)
        link = entry.get("link", "")
        if not link or not title:
            continue
        original = urljoin(source.rss_url, link.strip())
        try:
            canonical = canonical_url(original)
        except ValueError:
            continue
        # An update timestamp alone is not evidence of an original publication time.
        raw_date = entry.get("published") or ""
        date = entry.get("published_parsed")
        published = None
        if date:
            try:
                published = datetime.fromtimestamp(calendar.timegm(date), UTC).isoformat()
            except (ValueError, OverflowError, OSError):
                pass
        result.append(
            {
                "id": str(uuid5(NAMESPACE_URL, canonical)),
                "canonical_url": canonical,
                "title": title,
                "original_url": original,
                "source_id": source.source_id,
                "source_name": source.name,
                "language": source.language,
                "category": source.category,
                "summary": plain_text(entry.get("summary", ""), summary_limit),
                "published_at": published,
                "published_at_raw": str(raw_date)[:200],
                "entry_id": str(entry.get("id") or canonical)[:1000],
            }
        )
    return sorted(result, key=lambda row: row["published_at"] or "", reverse=True)
