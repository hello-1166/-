param(
    [Parameter(Mandatory = $true)]
    [string]$ExistingProjectPath
)
$ErrorActionPreference = "Stop"
$SourceRoot = [System.IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
$TargetRoot = [System.IO.Path]::GetFullPath((Resolve-Path -LiteralPath $ExistingProjectPath).Path)
if ([string]::Equals($SourceRoot, $TargetRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Extract P3 to a separate folder, then point ExistingProjectPath to the original P0 folder."
}
if (-not (Test-Path (Join-Path $TargetRoot 'docker-compose.yml')) -or
    -not (Test-Path (Join-Path $TargetRoot 'src/radar/main.py'))) {
    throw "Target does not look like the existing Radar project."
}
$ManifestPath = Join-Path $SourceRoot 'release_manifest.json'
$LegacyPath = Join-Path $SourceRoot 'p3_upgrade_manifest.json'
if (-not (Test-Path $ManifestPath) -or -not (Test-Path $LegacyPath)) {
    throw "Release manifests are missing. Use the complete P3 release ZIP."
}
$Manifest = [System.IO.File]::ReadAllText($ManifestPath) | ConvertFrom-Json
$Legacy = [System.IO.File]::ReadAllText($LegacyPath) | ConvertFrom-Json

function Get-NormalizedDockerHash([string]$Path) {
    $Lines = [System.IO.File]::ReadAllLines($Path) | Where-Object {
        $_.Trim() -ne '' -and $_.Trim() -ne '#' -and
        $_.Trim() -ne '# syntax=docker/dockerfile:1'
    }
    $Text = (($Lines | ForEach-Object { $_.TrimEnd() }) -join "`n").Replace(
        'FROM public.ecr.aws/docker/library/python:3.12-slim', 'FROM python:3.12-slim')
    $Hash = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($Hash.ComputeHash(
            [System.Text.Encoding]::UTF8.GetBytes($Text)))).Replace('-', '').ToLowerInvariant()
    } finally { $Hash.Dispose() }
}

$Plan = @()
foreach ($Entry in $Manifest.files.PSObject.Properties) {
    $Relative = $Entry.Name
    if ($Relative -eq '.env' -or $Relative -match '^(data|logs|backups|\.git|\.venv)(/|\\|$)') {
        throw "Forbidden release path: $Relative"
    }
    $LocalRelative = $Relative.Replace('/', [System.IO.Path]::DirectorySeparatorChar)
    $Source = [System.IO.Path]::GetFullPath((Join-Path $SourceRoot $LocalRelative))
    $Target = [System.IO.Path]::GetFullPath((Join-Path $TargetRoot $LocalRelative))
    foreach ($Check in @(@($Source, $SourceRoot), @($Target, $TargetRoot))) {
        if (-not $Check[0].StartsWith($Check[1] + [System.IO.Path]::DirectorySeparatorChar,
                [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "Unsafe release path: $Relative"
        }
    }
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf) -or
        (Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Entry.Value) {
        throw "Release file checksum failed: $Relative"
    }
    if (Test-Path -LiteralPath $Target) {
        $CurrentHash = (Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($CurrentHash -eq $Entry.Value) { continue }
        $Known = $Legacy.allowed_hashes.PSObject.Properties[$Relative]
        $Allowed = $Known -and (@($Known.Value) -contains $CurrentHash)
        if (-not $Allowed -and $Relative -eq 'Dockerfile') {
            $Allowed = @($Legacy.normalized_dockerfile_hashes) -contains (Get-NormalizedDockerHash $Target)
        }
        if (-not $Allowed) {
            throw "Locally modified file requires manual review; no files changed: $Relative"
        }
    }
    $Plan += @{ Relative = $Relative; Source = $Source; Target = $Target }
}
if ($Plan.Count -eq 0) { Write-Host 'P3 files are already installed.'; return }
$Backup = Join-Path $TargetRoot ('backups/p3-code-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ') + '-' + [Guid]::NewGuid().ToString('N').Substring(0,8))
foreach ($Item in $Plan) {
    if (Test-Path -LiteralPath $Item.Target) {
        $Copy = Join-Path $Backup $Item.Relative
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Copy) | Out-Null
        Copy-Item -LiteralPath $Item.Target -Destination $Copy
    }
}
$Applied = @()
try {
    foreach ($Item in $Plan) {
        $Applied += $Item
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Item.Target) | Out-Null
        Copy-Item -LiteralPath $Item.Source -Destination $Item.Target -Force
    }
} catch {
    foreach ($Item in $Applied) {
        $Copy = Join-Path $Backup $Item.Relative
        if (Test-Path -LiteralPath $Copy) { Copy-Item -LiteralPath $Copy -Destination $Item.Target -Force }
        elseif (Test-Path -LiteralPath $Item.Target) { Remove-Item -LiteralPath $Item.Target }
    }
    throw
}
Write-Host 'P3 code installed. Existing .env, data, logs and n8n volumes were preserved.'
Write-Host "Previous code backup: $Backup"
Write-Host "Open PowerShell in $TargetRoot and run: .\scripts\start_p0.ps1"
Write-Host 'Content planning desk: http://localhost:8000/plans'
