$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$ExamplePath = Join-Path $ProjectRoot ".env.example"
$EnvPath = Join-Path $ProjectRoot ".env"

if (-not (Test-Path $ExamplePath)) {
    throw ".env.example not found: $ExamplePath"
}

if (Test-Path $EnvPath) {
    Write-Host ".env already exists. It will not be overwritten."
    exit 0
}

$content = Get-Content $ExamplePath -Raw -Encoding UTF8
$bytes = New-Object byte[] 32
$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
$rng.GetBytes($bytes)
$rng.Dispose()
$key = [Convert]::ToBase64String($bytes)
$content = $content.Replace("GENERATED_BY_init_env_ps1", $key)

$utf8NoBom = New-Object System.Text.UTF8Encoding -ArgumentList $false
$file = [System.IO.File]::Open($EnvPath, [System.IO.FileMode]::CreateNew)
try {
    $encoded = $utf8NoBom.GetBytes($content)
    $file.Write($encoded, 0, $encoded.Length)
} finally {
    $file.Dispose()
}
Write-Host ".env created. A local n8n encryption key was generated."
Write-Host "Do not share or commit .env."
