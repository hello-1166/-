# AGENTS.md — AI Frontier Radar

## Project objective
Build AI Frontier Radar V1.0: a local-first, semi-automated global AI news intelligence and content-preparation system for Xiaohongshu and Douyin.

## Current milestone
P0 is accepted on the user's Windows machine. The user has authorized continuing the original
plan into P1: public RSS/Atom collection, provenance, URL deduplication, a local news inbox,
an inactive n8n ingestion workflow, and optional manual Feishu News Inbox synchronization.
Implement P1 only. Do not implement paid model calls, scoring, fact-checking, content generation,
video rendering or platform publication in this milestone.

P0 deliverables:
- Docker Compose local environment
- n8n service
- FastAPI service
- SQLite initialization and readiness check
- configuration validation for multi-provider LLM and Feishu
- tests, logs, documentation, PowerShell setup script

Do not implement news ingestion, scoring, fact-checking, content generation, video rendering, or platform publishing in P0.

## Required engineering rules
1. Inspect the existing repository before changing files.
2. Preserve user data and existing files. Never overwrite unreviewed files.
3. Do not invent API keys, Feishu app IDs, table IDs, model IDs, or credentials.
4. Do not hardcode secrets. Read secrets from environment variables.
5. Never print API keys, app secrets, access tokens, or encryption keys in logs or API responses.
6. Bind local development ports to `127.0.0.1`, not `0.0.0.0` on the host.
7. Keep the Python API accessible to n8n over the internal Docker network at `http://api:8000`.
8. Keep all service configuration outside business logic.
9. Use type hints, clear module boundaries, structured logging, and small testable functions.
10. Add or update tests for every behavior change.
11. Do not claim a test passed unless it was actually run and its output inspected.
12. Do not automatically publish to Xiaohongshu or Douyin.
13. Do not scrape login-protected sites or bypass rate limits/access controls.
14. Keep source URLs and attribution in all future news records.
15. Use UTC internally; use `Asia/Shanghai` for editorial schedules and display.

## P0 acceptance
- `docker compose config` succeeds.
- `docker compose up -d --build` starts `api` and `n8n`.
- `GET /health` returns healthy.
- `GET /ready` verifies SQLite initialization.
- configuration-status endpoints do not reveal secrets.
- `pytest` passes.
- no secrets or local runtime data are committed.

## Codex workflow
Work in small steps:
1. inspect;
2. propose a concise plan;
3. implement;
4. run tests;
5. inspect diffs;
6. summarize changed files, commands run, results, and unresolved issues.

P1 approval is recorded in the conversation: the user asked to continue according to the original
plan after P0 startup and n8n persistence checks passed. Do not proceed to P2 without approval.
