import json
import re

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError
from test_p2_selection import NOW, article, seed

from radar.main import app
from radar.news.store import database, utc_now
from radar.selection import store
from radar.selection.editorial_rules import EditorialRules, rules
from radar.selection.ranking import rank
from radar.selection.service import screen


def test_concrete_creator_task_outranks_generic_model_announcement():
    generic = article(title="Introducing Example model")
    generic["summary"] = "Our new model is now available. " * 8
    useful = article(title="Introducing video editing for creators")
    useful["summary"] = (
        "A hands-on demo shows creators editing video, compared with the previous tool. "
        "Pricing is lower and the new feature is available for download."
    )
    a, b = rank(generic, NOW), rank(useful, NOW)
    assert a["score"] < 65 <= b["score"]
    assert b["lane"] == "creator" and b["signals"]["creator"]
    assert "创作任务" in b["angle"]
    assert sum(b["dimensions"].values()) == b["score"] <= 100


@pytest.mark.parametrize("summary", ["", "No summary available.", "Introducing a video tool " * 3])
def test_missing_placeholder_or_repeated_title_never_enters_auto_recommendation(summary):
    item = article(title="Introducing a video tool")
    item["summary"] = summary
    value = rank(item, NOW)
    assert not value["eligible"] and not value["material_sufficient"]
    assert value["score"] <= 64 and value["blockers"]
    assert not seed(item)[0]["recommended"]


def test_rumor_blocks_recommendation_and_access_limit_is_explained():
    item = article(title="Introducing video editing for creators")
    base = rank(item, NOW)
    item["summary"] += " Limited preview, join the waitlist."
    limited = rank(item, NOW)
    assert limited["score"] < base["score"]
    assert limited["dimensions"]["使用门槛调整"] == -rules().penalties.limited
    assert any("受限开放" in c for c in limited["checks"])
    item["summary"] += " Unconfirmed rumor: pricing may change."
    rumor = rank(item, NOW)
    assert not rumor["eligible"] and any("传闻" in c for c in rumor["blockers"])


def test_hype_alone_does_not_increase_score_or_become_fact_verification():
    item = article()
    base = rank(item, NOW)
    item["title"] += " 震惊！炸裂！颠覆！史上最强！"
    hype = rank(item, NOW)
    assert hype["score"] == base["score"]
    assert "官方描述不等于独立实测结果" in hype["checks"]
    assert "本人实测" not in " ".join(hype["reasons"])


def test_bad_source_does_not_receive_traceability_points():
    item = article()
    item["original_url"] = "javascript:alert(1)"
    result = rank(item, NOW)
    assert result["dimensions"]["来源可追溯"] == 0 and not result["eligible"]


def test_recommendation_diversity_and_existing_human_choices_are_preserved():
    items = [article(str(i), f"Introducing creator video tool {i}") for i in range(7)]
    office = article("office", "Introducing spreadsheet reports for office teams")
    office["summary"] = (
        "A hands-on demo shows spreadsheets and meeting notes in the office workflow. "
        "The new feature improves speed, with pricing available for review."
    )
    topics = seed(*items, office)
    creator = next(i for i in topics if i["analysis"]["lane"] == "creator")
    store.decide(creator["id"], "selected")
    result = screen(NOW)
    assert result["lanes"]["创作工具"] == 3 and result["lanes"]["办公与工作"] == 1
    assert result["recommended"] == 4
    assert store.topic(creator["id"])["decision"] == "selected"
    assert store.topic(creator["id"])["analysis"]["recommendation_note"].startswith("已由你")
    recommended = store.listing(100, 0, "recommended", "", utc_now())["items"]
    assert len(recommended) == 4
    assert any(i["analysis"]["lane"] == "office" for i in recommended)
    remaining = next(i for i in topics if i["id"] != creator["id"])
    store.decide(remaining["id"], "ignored")
    screen(NOW)
    assert store.topic(remaining["id"])["decision"] == "ignored"


def test_explanations_and_version_are_exposed_without_model_calls():
    seed(article())
    with TestClient(app) as client:
        status = client.get("/api/v1/selection/status").json()
        assert status["last_screen"]["rule_version"] == "creator-rules-v2"
        assert status["budget"]["requests"] == 0
        item = client.get("/api/v1/topics").json()["items"][0]
        assert item["analysis"]["recommendation_note"]
        assert item["analysis"]["signals"]


def test_repeated_screen_does_not_modify_saved_plan_snapshot():
    topic = seed(article())[0]
    store.decide(topic["id"], "selected")
    with TestClient(app) as client:
        plan = client.post(
            "/api/v1/plans",
            json={
                "title": "保留策划",
                "topic_ids": [topic["id"]],
            },
        ).json()
        with database() as c:
            c.execute("UPDATE news_items SET summary='updated source summary'")
        screen(NOW)
        assert client.get("/api/v1/plans/" + plan["id"]).json() == plan


def test_weight_mistakes_and_invalid_patterns_fail_validation():
    cfg = rules().model_dump()
    cfg["weights"]["freshness"] += 1
    with pytest.raises(ValidationError):
        EditorialRules.model_validate(cfg)
    cfg = rules().model_dump()
    cfg["patterns"]["creator"] = "["
    with pytest.raises(re.error):
        EditorialRules.model_validate(cfg)


def test_research_cap_and_score_dimensions_remain_consistent():
    item = article()
    item["source_id"] = "SRC_ARXIV_AI"
    value = rank(item, NOW)
    assert value["score"] <= 55
    assert sum(value["dimensions"].values()) == value["score"]
    assert value["lane"] == "research"
    assert "产品" in value["angle"]


def test_old_score_cache_is_replaced_without_clearing_selection():
    topic = seed(article())[0]
    store.decide(topic["id"], "selected")
    with database() as c:
        c.execute("UPDATE editorial_topics SET analysis_json=?", (json.dumps({"old": True}),))
    screen(NOW)
    item = store.topic(topic["id"])
    assert item["decision"] == "selected"
    assert item["analysis"]["rule_version"] == "creator-rules-v2"


def test_training_event_and_professional_healthcare_are_not_consumer_tools():
    event = article(title="Helping caregivers use AI in everyday life")
    event["summary"] = (
        "Free, hands-on ChatGPT workshops for caregivers in five U.S. cities. "
        "The training event teaches practical skills for everyday life."
    )
    result = rank(event, NOW)
    assert result["lane"] == "activity" and result["score"] <= 55
    medical = article(title="Introducing healthcare workflow automation")
    medical["summary"] = (
        "A healthcare system integrates clinical data and automates hospital workflows. "
        "A demo shows the new feature for clinical teams."
    )
    result = rank(medical, NOW)
    assert result["lane"] == "industry" and result["dimensions"]["受众相关"] < 20
    assert any("AI医生" in check for check in result["checks"])


def test_economic_changes_and_document_tasks_can_qualify_without_model_hype():
    report = article(title="AI and freelance work", hours=96)
    report["summary"] = (
        "New research finds shifting demand for freelance work, new skill combinations, "
        "larger budgets and more hours for AI-related projects."
    )
    result = rank(report, NOW)
    assert result["lane"] == "office" and result["score"] >= 65
    task = article(title="Creative productivity tools integrate with everyday apps", hours=96)
    task["summary"] = (
        "Teams can edit PDFs in Drive. The integration connects creative and productivity "
        "tools to everyday apps, keeping the workflow in one place."
    )
    result = rank(task, NOW)
    assert result["score"] >= 65 and result["signals"]["task"]


def test_selected_export_includes_recommendation_reason_and_angle():
    topic = seed(article())[0]
    store.decide(topic["id"], "selected")
    with TestClient(app) as client:
        text = client.get("/api/v1/topics/export").text
        assert "creator-rules-v2" in text and "建议角度" in text
        assert "原始出处" in text and "规则线索，非事实结论" in text
