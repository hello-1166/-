from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from radar.core.config import load_yaml

Lane = Literal[
    "creator", "office", "consumer", "developer", "research", "industry", "activity", "general"
]
LANE_LABELS = {
    "creator": "创作工具",
    "office": "办公与工作",
    "consumer": "大众应用",
    "developer": "开发者与智能体",
    "research": "研究观察",
    "general": "综合观察",
    "industry": "专业行业观察",
    "activity": "培训与活动",
}


class Weights(BaseModel):
    model_config = ConfigDict(extra="forbid")
    freshness: int = Field(ge=0, le=100)
    audience: int = Field(ge=0, le=100)
    change: int = Field(ge=0, le=100)
    demonstration: int = Field(ge=0, le=100)
    traceability: int = Field(ge=0, le=100)
    material: int = Field(ge=0, le=100)

    @model_validator(mode="after")
    def hundred(self):
        if sum(self.model_dump().values()) != 100:
            raise ValueError("Editorial weights must sum to 100")
        return self


class Penalties(BaseModel):
    model_config = ConfigDict(extra="forbid")
    limited: int = Field(ge=0, le=100)
    rumor: int = Field(ge=0, le=100)


class EditorialRules(BaseModel):
    model_config = ConfigDict(extra="forbid")
    version: str = Field(min_length=1, max_length=100)
    lane_limit: int = Field(ge=1, le=30)
    minimum_summary_chars: int = Field(ge=1, le=1000)
    research_cap: int = Field(ge=0, le=100)
    insufficient_cap: int = Field(ge=0, le=100)
    activity_cap: int = Field(ge=0, le=100)
    weights: Weights
    penalties: Penalties
    patterns: dict[str, str]
    angles: dict[Lane, str]

    @model_validator(mode="after")
    def validate_patterns(self):
        needed = {
            "creator",
            "office",
            "consumer",
            "developer",
            "release",
            "access",
            "comparison",
            "capability",
            "demo",
            "visual",
            "research",
            "limited",
            "rumor",
            "task",
            "activity",
            "professional",
        }
        if set(self.patterns) != needed or set(self.angles) != set(LANE_LABELS):
            raise ValueError("Missing or unknown editorial rule fields")
        for pattern in self.patterns.values():
            re.compile(pattern)
        return self


def rules() -> EditorialRules:
    return EditorialRules.model_validate(load_yaml("editorial_ranking.yaml"))
