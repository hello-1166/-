from __future__ import annotations

import re
from datetime import UTC, datetime
from difflib import SequenceMatcher
from urllib.parse import urlsplit

from radar.selection.editorial_rules import LANE_LABELS, EditorialRules, rules

STOP = {"a", "an", "the", "of", "in", "on", "and", "for", "to", "with", "ai", "new"}


def terms(title: str) -> set[str]:
    words = set(re.findall(r"[a-z0-9]+(?:[.-][a-z0-9]+)*", title.lower())) - STOP
    # Chinese bigrams allow conservative matching without adding a tokenizer dependency.
    for phrase in re.findall(r"[\u4e00-\u9fff]+", title):
        words.update(phrase[i : i + 2] for i in range(len(phrase) - 1))
    return words


def likely_same_event(left: str, right: str, threshold: float) -> bool:
    a, b = terms(left), terms(right)
    if len(a & b) < 3:
        return False

    # Distinct model versions or quantities must not be merged automatically.
    def digits(s):
        return set(re.findall(r"\d+(?:\.\d+)*", s))

    negatives = r"\b(not|never|no|deny|denies|fake)\b|并未|否认|不支持|无法|尚未"
    if bool(re.search(negatives, left.lower())) != bool(re.search(negatives, right.lower())):
        return False
    if digits(left) != digits(right):
        return False
    jaccard = len(a & b) / len(a | b)
    return (
        jaccard >= threshold and SequenceMatcher(None, left.lower(), right.lower()).ratio() >= 0.7
    )


def rank(
    item: dict, now: datetime, cfg: EditorialRules | None = None, lookback_days: int = 7
) -> dict:
    cfg = cfg or rules()
    title, summary = item["title"], item.get("summary", "").strip()
    text = title + "\n" + summary
    matches = {k: re.search(pattern, text, re.I) for k, pattern in cfg.patterns.items()}
    flags = {k: bool(match) for k, match in matches.items()}
    signals = {k: match.group(0)[:80] for k, match in matches.items() if match}
    age = None
    if item.get("published_at"):
        try:
            dt = datetime.fromisoformat(item["published_at"].replace("Z", "+00:00"))
            if dt.tzinfo:
                age = (now - dt.astimezone(UTC)).total_seconds() / 3600
        except ValueError:
            pass
    timely = age is not None and 0 <= age <= lookback_days * 24
    research = (
        flags["research"]
        or "arxiv" in item["source_id"].lower()
        or item.get("category") == "research"
    )
    lane = next((k for k in ("creator", "office", "consumer", "developer") if flags[k]), "general")
    if flags["professional"]:
        lane = "industry"
    if flags["activity"]:
        lane = "activity"
    if research:
        lane = "research"
    try:
        url = urlsplit(item.get("original_url", ""))
        traceable = url.scheme in {"http", "https"} and bool(url.hostname) and not url.username
    except ValueError:
        traceable = False

    # A repeated title or feed placeholder is not meaningful summary evidence.
    def normalized(value: str) -> str:
        return re.sub(r"[\W_]+", "", value.casefold())

    body = normalized(summary)
    headline = normalized(title)
    placeholder = summary.lower() in {"no summary", "no summary available", "来源未提供摘要"}
    sufficient = (
        len(body) >= cfg.minimum_summary_chars
        and body != headline
        and not (
            headline
            and len(body) % len(headline) == 0
            and body == headline * (len(body) // len(headline))
        )
        and not placeholder
    )
    w = cfg.weights
    audience = (
        1
        if lane in {"creator", "office"}
        else 0.72
        if lane == "consumer"
        else 0.4
        if lane == "developer"
        else 0.2
    )
    freshness = 1 if timely and age <= 24 else 0.7 if timely and age <= 72 else 0.5 if timely else 0
    change = min(
        1,
        0.4 * flags["release"]
        + 0.3 * flags["access"]
        + 0.3 * flags["comparison"]
        + 0.3 * flags["capability"],
    )
    demonstration = 1 if flags["demo"] else 0.6 if flags["task"] else 0.4 if flags["visual"] else 0
    dimensions = {
        "时效性": round(w.freshness * freshness),
        "受众相关": round(w.audience * audience),
        "变化线索": round(w.change * change),
        "演示潜力": round(w.demonstration * demonstration),
        "来源可追溯": w.traceability if traceable else 0,
        "材料完整度": w.material if sufficient else 0,
    }
    reasons = []
    if lane in {"creator", "office", "consumer", "developer"}:
        reasons.append(f"{LANE_LABELS[lane]}线索：{signals[lane]}；不是仅凭模型名称判断受众价值")
    for key, label in (
        ("access", "价格或获取方式"),
        ("comparison", "效果或成本变化"),
        ("capability", "新增能力"),
        ("demo", "可展示材料"),
    ):
        if flags[key]:
            reasons.append(f"{label}线索：{signals[key]}，具体条件与效果仍需核实")
    blockers, checks = [], ["核对原文日期、版本、开放地区与收费条件", "官方描述不等于独立实测结果"]
    if not timely:
        blockers.append("时间未知、未来或超出当前筛选范围")
        checks.insert(0, "原始发布时间未知、在未来或已超时，不进入自动推荐")
    if not traceable:
        blockers.append("缺少有效原始链接")
        checks.append("补齐有效的 http/https 原始出处")
    if not sufficient:
        blockers.append("有效摘要不足，需先阅读原文")
        checks.insert(0, "摘要缺失、过短或重复标题；补充原文材料后再评估")
    if lane == "industry":
        reasons.append("包含专业医疗场景，不能仅因工作流关键词按大众办公产品推荐")
        checks.append("核对专业用户、机构与监管条件；不能包装成面向所有人的AI医生")
    if lane == "activity":
        reasons.append("材料指向培训或活动，不作为新产品发布推荐")
        checks.append("核对活动时间、地区与参加方式")
    if flags["limited"]:
        dimensions["使用门槛调整"] = -cfg.penalties.limited
        checks.append(f"发现受限开放线索：{signals['limited']}，不能承诺所有用户现在可用")
    if flags["rumor"]:
        dimensions["未证实线索调整"] = -cfg.penalties.rumor
        blockers.append("材料含未证实或传闻线索")
        checks.append(f"先核实传闻线索：{signals['rumor']}，不自动推荐为确认事实")
    if research:
        checks.append("研究或基准材料不能直接推断为已经开放的产品")
        reasons.append("按研究观察处理，不作为大众即用产品推荐")
    score = sum(dimensions.values())
    caps = [100]
    if research:
        caps.append(cfg.research_cap)
    if lane == "activity":
        caps.append(cfg.activity_cap)
    if not sufficient:
        caps.append(cfg.insufficient_cap)
    bounded = min(max(0, score), *caps)
    if bounded != score:
        dimensions["材料与研究边界调整"] = bounded - score
    if not reasons:
        reasons.append("未找到具体使用任务或变化依据，先补充受众价值再决定是否制作")
    return {
        "score": bounded,
        "dimensions": dimensions,
        "reasons": reasons,
        "checks": checks,
        "timely": timely,
        "angle": cfg.angles[lane],
        "evidence_level": "rss_summary" if sufficient else "insufficient_summary",
        "material_sufficient": sufficient,
        "lane": lane,
        "lane_label": LANE_LABELS[lane],
        "signals": signals,
        "blockers": blockers,
        "eligible": not blockers,
        "rule_version": cfg.version,
    }
